﻿namespace MHLab.PATCH.Admin
{
    partial class PatchForm
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PatchForm));
            this.BuildButton = new System.Windows.Forms.Button();
            this.NewVersion = new System.Windows.Forms.Button();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.MainDebug = new System.Windows.Forms.TextBox();
            this.DetailsDebug = new System.Windows.Forms.TextBox();
            this.FromVersion = new System.Windows.Forms.ComboBox();
            this.ToVersion = new System.Windows.Forms.ComboBox();
            this.MajorText = new System.Windows.Forms.TextBox();
            this.EncryptConfigButton = new System.Windows.Forms.Button();
            this.CreateConfigButton = new System.Windows.Forms.Button();
            this.PatchesBuilderVersionLabel = new System.Windows.Forms.Label();
            this.CoreVersionLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CloseButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.LastVersionLabel = new System.Windows.Forms.Label();
            this.MinorText = new System.Windows.Forms.TextBox();
            this.MaintenanceText = new System.Windows.Forms.TextBox();
            this.BuildText = new System.Windows.Forms.TextBox();
            this.Compression = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.OpenFolderCheck = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.IncludeLauncherCheckbox = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BuildButton
            // 
            this.BuildButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.BuildButton.FlatAppearance.BorderSize = 0;
            this.BuildButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BuildButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BuildButton.Location = new System.Drawing.Point(685, 114);
            this.BuildButton.Name = "BuildButton";
            this.BuildButton.Size = new System.Drawing.Size(75, 23);
            this.BuildButton.TabIndex = 0;
            this.BuildButton.Text = "Build patch";
            this.BuildButton.UseVisualStyleBackColor = false;
            this.BuildButton.Click += new System.EventHandler(this.BuildButton_Click);
            // 
            // NewVersion
            // 
            this.NewVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.NewVersion.FlatAppearance.BorderSize = 0;
            this.NewVersion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewVersion.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.NewVersion.Location = new System.Drawing.Point(685, 143);
            this.NewVersion.Name = "NewVersion";
            this.NewVersion.Size = new System.Drawing.Size(75, 23);
            this.NewVersion.TabIndex = 1;
            this.NewVersion.Text = "New version";
            this.NewVersion.UseVisualStyleBackColor = false;
            this.NewVersion.Click += new System.EventHandler(this.NewVersion_Click);
            // 
            // ProgressBar
            // 
            this.ProgressBar.Location = new System.Drawing.Point(13, 274);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ProgressBar.Size = new System.Drawing.Size(748, 43);
            this.ProgressBar.Step = 1;
            this.ProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.ProgressBar.TabIndex = 2;
            // 
            // MainDebug
            // 
            this.MainDebug.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.MainDebug.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MainDebug.ForeColor = System.Drawing.Color.White;
            this.MainDebug.Location = new System.Drawing.Point(12, 194);
            this.MainDebug.Name = "MainDebug";
            this.MainDebug.ReadOnly = true;
            this.MainDebug.Size = new System.Drawing.Size(452, 20);
            this.MainDebug.TabIndex = 3;
            // 
            // DetailsDebug
            // 
            this.DetailsDebug.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.DetailsDebug.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DetailsDebug.ForeColor = System.Drawing.Color.White;
            this.DetailsDebug.Location = new System.Drawing.Point(12, 220);
            this.DetailsDebug.Name = "DetailsDebug";
            this.DetailsDebug.ReadOnly = true;
            this.DetailsDebug.Size = new System.Drawing.Size(748, 20);
            this.DetailsDebug.TabIndex = 4;
            // 
            // FromVersion
            // 
            this.FromVersion.FormattingEnabled = true;
            this.FromVersion.Location = new System.Drawing.Point(523, 116);
            this.FromVersion.Name = "FromVersion";
            this.FromVersion.Size = new System.Drawing.Size(75, 21);
            this.FromVersion.TabIndex = 5;
            this.FromVersion.SelectedIndexChanged += new System.EventHandler(this.FromVersion_SelectedIndexChanged);
            // 
            // ToVersion
            // 
            this.ToVersion.FormattingEnabled = true;
            this.ToVersion.Location = new System.Drawing.Point(604, 116);
            this.ToVersion.Name = "ToVersion";
            this.ToVersion.Size = new System.Drawing.Size(75, 21);
            this.ToVersion.TabIndex = 6;
            this.ToVersion.SelectedIndexChanged += new System.EventHandler(this.ToVersion_SelectedIndexChanged);
            // 
            // MajorText
            // 
            this.MajorText.Location = new System.Drawing.Point(584, 145);
            this.MajorText.Name = "MajorText";
            this.MajorText.Size = new System.Drawing.Size(23, 20);
            this.MajorText.TabIndex = 7;
            this.MajorText.Text = "0";
            this.MajorText.TextChanged += new System.EventHandler(this.NewVersionName_TextChanged);
            // 
            // EncryptConfigButton
            // 
            this.EncryptConfigButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.EncryptConfigButton.FlatAppearance.BorderSize = 0;
            this.EncryptConfigButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EncryptConfigButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.EncryptConfigButton.Location = new System.Drawing.Point(6, 19);
            this.EncryptConfigButton.Name = "EncryptConfigButton";
            this.EncryptConfigButton.Size = new System.Drawing.Size(89, 23);
            this.EncryptConfigButton.TabIndex = 8;
            this.EncryptConfigButton.Text = "Encrypt config";
            this.EncryptConfigButton.UseVisualStyleBackColor = false;
            this.EncryptConfigButton.Click += new System.EventHandler(this.EncryptConfigButton_Click);
            // 
            // CreateConfigButton
            // 
            this.CreateConfigButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(23)))), ((int)(((byte)(23)))));
            this.CreateConfigButton.FlatAppearance.BorderSize = 0;
            this.CreateConfigButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreateConfigButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.CreateConfigButton.Location = new System.Drawing.Point(101, 19);
            this.CreateConfigButton.Name = "CreateConfigButton";
            this.CreateConfigButton.Size = new System.Drawing.Size(89, 23);
            this.CreateConfigButton.TabIndex = 9;
            this.CreateConfigButton.Text = "Create config";
            this.CreateConfigButton.UseVisualStyleBackColor = false;
            this.CreateConfigButton.Click += new System.EventHandler(this.CreateConfigButton_Click);
            // 
            // PatchesBuilderVersionLabel
            // 
            this.PatchesBuilderVersionLabel.AutoSize = true;
            this.PatchesBuilderVersionLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.PatchesBuilderVersionLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PatchesBuilderVersionLabel.Location = new System.Drawing.Point(13, 330);
            this.PatchesBuilderVersionLabel.Name = "PatchesBuilderVersionLabel";
            this.PatchesBuilderVersionLabel.Size = new System.Drawing.Size(123, 13);
            this.PatchesBuilderVersionLabel.TabIndex = 10;
            this.PatchesBuilderVersionLabel.Text = "Patches builder version: ";
            // 
            // CoreVersionLabel
            // 
            this.CoreVersionLabel.AutoSize = true;
            this.CoreVersionLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.CoreVersionLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CoreVersionLabel.Location = new System.Drawing.Point(345, 330);
            this.CoreVersionLabel.Name = "CoreVersionLabel";
            this.CoreVersionLabel.Size = new System.Drawing.Size(72, 13);
            this.CoreVersionLabel.TabIndex = 11;
            this.CoreVersionLabel.Text = "Core version: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.EncryptConfigButton);
            this.groupBox1.Controls.Add(this.CreateConfigButton);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Location = new System.Drawing.Point(564, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(196, 52);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Launcher settings";
            // 
            // CloseButton
            // 
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.CloseButton.FlatAppearance.BorderSize = 0;
            this.CloseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(740, 4);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(20, 23);
            this.CloseButton.TabIndex = 13;
            this.CloseButton.Text = "X";
            this.CloseButton.UseVisualStyleBackColor = false;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(470, 196);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Last version:";
            // 
            // LastVersionLabel
            // 
            this.LastVersionLabel.AutoSize = true;
            this.LastVersionLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.LastVersionLabel.Location = new System.Drawing.Point(543, 196);
            this.LastVersionLabel.Name = "LastVersionLabel";
            this.LastVersionLabel.Size = new System.Drawing.Size(24, 13);
            this.LastVersionLabel.TabIndex = 15;
            this.LastVersionLabel.Text = "n/d";
            // 
            // MinorText
            // 
            this.MinorText.Location = new System.Drawing.Point(608, 145);
            this.MinorText.Name = "MinorText";
            this.MinorText.Size = new System.Drawing.Size(23, 20);
            this.MinorText.TabIndex = 16;
            this.MinorText.Text = "0";
            // 
            // MaintenanceText
            // 
            this.MaintenanceText.Location = new System.Drawing.Point(632, 145);
            this.MaintenanceText.Name = "MaintenanceText";
            this.MaintenanceText.Size = new System.Drawing.Size(23, 20);
            this.MaintenanceText.TabIndex = 17;
            this.MaintenanceText.Text = "0";
            // 
            // BuildText
            // 
            this.BuildText.Location = new System.Drawing.Point(656, 145);
            this.BuildText.Name = "BuildText";
            this.BuildText.Size = new System.Drawing.Size(23, 20);
            this.BuildText.TabIndex = 18;
            this.BuildText.Text = "0";
            // 
            // Compression
            // 
            this.Compression.FormattingEnabled = true;
            this.Compression.Items.AddRange(new object[] {
            "ZIP",
            "TAR",
            "TARGZ"});
            this.Compression.Location = new System.Drawing.Point(467, 116);
            this.Compression.Name = "Compression";
            this.Compression.Size = new System.Drawing.Size(50, 21);
            this.Compression.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(14, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(228, 21);
            this.label2.TabIndex = 20;
            this.label2.Text = "P.A.T.C.H. - Admin patch builder";
            // 
            // OpenFolderCheck
            // 
            this.OpenFolderCheck.AutoSize = true;
            this.OpenFolderCheck.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.OpenFolderCheck.Location = new System.Drawing.Point(622, 195);
            this.OpenFolderCheck.Name = "OpenFolderCheck";
            this.OpenFolderCheck.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.OpenFolderCheck.Size = new System.Drawing.Size(142, 17);
            this.OpenFolderCheck.TabIndex = 21;
            this.OpenFolderCheck.Text = "Open folder on complete";
            this.OpenFolderCheck.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.panel1.Location = new System.Drawing.Point(-3, 255);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(779, 100);
            this.panel1.TabIndex = 22;
            // 
            // groupBox2
            // 
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(18, 51);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(162, 127);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Deploy";
            // 
            // groupBox3
            // 
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox3.Location = new System.Drawing.Point(187, 51);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(274, 127);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "FTP manager";
            // 
            // IncludeLauncherCheckbox
            // 
            this.IncludeLauncherCheckbox.AutoSize = true;
            this.IncludeLauncherCheckbox.Checked = true;
            this.IncludeLauncherCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.IncludeLauncherCheckbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.IncludeLauncherCheckbox.Location = new System.Drawing.Point(577, 171);
            this.IncludeLauncherCheckbox.Name = "IncludeLauncherCheckbox";
            this.IncludeLauncherCheckbox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.IncludeLauncherCheckbox.Size = new System.Drawing.Size(187, 17);
            this.IncludeLauncherCheckbox.TabIndex = 25;
            this.IncludeLauncherCheckbox.Text = "Include Launcher for self-updating";
            this.IncludeLauncherCheckbox.UseVisualStyleBackColor = true;
            // 
            // PatchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.ClientSize = new System.Drawing.Size(772, 353);
            this.Controls.Add(this.IncludeLauncherCheckbox);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.OpenFolderCheck);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Compression);
            this.Controls.Add(this.BuildText);
            this.Controls.Add(this.MaintenanceText);
            this.Controls.Add(this.MinorText);
            this.Controls.Add(this.LastVersionLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CoreVersionLabel);
            this.Controls.Add(this.PatchesBuilderVersionLabel);
            this.Controls.Add(this.MajorText);
            this.Controls.Add(this.ToVersion);
            this.Controls.Add(this.FromVersion);
            this.Controls.Add(this.DetailsDebug);
            this.Controls.Add(this.MainDebug);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.NewVersion);
            this.Controls.Add(this.BuildButton);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PatchForm";
            this.Text = "P.A.T.C.H. - Admin patches builder";
            this.Load += new System.EventHandler(this.PatchForm_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PatchForm_MouseDown);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BuildButton;
        private System.Windows.Forms.Button NewVersion;
        public System.Windows.Forms.ProgressBar ProgressBar;
        public System.Windows.Forms.TextBox MainDebug;
        public System.Windows.Forms.TextBox DetailsDebug;
        public System.Windows.Forms.ComboBox FromVersion;
        public System.Windows.Forms.ComboBox ToVersion;
        public System.Windows.Forms.TextBox MajorText;
        private System.Windows.Forms.Button EncryptConfigButton;
        private System.Windows.Forms.Button CreateConfigButton;
        private System.Windows.Forms.Label PatchesBuilderVersionLabel;
        private System.Windows.Forms.Label CoreVersionLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LastVersionLabel;
        public System.Windows.Forms.TextBox MinorText;
        public System.Windows.Forms.TextBox MaintenanceText;
        public System.Windows.Forms.TextBox BuildText;
        public System.Windows.Forms.ComboBox Compression;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox OpenFolderCheck;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox IncludeLauncherCheckbox;
    }
}

