﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;
using System.Reflection;
using System.Runtime.InteropServices;
using MHLab.PATCH;
using MHLab.PATCH.Settings;
using MHLab.PATCH.Utilities;
using MHLab.PATCH.Debugging;

namespace MHLab.PATCH.Admin
{
    public partial class PatchForm : Form
    {
        protected enum PatchBuilderStatus
        {
            IDLE,
            IS_BUILDING
        }

        PatchManager m_patchManager;

        private PatchBuilderStatus m_patchBuilderStatus;

        public PatchForm()
        {
            InitializeComponent();

            m_patchBuilderStatus = PatchBuilderStatus.IDLE;

            m_patchManager = new PatchManager();

            LastVersionLabel.Text = m_patchManager.GetLastVersion();
            PatchesBuilderVersionLabel.Text += Assembly.GetExecutingAssembly().GetName().Version.ToString();
            CoreVersionLabel.Text += Utility.GetVersion();

            if (!FileManager.FileExists(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "config.xml"))
                this.EncryptConfigButton.Enabled = false;

            m_patchManager.SetOnSetMainProgressBarAction(OnSetMainProgressBar);
            m_patchManager.SetOnSetDetailProgressBarAction(OnSetDetailProgressBar);
            m_patchManager.SetOnIncreaseMainProgressBarAction(OnIncreaseMainProgressBar);
            m_patchManager.SetOnIncreaseDetailProgressBarAction(OnIncreaseDetailProgressBar);
            m_patchManager.SetOnLogAction(OnLog);
            m_patchManager.SetOnErrorAction(OnError);
            m_patchManager.SetOnFatalErrorAction(OnFatalError);
            m_patchManager.SetOnTaskStartedAction(OnTaskStarted);
            m_patchManager.SetOnTaskCompletedAction(OnTaskCompleted);
        }

        #region Callbacks for New version
        void OnSetMainProgressBar(int min, int max)
        {
            this.ProgressBar.BeginInvoke((MethodInvoker)delegate() 
            {
                this.ProgressBar.Maximum = max;
                this.ProgressBar.Minimum = min;
                this.ProgressBar.Step = 1;

                this.ProgressBar.Value = 0;
            });
        }

        void OnSetDetailProgressBar(int min, int max)
        {
            // Add your eventual code here
        }

        void OnIncreaseMainProgressBar()
        {
            this.ProgressBar.BeginInvoke((MethodInvoker)delegate()
            {
                this.ProgressBar.PerformStep();
            });
        }

        void OnIncreaseDetailProgressBar()
        {
            // Add your eventual code here
        }

        void OnLog(string main, string detail)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate()
            {
                this.MainDebug.Text = main;
                this.DetailsDebug.Text = detail;
            });
        }

        void OnError(string main, string detail, Exception e)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate()
            {
                this.MainDebug.Text = main;
                this.DetailsDebug.Text = detail;
                Debugger.Log(e.Message);
            });
        }

        void OnFatalError(string main, string detail, Exception e)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate()
            {
                this.MainDebug.Text = main;
                this.DetailsDebug.Text = detail;
                Debugger.Log(e.Message);
            });
        }

        void OnTaskStarted(string message)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate()
            {
                m_patchBuilderStatus = PatchBuilderStatus.IS_BUILDING;
                this.MainDebug.Text = message;
                this.DetailsDebug.Text = "";
                ToggleBuildPatchComponents(false);
                ToggleNewVersionComponents(false);
            });
        }

        void OnTaskCompleted(string message)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate()
            {
                LastVersionLabel.Text = m_patchManager.GetLastVersion();
                /*_currentVersions = m_patchManager.GetCurrentVersions();
                UpdateLastVersionGUI(_lastVersion);*/
                this.MainDebug.Text = message;
                m_patchBuilderStatus = PatchBuilderStatus.IDLE;

                if(OpenFolderCheck.Checked)
                    System.Diagnostics.Process.Start(SettingsManager.BUILDS_PATH);

                CleanComponents();
                BindVersions();
                ToggleBuildPatchComponents(true);
                ToggleNewVersionComponents(true);
            });
        }

        void OnTaskCompletedPatchBuilding(string message)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate()
            {
                /*_currentVersions = m_patchManager.GetCurrentVersions();
                UpdateLastVersionGUI(_lastVersion);*/
                this.MainDebug.Text = message;
                m_patchBuilderStatus = PatchBuilderStatus.IDLE;

                if (OpenFolderCheck.Checked)
                    System.Diagnostics.Process.Start(SettingsManager.FINAL_PATCHES_PATH);

                CleanComponents();
                BindVersions();
                ToggleBuildPatchComponents(true);
                ToggleNewVersionComponents(true);
            });
        }
        #endregion

        private void NewVersion_Click(object sender, EventArgs e)
        {
            m_patchManager.SetOnTaskCompletedAction(OnTaskCompleted);
            string NewVersion = MajorText.Text + "." + MinorText.Text + "." + MaintenanceText.Text + "." + BuildText.Text;
            try
            {
                Version v = new Version(NewVersion);

                if(IncludeLauncherCheckbox.Checked)
                {
                    IEnumerable<string> files = FileManager.GetFiles(SettingsManager.PATCHER_FILES_PATH, "*", SearchOption.AllDirectories);
                    foreach (string entry in files)
                    {
                        string currentFile = entry.Replace(SettingsManager.PATCHER_FILES_PATH, SettingsManager.CURRENT_BUILD_PATH);
                        if (!FileManager.FileExists(currentFile))
                            if (!FileManager.DirectoryExists(Path.GetDirectoryName(currentFile)))
                                FileManager.CreateDirectory(Path.GetDirectoryName(currentFile));
                        FileManager.FileCopy(entry, currentFile, false);
                    }

                    string configFile = SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "Encrypted" + Path.DirectorySeparatorChar + "config";

                    if (FileManager.FileExists(configFile))
                    {
                        if (!FileManager.FileExists(FileManager.PathCombine(SettingsManager.CURRENT_BUILD_PATH, Path.GetFileName(configFile))))
                            FileManager.FileCopy(configFile, FileManager.PathCombine(SettingsManager.CURRENT_BUILD_PATH, Path.GetFileName(configFile)), false);
                    }
                }

                Thread buildThread = new Thread(new ThreadStart(() => m_patchManager.BuildNewVersion(v.ToString())));
                buildThread.IsBackground = true;
                buildThread.Start();
            }
            catch (Exception ex)
            {
                Debugger.Log(ex.Message);
            }
        }

        private void BindVersions()
        {
            List<string> versions = new List<string>();
            versions.Add(" ");
            versions.AddRange(m_patchManager.GetVersions());
            this.FromVersion.DataSource = versions.Distinct().ToList();
            this.ToVersion.DataSource = versions.Distinct().ToList();
        }

        private void CleanComponents()
        {
            FromVersion.SelectedIndex = 0;
            ToVersion.SelectedIndex = 0;

            string lastVersion = m_patchManager.GetLastVersion();
            if (lastVersion != null && lastVersion != "none")
            {
                Version v = new Version(lastVersion);
                MajorText.Text = v.Major.ToString();
                MinorText.Text = v.Minor.ToString();
                MaintenanceText.Text = v.Revision.ToString();
                BuildText.Text = (v.Build + 1).ToString();
            }
            ToggleNewVersionComponents(true);
        }

        private void ToggleButtons(bool value)
        {
            BuildButton.Enabled = value;
            NewVersion.Enabled = value;
        }

        private void ToggleNewVersionComponents(bool value)
        {
            MajorText.Enabled = value;
            MinorText.Enabled = value;
            MaintenanceText.Enabled = value;
            BuildText.Enabled = value;
            NewVersion.Enabled = value;
        }

        private void ToggleBuildPatchComponents(bool value)
        {
            BuildButton.Enabled = value;
            FromVersion.Enabled = value;
            ToVersion.Enabled = value;
        }

        private void NewVersionName_TextChanged(object sender, EventArgs e)
        {
            MajorText.Text = MajorText.Text.Trim();
            if (MajorText.Text == "")
            {
                ToggleNewVersionComponents(true);
                ToggleBuildPatchComponents(true);
                ToggleButtons(false);
            }
            else
            {
                ToggleNewVersionComponents(true);
                ToggleBuildPatchComponents(false);
            }
        }

        private void ToVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((string)ToVersion.SelectedItem == " ")
            {
                ToggleButtons(false);
                ToggleNewVersionComponents(true);
                ToggleBuildPatchComponents(true);
            }
            else
            {
                ToggleButtons(false);
                ToggleNewVersionComponents(false);
                ToggleBuildPatchComponents(true);
                if ((string)FromVersion.SelectedItem != " " && (string)FromVersion.SelectedItem != "" && (string)FromVersion.SelectedItem != null)
                    BuildButton.Enabled = true;
                else
                    BuildButton.Enabled = false;
            }
        }

        private void FromVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((string)FromVersion.SelectedItem == " ")
            {
                ToggleButtons(false);
                ToggleNewVersionComponents(true);
                ToggleBuildPatchComponents(true);
            }
            else
            {
                ToggleButtons(false);
                ToggleNewVersionComponents(false);
                ToggleBuildPatchComponents(true);
                if ((string)ToVersion.SelectedItem != " " && (string)ToVersion.SelectedItem != "" && (string)ToVersion.SelectedItem != null)
                    BuildButton.Enabled = true;
                else
                    BuildButton.Enabled = false;
            }
        }

        private void PatchForm_Load(object sender, EventArgs e)
        {
            Compression.SelectedIndex = 0;
            BindVersions();
            CleanComponents();
        }

        private void BuildButton_Click(object sender, EventArgs e)
        {
            ToggleBuildPatchComponents(false);
            ToggleNewVersionComponents(false);
            m_patchManager.SetOnTaskCompletedAction(OnTaskCompletedPatchBuilding);
            
            Thread buildThread = new Thread(new ThreadStart(BuildPatch));
            buildThread.IsBackground = true;
            buildThread.Start();
        }

        private void BuildPatch()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            try
            {
                string from = "";
                string to = "";
                from = (string)FromVersion.SelectedItem;
                to = (string)ToVersion.SelectedItem;
                
                m_patchManager.BuildPatch(from, to, (PATCH.Compression.CompressionType)Enum.Parse(typeof(PATCH.Compression.CompressionType), Compression.Text));
            }
            catch (Exception ex)
            {
                Debugger. Log(ex.Message);
            }

            CleanComponents();
            ToggleBuildPatchComponents(true);
            ToggleNewVersionComponents(true);
            ToggleButtons(false);
            Control.CheckForIllegalCrossThreadCalls = true;
        }

        private void EncryptConfigButton_Click(object sender, EventArgs e)
        {
            try
            {
                FileManager.CreateDirectory(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH);
                string plainFile = File.ReadAllText(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "config.xml");
                string crypted = Rijndael.Encrypt(plainFile, SettingsManager.PATCH_VERSION_ENCRYPTION_PASSWORD);

                FileManager.CreateDirectory(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "Encrypted");
                File.WriteAllText(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "Encrypted" + Path.DirectorySeparatorChar + "config", crypted);

                this.MainDebug.Text = "Config encrypted!";
                this.DetailsDebug.Text = "Config file successfully encrypted! You can find it in your \"config\\Encrypted\" directory!";
            }
            catch(Exception ex)
            {
                this.MainDebug.Text = "Config error!";
                this.DetailsDebug.Text = "Failed to encrypt config! " + ex.Message;
            }
        }

        private void CreateConfigButton_Click(object sender, EventArgs e)
        {
            try
            {
                SettingsOverrider set = new SettingsOverrider();
                XmlSerializer ser = new XmlSerializer(set.GetType());
                FileManager.CreateDirectory(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH);
                using (TextWriter writer = new StreamWriter(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "config.xml"))
                    ser.Serialize(writer, set);

                if (FileManager.FileExists(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "config.xml"))
                    this.EncryptConfigButton.Enabled = true;

                this.MainDebug.Text = "Config created!";
                this.DetailsDebug.Text = "Config plain file successfully created! You can find it in your \"config\" directory!";
            }
            catch (Exception ex)
            {
                this.MainDebug.Text = "Config error!";
                this.DetailsDebug.Text = "Failed to create plain config! " + ex.Message;
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void PatchForm_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
    }
}
