﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.Reflection;
using System.IO;
using System.Threading;
using MHLab.PATCH;
using MHLab.PATCH.Settings;
using MHLab.PATCH.Utilities;
using MHLab.PATCH.Debugging;

namespace MHLab.PATCH.Admin
{
    public class Command
    {
        public string MainCommand;
        public List<string> Parameters;

        public Command(string command, params string[] parameters)
        {
            Parameters = new List<string>();
            MainCommand = command;
            foreach(string s in parameters)
            {
                Parameters.Add(s);
            }
        }
    }

    public class PatchCommandLine
    {
        PatchManager m_patchManager;

        public PatchCommandLine(string[] args)
        {
            m_patchManager = new PatchManager();
            m_patchManager.SetOnLogAction(OnLog);
            m_patchManager.SetOnErrorAction(OnError);
            m_patchManager.SetOnFatalErrorAction(OnFatalError);
            m_patchManager.SetOnTaskStartedAction(OnTaskStarted);
            m_patchManager.SetOnTaskCompletedAction(OnTaskCompleted);

            if(args.Length < 1)
            {
                Console.WriteLine("No commands found! Be sure to write a command or type -help to visualize available commands!");
                return;
            }

            string command = args[0];
            switch(command)
            {
                case "-help":
                    {
                        Console.WriteLine("Welcome in P.A.T.C.H. - Command Line Tool, check available commands:");
                        Console.WriteLine("\t-build versionName => Example: -build 2.5.0.6");
                        Console.WriteLine("\t-patch versionFrom versionTo compression => Example: -patch 2.5.0.6 2.5.0.7 ZIP");
                        Console.WriteLine("\t-config -create");
                        Console.WriteLine("\t-config -encrypt");
                    }
                    break;
                case "-config":
                    {
                        if (args.Length < 2)
                        {
                            Console.WriteLine("No parameter found! Be sure to write it or type -help to visualize available commands!");
                            return;
                        }

                        string secondary = args[1];
                        if (secondary == "-create")
                            CreateConfig();
                        if (secondary == "-encrypt")
                            EncryptConfig();
                    }
                    break;
                case "-build":
                    {
                        if (args.Length < 2)
                        {
                            Console.WriteLine("No version parameter found! Be sure to write it or type -help to visualize available commands!");
                            return;
                        }
                        string param = args[1];
                        if (args[1] == "auto")
                            param = m_patchManager.GetNextVersion();

                        Command c = new Command(command, param);
                        Build(c);
                    }
                    break;
                case "-patch":
                    {
                        if (args.Length < 4)
                        {
                            Console.WriteLine("No parameters found! Be sure to write them or type -help to visualize available commands!");
                            return;
                        }
                        List<string> versions = m_patchManager.GetVersions();
                        if(versions.Count < 2)
                        {
                            Console.WriteLine("Not enough builds found! Be sure to have atleast two builds in your \"builds\" folder!");
                            return;
                        }

                        if(args[3] != "ZIP" && args[3] != "TAR" && args[3] != "TARGZ")
                        {
                            Console.WriteLine("Not supported compression type!");
                            return;
                        }

                        string param1 = args[1];
                        if (args[1] == "previous")
                            param1 = versions[versions.Count - 2];
                        string param2 = args[2];
                        if (args[2] == "current")
                            param2 = versions[versions.Count - 1];
                        Command c = new Command(command, param1, param2, args[3]);
                        Patch(c);
                    }
                    break;
                default:
                    {
                        Console.WriteLine("No commands found! Be sure to write a valid command or type -help to visualize available commands!");
                    }
                    break;
            }
        }

        #region Callbacks for New version

        void OnLog(string main, string detail)
        {
            Console.WriteLine("[LOG] " + main + " - " + detail);
        }

        void OnError(string main, string detail, Exception e)
        {
            Console.WriteLine("[ERROR] " + main + " - " + detail);
            Debugger.Log(e.Message);
        }

        void OnFatalError(string main, string detail, Exception e)
        {
            Console.WriteLine("[FATAL] " + main + " - " + detail);
            Debugger.Log(e.Message);
        }

        void OnTaskStarted(string message)
        {
            
        }

        void OnTaskCompleted(string message)
        {
            Console.WriteLine("[COMPLETED] " + message);
        }

        void OnTaskCompletedPatchBuilding(string message)
        {
            Console.WriteLine("[COMPLETED] " + message);
        }
        #endregion

        private void Build(Command command)
        {
            string NewVersion = command.Parameters[0];
            try
            {
                Version v = new Version(NewVersion);
                
                IEnumerable<string> files = FileManager.GetFiles(SettingsManager.PATCHER_FILES_PATH, "*", SearchOption.AllDirectories);
                foreach (string entry in files)
                {
                    string currentFile = entry.Replace(SettingsManager.PATCHER_FILES_PATH, SettingsManager.CURRENT_BUILD_PATH);
                    if (!FileManager.FileExists(currentFile))
                        if (!FileManager.DirectoryExists(Path.GetDirectoryName(currentFile)))
                            FileManager.CreateDirectory(Path.GetDirectoryName(currentFile));
                    FileManager.FileCopy(entry, currentFile, false);
                }

                string configFile = SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "Encrypted" + Path.DirectorySeparatorChar + "config";

                if (FileManager.FileExists(configFile))
                {
                    if (!FileManager.FileExists(FileManager.PathCombine(SettingsManager.CURRENT_BUILD_PATH, Path.GetFileName(configFile))))
                        FileManager.FileCopy(configFile, FileManager.PathCombine(SettingsManager.CURRENT_BUILD_PATH, Path.GetFileName(configFile)), false);
                }

                Thread buildThread = new Thread(new ThreadStart(() => m_patchManager.BuildNewVersion(v.ToString())));
                buildThread.IsBackground = false;
                buildThread.Start();
            }
            catch (Exception ex)
            {
                Debugger.Log(ex.Message);
            }
        }

        private void Patch(Command command)
        {
            try
            {
                string from = "";
                string to = "";
                from = (string)command.Parameters[0];
                to = (string)command.Parameters[1];

                Thread buildThread = new Thread(new ThreadStart(() => m_patchManager.BuildPatch(from, to, (PATCH.Compression.CompressionType)Enum.Parse(typeof(PATCH.Compression.CompressionType), (string)command.Parameters[2]))));
                buildThread.IsBackground = false;
                buildThread.Start();
            }
            catch (Exception ex)
            {
                Debugger.Log(ex.Message);
            }
        }

        private void EncryptConfig()
        {
            try
            {
                FileManager.CreateDirectory(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH);
                string plainFile = File.ReadAllText(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "config.xml");
                string crypted = Rijndael.Encrypt(plainFile, SettingsManager.PATCH_VERSION_ENCRYPTION_PASSWORD);

                FileManager.CreateDirectory(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "Encrypted");
                File.WriteAllText(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "Encrypted" + Path.DirectorySeparatorChar + "config", crypted);

                Console.WriteLine("Config encrypted!");
                Console.WriteLine("Config file successfully encrypted! You can find it in your \"config\\Encrypted\" directory!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Config error!");
                Console.WriteLine("Failed to encrypt config! " + ex.Message);
            }
        }

        private void CreateConfig()
        {
            try
            {
                SettingsOverrider set = new SettingsOverrider();
                XmlSerializer ser = new XmlSerializer(set.GetType());
                FileManager.CreateDirectory(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH);
                using (TextWriter writer = new StreamWriter(SettingsManager.LAUNCHER_CONFIG_GENERATION_PATH + Path.DirectorySeparatorChar + "config.xml"))
                    ser.Serialize(writer, set);


                Console.WriteLine("Config created!");
                Console.WriteLine("Config plain file successfully created! You can find it in your \"config\" directory!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Config error!");
                Console.WriteLine("Failed to create plain config! " + ex.Message);
            }
        }
    }
}
