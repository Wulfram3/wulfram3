﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MHLab.PATCH.Admin
{
    public class Program
    {
        static void Main(string[] args)
        {
            PatchCommandLine cmd = new PatchCommandLine(args);
        }
    }
}
