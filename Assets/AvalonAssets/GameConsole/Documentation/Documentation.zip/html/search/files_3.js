var searchData=
[
  ['namespace_2etxt',['namespace.txt',['../namespace_8txt.html',1,'']]]
];
