﻿using HutongGames.PlayMaker;

using UnityEngine;

using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Creates a new GameObjectPool pool.")]
	public class CreateGameObjectPool : FsmStateAction {

		[RequiredField]
		[Tooltip("The GameObject to create the pool component on.")]
		public FsmOwnerDefault Container;

		[Tooltip("Whether to initialise the pool in the Start method.")]
		public FsmBool InitialiseOnStart;

		[Tooltip("The level of log messaging that the pool will output.")]
		[ObjectType(typeof(LogLevel))]
		public FsmEnum LogMessages;

		[Tooltip("The modes in which pooled objects are notified of their acquisition from, and release to, the pool.")]
		[ObjectType(typeof(NotificationMode))]
		public FsmEnum NotificationMode;

		[Tooltip("Whether the pool should persist between scene changes.")]
		public FsmBool DontDestroyOnLoad;

		[Tooltip("Whether the pool should instantiate a new object when the pool is empty, and an attempt is made to acquire from the pool.")]
		public FsmBool InstantiateWhenEmpty;

		[Tooltip("Whether to re-parent the pooled objects to the pool's transform, after the objects are released.")]
		public FsmBool ReparentPooledObjects;

		[Tooltip("Whether to record pool statistics.")]
		public FsmBool RecordStatistics;

		[RequiredField]
		[Tooltip("The source object that is being pooled.")]
		public FsmGameObject SourceObject;

		[Tooltip("The initial size of the pool.")]
		public FsmInt InitialPoolSize;

		[Tooltip("The maximum size of the pool, which is the maximum number of objects it can contain.")]
		public FsmInt MaximumPoolSize;

		[UIHint(UIHint.Variable)]
		[ObjectType(typeof(GameObjectPool))]
		[Tooltip("The newly-created GameObjectPool.")]
		public FsmObject Pool;
		
		public override void Reset() {
			this.Container = null;
			this.InitialiseOnStart = GameObjectPoolSettings.DefaultSettings.InitialiseOnStart;
			this.LogMessages = GameObjectPoolSettings.DefaultSettings.LogMessages;
			this.NotificationMode = new FsmEnum { UseVariable = false, Value = GameObjectPoolSettings.DefaultSettings.NotificationMode };
			this.DontDestroyOnLoad = GameObjectPoolSettings.DefaultSettings.DontDestroyOnLoad;
			this.InstantiateWhenEmpty = GameObjectPoolSettings.DefaultSettings.InstantiateWhenEmpty;
			this.SourceObject = null;
			this.InitialPoolSize = GameObjectPoolSettings.DefaultSettings.InitialSize;
			this.MaximumPoolSize = GameObjectPoolSettings.DefaultSettings.MaximumSize;
			this.ReparentPooledObjects = GameObjectPoolSettings.DefaultSettings.ReparentPooledObjects;
			this.RecordStatistics = GameObjectPoolSettings.DefaultSettings.RecordStatistics;
			this.Pool = null;
		}

		public override void OnEnter() {
			GameObject container = this.Fsm.GetOwnerDefaultTarget(this.Container);
			
			if (container != null && !this.SourceObject.IsNone && this.SourceObject.Value != null) {
				var pool = container.AddComponent<GameObjectPool>();
				pool.Source = this.SourceObject.Value;
				
				if (!this.InitialiseOnStart.IsNone) {
					pool.InitialiseOnStart = this.InitialiseOnStart.Value;
				}
				if (!this.LogMessages.IsNone) {
					pool.LogMessages = (LogLevel)this.LogMessages.Value;
				}
				if (!this.NotificationMode.IsNone) {
					pool.NotificationMode = (NotificationMode)this.NotificationMode.Value;
				}
				if (!this.DontDestroyOnLoad.IsNone) {
					pool.DontDestroyOnLoad = this.DontDestroyOnLoad.Value;
				}
				if (!this.InstantiateWhenEmpty.IsNone) {
					pool.InstantiateWhenEmpty = this.InstantiateWhenEmpty.Value;
				}
				if (!this.InitialPoolSize.IsNone) {
					pool.InitialSize = this.InitialPoolSize.Value;
				}
				if (!this.MaximumPoolSize.IsNone) {
					pool.MaximumSize = this.MaximumPoolSize.Value;
				}
				if (!this.ReparentPooledObjects.IsNone) {
					pool.ReparentPooledObjects = this.ReparentPooledObjects.Value;
				}
				if (!this.RecordStatistics.IsNone) {
					pool.RecordStatistics = this.RecordStatistics.Value;
				}

				if (!this.Pool.IsNone) {
					this.Pool.Value = pool;
				}
			}

			this.Finish();
		}

	}

}