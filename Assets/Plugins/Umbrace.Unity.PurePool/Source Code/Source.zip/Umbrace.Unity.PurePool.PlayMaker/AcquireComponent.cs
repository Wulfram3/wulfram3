﻿using System;

using HutongGames.PlayMaker;

using UnityEngine;

using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Acquires an instance of a Component from a pool.")]
	public class AcquireComponent : FsmStateAction {

		[ObjectType(typeof(ComponentPool))]
		[Tooltip("The pool from which to acquire an instance of a Component.")]
		public FsmObject Pool;

		[ObjectType(typeof(ComponentPoolManager))]
		[Tooltip("The pool manager from which to acquire an instance of a Component.")]
		public FsmObject Manager;

		[UIHint(UIHint.ScriptComponent)]
		[Title("Component Type"), Tooltip("The type of component to acquire from the pool manager.")]
		public FsmString SourceComponent;

		[Tooltip("The optional parent transform that the acquired instance should be parented to.")]
		public FsmGameObject Parent;

		[Tooltip("The optional position at which to place the acquired instance. If Parent is defined, this is used as a local offset from the Parent position.")]
		public FsmVector3 Position;

		[Tooltip("The optional rotation at which to place the acquired instance. NOTE: Overrides the rotation of the Parent.")]
		public FsmVector3 Rotation;

		[UIHint(UIHint.Variable)]
		[ObjectType(typeof(Component))]
		[Tooltip("The instance that was acquired from the pool.")]
		public FsmObject Instance;

		public override void OnEnter() {
			Transform parent = null;
			var position = Vector3.zero;
			var rotation = Vector3.zero;

			if (!this.Parent.IsNone && this.Parent.Value != null) {
				parent = this.Parent.Value.transform;
				position = this.Parent.Value.transform.position;

				if (!this.Position.IsNone) {
					position += this.Position.Value;
				}

				rotation = !this.Rotation.IsNone ? this.Rotation.Value : this.Parent.Value.transform.eulerAngles;
			} else {
				if (!this.Position.IsNone) {
					position = this.Position.Value;
				}

				if (!this.Rotation.IsNone) {
					rotation = this.Rotation.Value;
				}
			}

			if (this.Instance.IsNone) {
				this.LogWarning($"{nameof(this.Instance)} not set.");
			} else if (!this.Pool.IsNone && this.Pool.Value != null) {
				this.AcquireFromPool(parent, position, rotation);
			} else if (!this.Manager.IsNone && this.Manager.Value != null && !this.SourceComponent.IsNone && !string.IsNullOrEmpty(this.SourceComponent.Value)) {
				this.AcquireFromManager(parent, position, rotation);
			} else {
				this.LogWarning($"{nameof(this.Pool)}, {nameof(this.Manager)} or {nameof(this.SourceComponent)} not set.");
			}

			this.Finish();
		}

		private void AcquireFromPool(Transform parent, Vector3 position, Vector3 rotation) {
			var pool = (ComponentPool)this.Pool.Value;

			if (pool.IsInitialised) {
				Component instance;
				if (pool.TryAcquire(parent, position, Quaternion.Euler(rotation), out instance)) {
					this.Instance.Value = instance;
				}
			} else {
				this.LogWarning("The pool must be initialised before an object can be acquired from it.");
			}
		}

		private void AcquireFromManager(Transform parent, Vector3 position, Vector3 rotation) {
			var manager = (ComponentPoolManager)this.Manager.Value;
			Type componentType = ReflectionUtils.GetGlobalType(this.SourceComponent.Value);

			Component instance;
			if (manager.TryAcquire(componentType, parent, position, Quaternion.Euler(rotation), out instance)) {
				this.Instance.Value = instance;
			}
		}

		public override void Reset() {
			this.Pool = null;
			this.Manager = null;
			this.SourceComponent = null;
			this.Parent = null;
			this.Position = null;
			this.Rotation = null;
			this.Instance = null;
		}

		public override string ErrorCheck() {
			bool poolNotSet = this.Pool.IsNone || (!this.Pool.UsesVariable && this.Pool.Value == null);
			bool managerNotSet = this.Manager.IsNone || (!this.Manager.UsesVariable && this.Manager.Value == null);
			bool sourceNotSet = this.SourceComponent.IsNone || (!this.SourceComponent.UsesVariable && string.IsNullOrEmpty(this.SourceComponent.Value));

			if (!(poolNotSet ^ managerNotSet) || managerNotSet != sourceNotSet) return $"Either {nameof(this.Pool)}, or {nameof(this.Manager)} and {nameof(this.SourceComponent)} must be set (not both).";

			return null;
		}

	}

}