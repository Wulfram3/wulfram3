﻿using HutongGames.PlayMaker;

using UnityEngine;

using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Acquires an instance of a GameObject from a pool.")]
	public class AcquireGameObject : FsmStateAction {

		[RequiredField]
		[ObjectType(typeof(GameObjectPool))]
		[Tooltip("The pool from which to acquire an instance of a GameObject.")]
		public FsmObject Pool;

		[Tooltip("The optional parent transform that the acquired instance should be parented to.")]
		public FsmGameObject Parent;

		[Tooltip("The optional position at which to place the acquired instance. If Parent is defined, this is used as a local offset from the Parent position.")]
		public FsmVector3 Position;

		[Tooltip("The optional rotation at which to place the acquired instance. NOTE: Overrides the rotation of the Parent.")]
		public FsmVector3 Rotation;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("The instance that was acquired from the pool.")]
		public FsmGameObject Instance;

		public override void OnEnter() {
			if (!this.Pool.IsNone && this.Pool.Value != null && !this.Instance.IsNone) {
				var pool = (GameObjectPool)this.Pool.Value;

				if (pool.IsInitialised) {
					Transform parent = null;
					var position = Vector3.zero;
					var rotation = Vector3.zero;

					if (!this.Parent.IsNone && this.Parent.Value != null) {
						parent = this.Parent.Value.transform;
						position = this.Parent.Value.transform.position;

						if (!this.Position.IsNone) {
							position += this.Position.Value;
						}

						rotation = !this.Rotation.IsNone ? this.Rotation.Value : this.Parent.Value.transform.eulerAngles;
					} else {
						if (!this.Position.IsNone) {
							position = this.Position.Value;
						}

						if (!this.Rotation.IsNone) {
							rotation = this.Rotation.Value;
						}
					}
					
					GameObject go;
					if (pool.TryAcquire(position, Quaternion.Euler(rotation), parent, out go)) {
						this.Instance.Value = go;
					}
				} else {
					this.LogWarning("The pool must be initialised before an object can be acquired from it.");
				}
			} else {
				this.LogWarning($"{nameof(this.Pool)} or {nameof(this.Instance)} not set.");
			}

			this.Finish();
		}

		public override void Reset() {
			this.Pool = null;
			this.Parent = null;
			this.Position = null;
			this.Rotation = null;
			this.Instance = null;
		}
		
	}

}