﻿using HutongGames.PlayMaker;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Releases an instance of a GameObject to its pool.")]
	public class ReleaseGameObject : FsmStateAction {

		[RequiredField]
		[ObjectType(typeof(GameObjectPool))]
		[Tooltip("The pool to which an instance of a GameObject should be released.")]
		public FsmObject Pool;

		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The instance that is being returned to the pool.")]
		public FsmGameObject Instance;

		public override void OnEnter() {
			if (!this.Pool.IsNone && this.Pool.Value != null && !this.Instance.IsNone && this.Instance.Value != null) {
				var pool = (GameObjectPool)this.Pool.Value;

				if (pool.IsInitialised) {
					pool.Release(this.Instance.Value);
				} else {
					this.LogError("The pool must be initialised before an object can be released to it.");
				}
			}

			this.Finish();
		}

		public override void Reset() {
			this.Pool = null;
			this.Instance = null;
		}

	}

}