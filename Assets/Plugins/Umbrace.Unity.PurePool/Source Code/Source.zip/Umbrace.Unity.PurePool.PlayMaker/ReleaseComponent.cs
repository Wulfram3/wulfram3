﻿using HutongGames.PlayMaker;

using UnityEngine;

using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Releases an instance of a Component to its pool.")]
	public class ReleaseComponent : FsmStateAction {

		[RequiredField]
		[ObjectType(typeof(ComponentPool))]
		[Tooltip("The pool to which an instance of a Component should be released.")]
		public FsmObject Pool;

		[RequiredField]
		[UIHint(UIHint.Variable)]
		[ObjectType(typeof(Component))]
		[Tooltip("The instance that is being returned to the pool.")]
		public FsmObject Instance;

		public override void OnEnter() {
			if (!this.Pool.IsNone && this.Pool.Value != null && !this.Instance.IsNone && this.Instance.Value != null) {
				var pool = (ComponentPool)this.Pool.Value;

				if (pool.IsInitialised) {
					pool.Release((Component)this.Instance.Value);
				} else {
					this.LogError("The pool must be initialised before an object can be released to it.");
				}
			}

			this.Finish();
		}

		public override void Reset() {
			this.Pool = null;
			this.Instance = null;
		}

	}

}