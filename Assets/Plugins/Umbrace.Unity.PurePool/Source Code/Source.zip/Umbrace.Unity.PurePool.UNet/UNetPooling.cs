﻿using System;
using System.Collections.Generic;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEngine;
using UnityEngine.Networking;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool.UNet {

	/// <summary>
	/// An integration component that allows UNET networking to utilise object pooling.
	/// </summary>
	[AddComponentMenu("Scripts/Umbrace.Unity.PurePool.UNet/UNet Pooling")]
	public class UNetPooling : MonoBehaviour {

		#region Inner classes.
		[Serializable]
		private class NetworkHash128ToGameObjectDictionary : SerialisableDictionary<NetworkHash128, GameObject> { }
		#endregion

		#region Public editor variables.
		/// <summary>
		/// The <see cref="GameObjectPoolManager"/> responsible for managing the pools.
		/// </summary>
		[Tooltip("The " + nameof(GameObjectPoolManager) + " responsible for managing the pools.")]
		public GameObjectPoolManager PoolManager;

		/// <summary>
		/// A value indicating whether to automatically register prefabs with <see cref="ClientScene"/> when pools are initialised by the manager.
		/// </summary>
		[Tooltip("A value indicating whether to automatically register prefabs with " + nameof(ClientScene) + " when pools are initialised by the manager.")]
		public bool AutoRegister;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets a dictionary of game objects that have been registered for spawning with pooling support.
		/// </summary>
		/// <remarks>
		/// This dictionary is updated when <see cref="RegisterSpawnHandler(GameObject)"/> is called.
		/// It contains a mapping from the asset ID of the game object's <see cref="NetworkIdentity"/>, to the game object itself.
		/// </remarks>
		public IDictionary<NetworkHash128, GameObject> Prefabs => this.prefabs;
		#endregion

		#region Fields.
		private NetworkHash128ToGameObjectDictionary prefabs = new NetworkHash128ToGameObjectDictionary();
		#endregion

		#region Private methods.
		private void Awake() {
			// Handle pools that will be attached in future.
			this.PoolManager.PoolAttached += this.ManagerOnPoolAttached; // TODO: How to handle a pool that's detached and then re-attached?
			
			// Handle pools that have already been attached to the manager.
			if (this.AutoRegister) {
				foreach (GameObjectPool pool in this.PoolManager.Pools) {
					this.RegisterSpawnHandler(pool.Source);
				}
			}
		}

		/// <summary>
		/// Handles the <see cref="GameObjectPoolManager.PoolAttached"/> event.
		/// </summary>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="eventArgs">The <see cref="PoolEventArgs{TPool}"/> object containing the event data.</param>
		private void ManagerOnPoolAttached(object sender, PoolEventArgs<GameObjectPool> eventArgs) {
			GameObjectPool pool = eventArgs.Pool;

			if (this.AutoRegister) {
				this.RegisterSpawnHandler(pool.Source);
			}
		}
		#endregion

		#region Public methods.
		/// <summary>
		/// Spawns a <see cref="GameObject"/> that's been registered with <see cref="ClientScene"/>, with pooling support.
		/// </summary>
		/// <param name="position">The position to spawn the object at.</param>
		/// <param name="assetId">The asset ID of the object to spawn.</param>
		/// <returns>The <see cref="GameObject"/> that was spawned.</returns>
		/// <remarks>
		/// <para>
		/// This method should be passed to the <see cref="ClientScene.RegisterPrefab(GameObject,SpawnDelegate,UnSpawnDelegate)"/> or <see cref="ClientScene.RegisterSpawnHandler"/> methods.
		/// </para>
		/// <para>
		/// Objects spawned using <see cref="SpawnHandler"/> should not be destroyed manually, but instead should be passed to <see cref="UnspawnHandler"/>, to allow pooling to work.
		/// When using UNet, this means you should call <see cref="NetworkServer.UnSpawn"/> instead of <see cref="NetworkServer.Destroy"/>.
		/// </para>
		/// </remarks>
		/// <exception cref="ArgumentException">When <paramref name="assetId"/> has not been registered with <see cref="ClientScene"/>.</exception>
		/// <seealso cref="UnspawnHandler"/>
		/// <seealso cref="ClientScene.RegisterPrefab(GameObject,SpawnDelegate,UnSpawnDelegate)"/>
		/// <seealso cref="ClientScene.RegisterSpawnHandler"/>
		/// <seealso cref="NetworkServer.UnSpawn"/>
		public GameObject SpawnHandler(Vector3 position, NetworkHash128 assetId) {
			// Get the prefab from its asset ID. It must have been registered with RegisterSpawnHandler.
			GameObject prefab;

			// ClientScene doesn't keep the prefab in the prefabs dictionary when custom spawn and unspawn delegates are used.
			//if (!ClientScene.prefabs.TryGetValue(assetId, out prefab)) {
			// Instead, we use our own dictionary to look up the prefab.
			if (!this.prefabs.TryGetValue(assetId, out prefab)) {
				string message = $"{nameof(this.SpawnHandler)} invoked with an asset ID that has not been registered with {nameof(this.RegisterSpawnHandler)}. " +
								$"Prefabs and custom asset IDs should be registered with {nameof(this.RegisterSpawnHandler)}, and their asset IDs should be " +
								$"present in the {nameof(this.Prefabs)} dictionary.";
				DebugHelper.LogError(message);
				throw new ArgumentException(message, nameof(assetId));
			}

			// Try to get a pooled instance first, but if that fails just instantiate.
			GameObject instance;
			if (this.PoolManager.TryAcquire(prefab, out instance)) {
				instance.transform.position = position;
			} else {
				instance = Object.Instantiate(prefab, position, Quaternion.identity);
			}

			return instance;
		}

		/// <summary>
		/// Despawns a <see cref="GameObject"/>, with pooling support.
		/// </summary>
		/// <param name="instance">The <see cref="GameObject"/> to be despawned.</param>
		/// <remarks>
		/// This method should be passed to the <see cref="ClientScene.RegisterPrefab(GameObject,SpawnDelegate,UnSpawnDelegate)"/> or <see cref="ClientScene.RegisterSpawnHandler"/> methods.
		/// Despawning of a networked <see cref="GameObject"/> can then be performed by calling <see cref="NetworkServer.UnSpawn"/>.
		/// </remarks>
		/// <seealso cref="SpawnHandler"/>
		/// <seealso cref="ClientScene.RegisterPrefab(GameObject,SpawnDelegate,UnSpawnDelegate)"/>
		/// <seealso cref="ClientScene.RegisterSpawnHandler"/>
		/// <seealso cref="NetworkServer.UnSpawn"/>
		public void UnspawnHandler(GameObject instance) {
			this.PoolManager.Release(instance);
		}

		/// <summary>
		/// Registers pooling-based spawn handlers for all prefabs that have been registered with <see cref="ClientScene"/>.
		/// </summary>
		/// <remarks>
		/// This method replaces all <see cref="ClientScene"/> registrations that were made using
		/// <see cref="ClientScene.RegisterPrefab(GameObject)"/> without pooling support,
		/// with new registrations made using <see cref="RegisterSpawnHandler(GameObject)"/> to provide pooling support.
		/// </remarks>
		public void RegisterSpawnHandlers() {
			// Copy of the prefabs, so we can remove them from ClientScene while enumerating.
			var registeredPrefabs = ClientScene.prefabs.Values.ToArray();

			foreach (GameObject prefab in registeredPrefabs) {
				// Unregister the prefab from ClientScene first, since it was registered without pooling support.
				ClientScene.UnregisterPrefab(prefab);

				// Re-register the prefab with pooling support.
				this.RegisterSpawnHandler(prefab);
			}
		}

		/// <summary>
		/// Registers the specified prefab with the UNET spawning system, with pooling support.
		/// </summary>
		/// <remarks>
		/// This is equivalent to calling <see cref="ClientScene.RegisterPrefab(GameObject,SpawnDelegate,UnSpawnDelegate)"/>, 
		/// and passing <see cref="SpawnHandler"/> and <see cref="UnspawnHandler"/>, in addition to adding
		/// the prefab to the <see cref="Prefabs"/> dictionary.
		/// </remarks>
		/// <param name="prefab">The prefab that will be spawned.</param>
		public void RegisterSpawnHandler(GameObject prefab) {
			ClientScene.RegisterPrefab(prefab, this.SpawnHandler, this.UnspawnHandler);
			this.prefabs[prefab.GetComponent<NetworkIdentity>().assetId] = prefab;
		}

		/// <summary>
		/// Registers the asset with the specified asset ID with the UNET spawning system, with pooling support.
		/// </summary>
		/// <param name="assetId">The asset ID of the asset that will be spawned.</param>
		/// <remarks>
		/// <paramref name="assetId"/> must be present in the <see cref="Prefabs"/> dictionary, mapping to its prefab game object.
		/// If the asset ID is not present in the dictionary, it will not be possible to spawn the object.
		/// </remarks>
		public void RegisterSpawnHandler(NetworkHash128 assetId) {
			ClientScene.RegisterSpawnHandler(assetId, this.SpawnHandler, this.UnspawnHandler);
		}

		/// <summary>
		/// Creates new pools using the default settings, for every prefab currently registered with <see cref="ClientScene"/> with pooling support.
		/// </summary>
		/// <remarks>
		/// This is equivalent to calling <see cref="GameObjectPoolManager.CreatePool(GameObject)"/> for each prefab in the <see cref="Prefabs"/>
		/// dictionary.
		/// </remarks>
		public void CreatePoolsForNetworkedPrefabs() {
			Contract.RequiresNotNull(this.PoolManager, nameof(this.PoolManager));

			//foreach (GameObject prefab in ClientScene.prefabs.Values) {
			foreach (GameObject prefab in this.prefabs.Values) {
				if (!this.PoolManager.HasPool(prefab)) {
					this.PoolManager.CreatePool(prefab);
				}
			}
		}

		/// <summary>
		/// Registers all prefabs from pools attached to the manager with the UNET spawning system, with pooling support.
		/// </summary>
		/// <remarks>
		/// This is equivalent to calling <see cref="RegisterSpawnHandler(GameObject)"/> for each pool in the pool manager's <see cref="GameObjectPoolManager.Pools"/> collection.
		/// </remarks>
		public void RegisterNetworkedPrefabsForAllPools() {
			Contract.RequiresNotNull(this.PoolManager, nameof(this.PoolManager));

			foreach (GameObjectPool pool in this.PoolManager.Pools) {
				if (pool.IsInitialised) {
					this.RegisterSpawnHandler(pool.Source);
				}
			}
		}
		#endregion

	}

}