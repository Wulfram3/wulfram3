﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal abstract class PoolDrawer<TPool, TSource, TInstance, TPoolSettings>
		where TPoolSettings : SharedPoolSettings<TSource>, ISharedPoolSettings<TSource>, new()
		where TPool : PoolBase<TSource, TInstance, TPoolSettings> {

		#region Fields.
		private readonly Action<TPool, TSource> changeSourceAction;

		protected SerializedProperty sourceProp;
		private SerializedProperty instantiateWhenEmptyProp;
		private SerializedProperty initialSizeProp;
		private SerializedProperty maximumSizeProp;
		private SerializedProperty initialiseOnStartProp;
		private SerializedProperty dontDestroyOnLoadProp;
		private SerializedProperty reparentPooledObjectsProp;
		private SerializedProperty recordStatisticsProp;
		private SerializedProperty logMessagesProp;
		private SerializedProperty notificationModeProp;
		private SerializedProperty warnOnDestroyProp;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets or sets a value indicating whether to draw the <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/> property.
		/// </summary>
		public bool DrawSourceObject { get; set; } = true;

		/// <summary>
		/// Gets or sets a value indicating whether to draw the <see cref="PoolBase{TSource,TInstance,TSettings}.InitialiseOnStart"/> property.
		/// </summary>
		public bool DrawInitialiseOnStart { get; set; } = true;

		/// <summary>
		/// Gets or sets the way in which times are displayed.
		/// </summary>
		public TimeDisplayMode TimeDisplayMode { get; set; } = TimeDisplayMode.RealtimeSinceStartup;
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="PoolDrawer{TPool,TSource,TInstance,TPoolSettings}"/> class.
		/// </summary>
		protected PoolDrawer(SerializedObject serializedObject, string root) {
			this.CreateSerializedProperties(serializedObject, root);
		}
		
		/// <summary>
		/// Initialises a new instance of the <see cref="PoolDrawer{TPool,TSource,TInstance,TPoolSettings}"/> class.
		/// </summary>
		/// <param name="changeSourceAction">An action that is used to change the source object on the pool.</param>
		protected PoolDrawer(Action<TPool, TSource> changeSourceAction) {
			this.changeSourceAction = changeSourceAction;
		}
		#endregion

		#region Public methods.
		public void DrawPoolDefinition(TPool pool, bool drawAdvanced) {
			this.DrawPoolDefinition(Enumerable.Repeat(pool, 1), drawAdvanced);
		}

		public void DrawPoolDefinition(IEnumerable<TPool> pools, bool drawAdvanced) {
			this.DrawPoolSettings(pools.Select(p => new KeyValuePair<TPoolSettings, TPool>(p.Definition, null)), drawAdvanced);
		}

		public void DrawPoolDefinition(TPoolSettings pool, bool drawAdvanced) {
			this.DrawPoolDefinition(Enumerable.Repeat(pool, 1), drawAdvanced);
		}

		public void DrawPoolDefinition(IEnumerable<TPoolSettings> definitions, bool drawAdvanced) {
			this.DrawPoolSettings(definitions.Select(d => new KeyValuePair<TPoolSettings, TPool>(d, null)), drawAdvanced);
		}
		
		public void DrawPool(TPool selectedPool, string root, bool drawAdvanced) {
			this.DrawPool(Enumerable.Repeat(selectedPool, 1), root, drawAdvanced);
		}

		public void DrawPool(IEnumerable<TPool> selectedPools, bool drawAdvanced) {
			this.DrawPoolSettings(selectedPools.Select(p => new KeyValuePair<TPoolSettings, TPool>(p.Settings, p)), drawAdvanced);
		}

		public void DrawPool(IEnumerable<TPool> selectedPools, string root, bool drawAdvanced) {
			var serializedObject = new SerializedObject(selectedPools.ToArray());
			this.CreateSerializedProperties(serializedObject, root);
			this.DrawPoolSettings(selectedPools.Select(p => new KeyValuePair<TPoolSettings, TPool>(p.Settings, p)), drawAdvanced);
		}
		#endregion

		protected virtual void CreateSerializedProperties(SerializedObject serializedObject, string root) {
			this.instantiateWhenEmptyProp = serializedObject.FindProperty(root + ".instantiateWhenEmpty");
			this.initialSizeProp = serializedObject.FindProperty(root + ".initialSize");
			this.maximumSizeProp = serializedObject.FindProperty(root + ".maximumSize");
			this.initialiseOnStartProp = serializedObject.FindProperty(root + ".initialiseOnStart");
			this.dontDestroyOnLoadProp = serializedObject.FindProperty(root + ".dontDestroyOnLoad");
			this.reparentPooledObjectsProp = serializedObject.FindProperty(root + ".reparentPooledObjects");
			this.recordStatisticsProp = serializedObject.FindProperty(root + ".recordStatistics");
			this.logMessagesProp = serializedObject.FindProperty(root + ".logMessages");
			this.notificationModeProp = serializedObject.FindProperty(root + ".notificationMode");
			this.warnOnDestroyProp = serializedObject.FindProperty(root + ".warnOnDestroy");
		}

		protected abstract void DrawSource(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools);
		
		protected virtual void ChangeSourceField(ISharedPoolSettings<TSource> settings, TPool pool, TSource newSource) {
			if (pool == null) {
				settings.Source = newSource;
			} else {
				if (this.changeSourceAction != null) {
					this.changeSourceAction(pool, newSource);
				} else {
					pool.Source = newSource;
				}
			}
		}

		protected virtual void DrawAfterSourceField(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools, bool drawAdvanced) {
			// Do nothing.
		}
		
		[SuppressMessage("ReSharper", "PossibleMultipleEnumeration")]
		private void DrawPoolSettings(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools, bool drawAdvanced) {
			bool hasPools = pools.All(kvp => kvp.Value != null);

			// Draw the Source Object field.
			if (this.DrawSourceObject) {
				// Disable the Source Object field if any of the selected pools are initialised.
				EditorGUI.BeginDisabledGroup(pools.Any(kvp => kvp.Value != null && kvp.Value.IsInitialised));
				this.DrawSource(pools);
				EditorGUI.EndDisabledGroup();
			}

			this.DrawAfterSourceField(pools, drawAdvanced);

			// Draw the Instantiate When Empty field.
			this.DrawSetting(pools,
				this.instantiateWhenEmptyProp,
				s => s.InstantiateWhenEmpty,
				(rect, s) => EditorGUI.Toggle(rect, new GUIContent("Instantiate When Empty", "Whether to instantiate a new object when an attempt is made to acquire from an empty pool."), s.InstantiateWhenEmpty),
				(s, newValue) => s.InstantiateWhenEmpty = newValue
			);
			
			// Draw the Initial Size field.
			if (!hasPools || pools.All(kvp => !kvp.Value.IsInitialised)) {
				this.DrawSetting(pools,
					this.initialSizeProp,
					s => s.InitialSize,
					(rect, s) => EditorGUI.DelayedIntField(rect, new GUIContent("Initial Size", "The initial size of the pool."), s.InitialSize),
					(s, newValue) => {
						if (newValue >= 0) {
							// Increase the maximum pool size to be at least as large as the initial size.
							if (newValue > s.MaximumSize) {
								s.MaximumSize = newValue;
							}
							s.InitialSize = newValue;
						}
					}
				);
			}
			if (hasPools && pools.All(kvp => kvp.Value.IsInitialised)) {
				// If the pools have been initialised, draw the Pooled Objects count field.
				this.DrawSetting(pools,
					(s, p) => p.Count,
					(rect, s, p) => EditorGUI.DelayedIntField(rect, new GUIContent("Pooled Objects", "The number of objects currently contained by the pool."), p.Count),
					(s, pool, newValue) => {
						if (pool == null) {
							// Do nothing.
						} else {
							if (newValue != pool.Count && newValue <= pool.MaximumSize) {
								pool.SetSize(newValue);
							}
						}
					}
				);
			}

			// Draw the Maximum Size field.
			this.DrawSetting(pools,
				this.maximumSizeProp,
				(s, p) => s.MaximumSize,
				(rect, s, p) => EditorGUI.DelayedIntField(rect, new GUIContent("Maximum Size", "The maximum size of the pool."), s.MaximumSize),
				(s, pool, newValue) => {
					bool hasInitialisedPool = pool != null && pool.IsInitialised;
					if (newValue >= 0 && (hasInitialisedPool || newValue >= s.InitialSize)) {
						s.MaximumSize = newValue;
					}
				}
			);

			if (drawAdvanced) {
				// Draw the Initialise On Start field.
				if (this.DrawInitialiseOnStart && (!hasPools || pools.All(kvp => !kvp.Value.IsInitialised))) {
					// TODO: This field also becomes unnecessary after the Start method has been called, not only after the pool has been initialised.
					this.DrawSetting(pools,
						this.initialiseOnStartProp,
						s => s.InitialiseOnStart,
						(rect, s) => EditorGUI.Toggle(rect, new GUIContent("Initialise On Start", "Whether to initialise the pool in the Start method."), s.InitialiseOnStart),
						(s, newValue) => s.InitialiseOnStart = newValue
					);
				}

				// Draw the Dont Destroy On Load field.
				this.DrawSetting(pools,
					this.dontDestroyOnLoadProp,
					s => s.DontDestroyOnLoad,
					(rect, s) => EditorGUI.Toggle(rect, new GUIContent("Don't Destroy On Load", "Whether the pool should persist between scene changes."), s.DontDestroyOnLoad),
					(s, newValue) => s.DontDestroyOnLoad = newValue
				);

				// Draw the Re-parent Pooled Objects field.
				this.DrawSetting(pools,
					this.reparentPooledObjectsProp,
					s => s.ReparentPooledObjects,
					(rect, s) => EditorGUI.Toggle(rect, new GUIContent("Re-parent Pooled Objects", "Whether to re-parent the pooled objects to the pool's Transform when released."), s.ReparentPooledObjects),
					(s, newValue) => s.ReparentPooledObjects = newValue
				);

				// Draw the Record Statistics field.
				this.DrawSetting(pools,
					this.recordStatisticsProp,
					s => s.RecordStatistics,
					(rect, s) => EditorGUI.Toggle(rect, new GUIContent("Record Statistics", "Whether to record pool statistics."), s.RecordStatistics),
					(s, record) => s.RecordStatistics = record
				);

				// Draw the Warn On Destroy field.
				this.DrawSetting(pools,
					this.warnOnDestroyProp,
					s => s.WarnOnDestroy,
					(rect, s) => EditorGUI.Toggle(rect, new GUIContent("Warn On Destroy", "Whether to log a warning message when a poolable object is destroyed (either inside of the pool, or while in use)."), s.WarnOnDestroy),
					(s, newValue) => s.WarnOnDestroy = newValue
				);

				// Draw the Log Messages field.
				this.DrawSetting(pools,
					this.logMessagesProp,
					s => s.LogMessages,
					(rect, s) => (LogLevel)EditorGUI.EnumPopup(rect, new GUIContent("Log Messages", "The level of log messaging that the pool will output."), s.LogMessages),
					(s, logLevel) => s.LogMessages = logLevel
				);

				// Draw the Notification Mode field.
				this.DrawSetting(pools,
					this.notificationModeProp,
					s => s.NotificationMode,
					(rect, s) => (NotificationMode)EditorGUI.EnumMaskField(rect, new GUIContent("Notification Mode", "The modes in which pooled objects are notified of their acquisition from, and release to, the pool."), s.NotificationMode),
					(s, mode) => s.NotificationMode = mode
				);

				// Draw the action buttons, only in Play Mode.
				if (hasPools && EditorApplication.isPlaying) {
					this.DrawPoolActions(pools);
				}
			}
		}

		protected virtual void DrawPoolActions(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools) {
			EditorGUILayout.BeginHorizontal();
			// Use a smaller label, to leave more room for the buttons.
			using (new LabelWidthGroup(100)) {
				EditorGUILayout.PrefixLabel("Actions");

				// TODO: Make the buttons flow on to the next line if the inspector isn't wide enough. See EditorGUIUtility.GetFlowLayoutedRects.
				// Draw the Fill Pool button.
				if (pools.Any(kvp => kvp.Value.IsInitialised)) {
					if (GUILayout.Button(new GUIContent("Fill", "Populate the pool with the maximum number of items."))) {
						foreach (var pool in pools.Select(kvp => kvp.Value).Where(p => p.IsInitialised)) {
							pool.Fill();
						}
					}
					// Draw the Clear Pool button.
					if (GUILayout.Button(new GUIContent("Clear", "Remove all items from the pool."))) {
						foreach (var pool in pools.Select(kvp => kvp.Value).Where(p => p.IsInitialised)) {
							pool.Clear();
						}
					}
				}

				// Draw the Initialise Pool button, only when the pool is uninitialised.
				// Disable the button if the source object hasn't been set yet.
				if (pools.Any(kvp => !kvp.Value.IsInitialised)) {
					EditorGUI.BeginDisabledGroup(pools.Select(kvp => kvp.Value).Where(p => !p.IsInitialised).All(p => p.Source == null));
					if (GUILayout.Button(new GUIContent("Initialise", "Initialise the pool, and make it ready for use."))) {
						foreach (var pool in pools.Select(kvp => kvp.Value).Where(p => !p.IsInitialised && p.Source != null)) {
							pool.Initialise();
						}
					}
					EditorGUI.EndDisabledGroup();
				}

				this.DrawPoolAdditionalActions(pools);
			}
			EditorGUILayout.EndHorizontal();
		}

		protected virtual void DrawPoolAdditionalActions(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools) {
			// Do nothing.
		}
		
		internal void DrawSetting<T>(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools, Func<TPoolSettings, TPool, T> currentValueSelector, Func<Rect, TPoolSettings, TPool, T> drawControl, Action<ISharedPoolSettings<TSource>, TPool, T> setValue) {
			this.DrawSetting(pools, null, currentValueSelector, drawControl, setValue);
		}

		internal void DrawSetting<T>(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools, SerializedProperty property, Func<TPoolSettings, TPool, T> currentValueSelector, Func<Rect, TPoolSettings, TPool, T> drawControl, Action<ISharedPoolSettings<TSource>, TPool, T> setValue) {
			EditorGUI.showMixedValue = !pools.Select(kvp => currentValueSelector(kvp.Key, kvp.Value)).Unanimous();
			var rect = EditorGUILayout.GetControlRect(true);
			if (property != null) {
				EditorGUI.BeginProperty(rect, GUIContent.none, property);
			}
			EditorGUI.BeginChangeCheck();

			KeyValuePair<TPoolSettings, TPool> first = pools.First();
			T newValue = drawControl(rect, first.Key, first.Value);

			if (EditorGUI.EndChangeCheck()) {
				// Record an undo state for the pools being edited.
				if (pools.All(kvp => kvp.Value != null)) {
					Undo.RecordObjects(pools.Select(kvp => kvp.Value).Cast<UnityEngine.Object>().ToArray(), "Change Pool Setting");
				}

				// Apply the change in value to all pools (or pool settings) being edited.
				foreach (var kvp in pools) {
					ISharedPoolSettings<TSource> destination = kvp.Value == null ? kvp.Key : (ISharedPoolSettings<TSource>)kvp.Value;
					setValue(destination, kvp.Value, newValue);
				}

				// Prefab override support.
				if (property != null) {
					// Ensure all pools being edited have their prefab state updated.
					foreach (var targetObject in property.serializedObject.targetObjects) {
						if (PrefabUtility.GetPrefabType(targetObject) == PrefabType.PrefabInstance) {
							// Prefab instances need to record any changes to their properties.
							PrefabUtility.RecordPrefabInstancePropertyModifications(targetObject);
						} else if (PrefabUtility.GetPrefabType(targetObject) == PrefabType.Prefab) {
							// Prefabs need to be set dirty to ensure their instances are updated and reflect any changes.
							EditorUtility.SetDirty(targetObject);
						}
					}
				}
			}
			if (property != null) {
				EditorGUI.EndProperty();
			}
		}

		//internal void DrawSetting<T>(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools, Func<TPoolSettings, T> currentValueSelector, Func<Rect, TPoolSettings, T> drawControl, Action<ISharedPoolSettings<TSource>, T> setValue) {
		//	this.DrawSetting(pools,
		//		(s, p) => currentValueSelector(s),
		//		(rect, s, p) => drawControl(rect, s),
		//		(s, p, newValue) => setValue(s, newValue));
		//}

		//internal void DrawSetting<T>(IEnumerable<TPool> pools, Func<TPool, T> currentValueSelector, Func<Rect, TPool, T> drawControl, Action<TPool, T> setValue) {
		//	this.DrawSetting(
		//		pools.Select(p => new KeyValuePair<TPoolSettings, TPool>(p.Settings, p)),
		//		(s, p) => currentValueSelector(p),
		//		(rect, s, p) => drawControl(rect, p),
		//		(s, p, newValue) => setValue(p, newValue)
		//	);
		//}

		internal void DrawSetting<T>(IEnumerable<KeyValuePair<TPoolSettings, TPool>> pools, SerializedProperty property, Func<TPoolSettings, T> currentValueSelector, Func<Rect, TPoolSettings, T> drawControl, Action<ISharedPoolSettings<TSource>, T> setValue) {
			this.DrawSetting(pools,
				property,
				(s, p) => currentValueSelector(s),
				(rect, s, p) => drawControl(rect, s),
				(s, p, newValue) => setValue(s, newValue));
		}

		internal void DrawSetting<T>(IEnumerable<TPool> pools, SerializedProperty property, Func<TPool, T> currentValueSelector, Func<Rect, TPool, T> drawControl, Action<TPool, T> setValue) {
			this.DrawSetting(
				pools.Select(p => new KeyValuePair<TPoolSettings, TPool>(p.Settings, p)),
				property,
				(s, p) => currentValueSelector(p),
				(rect, s, p) => drawControl(rect, p),
				(s, p, newValue) => setValue(p, newValue)
			);
		}

		public void DrawPoolStatistics(TPool pool) {
			this.DrawPoolStatistics(Enumerable.Repeat(pool, 1));
		}

		[SuppressMessage("ReSharper", "PossibleMultipleEnumeration")]
		public void DrawPoolStatistics(IEnumerable<TPool> selectedPools) {
			IEnumerable<TPool> initialisedPools = selectedPools.Where(p => p.IsInitialised);

			if (initialisedPools.Any(p => !p.RecordStatistics)) {
				EditorGUILayout.HelpBox($"{nameof(PoolBase<TSource,TInstance,TPoolSettings>.RecordStatistics)} has been disabled on some of the selected pools.", MessageType.Warning);
			}

			this.DrawPoolStatistic(initialisedPools, p => p.Count + p.Statistics.ObjectsAliveOutsidePool,
				new GUIContent("Owned Objects", "The number of objects owned by the pool, including those in use."));

			EditorGUI.indentLevel++;
			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.ObjectsAliveOutsidePool,
				new GUIContent("In-use Objects", "The number of objects that have been acquired from, but not yet returned to, the pool."));

			this.DrawPoolStatistic(initialisedPools, p => p.Count,
				new GUIContent("In-pool Objects", "The number of objects that are currently contained by the pool."));
			EditorGUI.indentLevel--;

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.InstantiationCount,
				new GUIContent("Instantiations", "The number of objects that have been instantiated when the pool was empty."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.DestructionCount,
				new GUIContent("Destructions", "The number of objects that have been destroyed when the pool was full."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.AcquireCount,
				new GUIContent("Objects Acquired", "The number of objects that have been acquired from the pool."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.ReleaseCount,
				new GUIContent("Objects Released", "The number of objects that have been released to the pool."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.HighestAliveCount,
				new GUIContent("Highest Owned Count", "The highest count of objects owned by the pool at any one time."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.RecommendedPoolSize,
				new GUIContent("Recommended Size", "The recommended size that the pool should have been at initialisation time, to avoid instantiations."));

			EditorGUI.BeginChangeCheck();
			var newMode = (TimeDisplayMode)EditorGUILayout.EnumPopup(new GUIContent("Time Display Mode", "The display mode to use for time-based statistics."), this.TimeDisplayMode);
			if (EditorGUI.EndChangeCheck()) {
				this.TimeDisplayMode = newMode;
			}

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.InitialisedTime,
				new GUIContent("Since Initialised", "The length of time since the pool was initialised."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.LastInstantiateTime,
				new GUIContent("Since Last Instantiate", "The length of time since an object was last instantiated."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.LastDestroyTime,
				new GUIContent("Since Last Destroy", "The length of time since an object was last destroyed."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.LastAcquireTime,
				new GUIContent("Since Last Acquire", "The length of time since an object was last acquired."));

			this.DrawPoolStatistic(initialisedPools, p => p.Statistics.LastReleaseTime,
				new GUIContent("Since Last Release", "The length of time since an object was last released."));
		}

		private void DrawPoolStatistic<T>(IEnumerable<T> values, GUIContent prefixContent, Func<T, string> valueFormatter) {
			EditorGUI.showMixedValue = !values.Unanimous();
			EditorGUILayout.BeginHorizontal();
			EditorGUILayout.PrefixLabel(prefixContent);
			using (new NoIndentGroup()) {
				EditorGUILayout.SelectableLabel(valueFormatter(values.First()), GUILayout.Height(EditorGUIUtility.singleLineHeight));
			}
			EditorGUILayout.EndHorizontal();
		}

		private void DrawPoolStatistic<T>(IEnumerable<TPool> source, Func<TPool, T> selector, GUIContent prefixContent) {
			this.DrawPoolStatistic(source.Select(selector), prefixContent, val => val.ToString());
		}

		private void DrawPoolStatistic(IEnumerable<TPool> source, Func<TPool, TimeInstant?> selector, GUIContent prefixContent) {
			var values = source.Select(selector);
			if (values.Any(v => v.HasValue)) {
				this.DrawPoolStatistic(values.Where(v => v.HasValue).Select(v => v.Value), prefixContent, val => this.GetDisplayTime(val, this.TimeDisplayMode));
			}
		}

		private string GetDisplayTime(TimeInstant timeInstant, TimeDisplayMode displayMode) {
			switch (displayMode) {
				case TimeDisplayMode.FrameCount:
					return (Time.frameCount - timeInstant.FrameCount).ToString(CultureInfo.CurrentCulture);
				case TimeDisplayMode.RealtimeSinceStartup:
					return TimeSpan.FromSeconds(Time.realtimeSinceStartup - timeInstant.RealtimeSinceStartup).ToString();
				case TimeDisplayMode.Time:
					return TimeSpan.FromSeconds(Time.time - timeInstant.Time).ToString();
				case TimeDisplayMode.UnscaledTime:
					return TimeSpan.FromSeconds(Time.unscaledTime - timeInstant.UnscaledTime).ToString();
				default:
					throw new ArgumentOutOfRangeException(nameof(displayMode), displayMode, null);
			}
		}

	}

}