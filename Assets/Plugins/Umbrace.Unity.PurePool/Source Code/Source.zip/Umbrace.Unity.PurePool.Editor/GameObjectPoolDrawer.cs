﻿using System;
using System.Collections.Generic;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class GameObjectPoolDrawer : PoolDrawer<GameObjectPool, GameObject, GameObject, GameObjectPoolSettings> {
		
		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="GameObjectPoolDrawer"/> class.
		/// </summary>
		public GameObjectPoolDrawer(SerializedObject serializedObject, string root) : base(serializedObject, root) {
			// Do nothing.
		}
		
		/// <summary>
		/// Initialises a new instance of the <see cref="GameObjectPoolDrawer"/> class.
		/// </summary>
		/// <param name="changeSourceAction">An action that is used to change the source object on the pool.</param>
		public GameObjectPoolDrawer(Action<GameObjectPool, GameObject> changeSourceAction) : base(changeSourceAction) {
			// Do nothing.
		}
		#endregion

		/// <inheritdoc />
		protected override void CreateSerializedProperties(SerializedObject serializedObject, string root) {
			base.CreateSerializedProperties(serializedObject, root);

			this.sourceProp = serializedObject.FindProperty(root + ".sourceObject");
		}

		/// <inheritdoc />
		protected override void DrawSource(IEnumerable<KeyValuePair<GameObjectPoolSettings, GameObjectPool>> pools) {
			this.DrawSetting(pools,
				this.sourceProp,
				(s, p) => s.Source,
				(rect, s, p) => (GameObject)EditorGUI.ObjectField(rect, new GUIContent("Source Object", "The object to be pooled."), s.Source, typeof(GameObject), true),
				this.ChangeSourceField
			);
		}
		
	}

}