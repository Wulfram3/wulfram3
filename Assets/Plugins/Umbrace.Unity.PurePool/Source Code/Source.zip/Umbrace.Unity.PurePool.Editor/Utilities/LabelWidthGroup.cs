using System;

using UnityEditor;

namespace Umbrace.Unity.PurePool.Editor {

	public class LabelWidthGroup : IDisposable {

		private readonly float previousLabelWidth;

		public LabelWidthGroup(float newLabelWidth) {
			this.previousLabelWidth = EditorGUIUtility.labelWidth;
			EditorGUIUtility.labelWidth = newLabelWidth;
		}

		public void Dispose() {
			EditorGUIUtility.labelWidth = this.previousLabelWidth;
		}

	}

}