﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class ComponentHelper : Helper<ComponentPoolManager, ComponentPoolManagerSettings, ComponentManagerEditorSettings, ComponentPool, ComponentPoolSettings, Type, Component> {

		public ComponentHelper(ComponentPoolManager manager) : base(manager) {
			// Do nothing.
		}
		
		public override string GetSourceName(Type source) {
			return source.Name;
		}

		protected override Type GetPoolableObjectType() {
			return typeof(PoolableComponent);
		}

	}

}