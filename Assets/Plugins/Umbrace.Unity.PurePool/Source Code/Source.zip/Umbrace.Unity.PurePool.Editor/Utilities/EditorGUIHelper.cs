﻿using System;
using System.Linq;

using Umbrace.Unity.PurePool.ForEditor;

using UnityEngine;
using UnityEditor;

namespace Umbrace.Unity.PurePool.Editor {

	/// <summary>
	/// A static helper class that provides additional methods for creating custom inspector editors.
	/// </summary>
	/// <seealso cref="EditorGUI"/>
	/// <seealso cref="EditorGUILayout"/>
	/// <seealso cref="EditorGUIUtility"/>
	internal static class EditorGUIHelper {
		
		public static void DrawFoldout(BoolEditorChangeValue expanded, string label, Action<bool, Rect> drawInToolbar) {
			EditorGUIHelper.DrawFoldout(expanded, new GUIContent(label), drawInToolbar);
		}

		public static void DrawFoldout(BoolEditorChangeValue expanded, string label, GUIStyle style, Action<bool, Rect> drawInToolbar) {
			EditorGUIHelper.DrawFoldout(expanded, new GUIContent(label), style, drawInToolbar);
		}

		public static void DrawFoldout(BoolEditorChangeValue expanded, GUIContent content, Action<bool, Rect> drawInToolbar) {
			EditorGUIHelper.DrawFoldout(expanded, content, EditorStyles.toolbar, drawInToolbar);
		}
		
		public static void DrawFoldout(BoolEditorChangeValue expanded, GUIContent content, GUIStyle style, Action<bool, Rect> drawInToolbar) {
			var st = new GUIStyle(EditorStyles.foldout) {
				fontStyle = style.fontStyle
			};

			EditorGUIHelper.DrawToolbar(null, style, rect => {
				// Offset the foldout to properly fit within the toolbar background. Otherwise the foldout content extends beyond the left edge of the toolbar background.
				GUILayout.Space(8);
				//var oldHierarchyValue = EditorGUIUtility.hierarchyMode;
				//EditorGUIUtility.hierarchyMode = false;

				// Turn off the indent level when drawing the foldout - otherwise the foldout content will be indented inside the already-indented toolbar.
				using (new NoIndentGroup()) {
					EditorGUI.BeginChangeCheck();
					Rect position = EditorGUILayout.GetControlRect(GUILayout.ExpandWidth(true), GUILayout.MinWidth(10));

					// Because EditorGUI.Foldout uses EditorGUIUtility.labelWidth to draw its label, we need to alter it here so it takes up all available space.
					float previousLabelWidth = EditorGUIUtility.labelWidth;
					EditorGUIUtility.labelWidth = position.width + 16; // 16 seems to be perfect, perhaps because it's two times 8 (the Space used to offset the foldout within the toolbar)?
					bool newExpanded = EditorGUI.Foldout(position, expanded.CurrentValue, content, true, st);
					EditorGUIUtility.labelWidth = previousLabelWidth;
					//EditorGUILayout.LabelField(content, GUILayout.ExpandWidth(true), GUILayout.MinWidth(10));
					if (EditorGUI.EndChangeCheck()) {
						expanded.TargetValue = newExpanded;
					}
				}

				//EditorGUIUtility.hierarchyMode = oldHierarchyValue;

				// Allow content to be drawn inside the toolbar.
				drawInToolbar?.Invoke(expanded.CurrentValue, rect);
			});

			//// Use an outer horizontal scope with spacing, to indent the toolbar-styled inner scope. Otherwise, the toolbar-styled inner scope will just take up the whole width.
			//using (new EditorGUILayout.HorizontalScope()) {
			//	GUILayout.Space(EditorGUI.indentLevel * 10);

			//	// Draw the inner scope with a toolbar style.
			//	using (var toolbar = new EditorGUILayout.HorizontalScope(style)) {
			//		// Offset the foldout to properly fit within the toolbar background. Otherwise the foldout content extends beyond the left edge of the toolbar background.
			//		GUILayout.Space(8);

			//		// Turn off the indent level when drawing the foldout - otherwise the foldout content will be indented inside the already-indented toolbar.
			//		int indent = EditorGUI.indentLevel;
			//		EditorGUI.indentLevel = 0;
			//		expanded.TargetValue = EditorGUILayout.Foldout(expanded.CurrentValue, content);
			//		EditorGUI.indentLevel = indent;

			//		GUILayout.FlexibleSpace(); // TODO: Remove this and allow drawInToolbar to implement it if required?

			//		// Allow content to be drawn inside the toolbar.
			//		if (drawInToolbar != null) {
			//			drawInToolbar(expanded.CurrentValue, toolbar.rect);
			//		}
			//	}
			//}
		}

		public static void DrawCustomFoldout(BoolEditorChangeValue expanded, GUIStyle style, Action<bool, Rect> drawInToolbar, bool spaced = true) {
			EditorGUIHelper.DrawToolbar(null, style, rect => {
				// Offset the foldout to properly fit within the toolbar background. Otherwise the foldout content extends beyond the left edge of the toolbar background.
				if (spaced)
				GUILayout.Space(8);
				//var oldHierarchyValue = EditorGUIUtility.hierarchyMode;
				//EditorGUIUtility.hierarchyMode = false;

				// Turn off the indent level when drawing the foldout - otherwise the foldout content will be indented inside the already-indented toolbar.
				using (new NoIndentGroup()) {
					EditorGUI.BeginChangeCheck();
					Rect position = EditorGUILayout.GetControlRect(GUILayout.Width(0));
					bool newExpanded = EditorGUI.Foldout(position, expanded.CurrentValue, GUIContent.none, true, EditorStyles.foldout);
					if (EditorGUI.EndChangeCheck()) {
						expanded.TargetValue = newExpanded;
					}
				}

				//EditorGUIUtility.hierarchyMode = oldHierarchyValue;

				drawInToolbar?.Invoke(expanded.CurrentValue, rect);
			});
		}

		/// <summary>
		/// Draws a horizontal toolbar area in the specified style.
		/// </summary>
		/// <param name="content">The content to be displayed in a label in the toolbar.</param>
		/// <param name="style">The style to apply to the toolbar.</param>
		/// <param name="drawInToolbar">An action that draws inside the toolbar, to the right of the content label.</param>
		public static void DrawToolbar(GUIContent content, GUIStyle style, Action<Rect> drawInToolbar) {
			// Use an outer horizontal scope with spacing, to indent the toolbar-styled inner scope. Otherwise, the toolbar-styled inner scope will just take up the whole width.
			using (new EditorGUILayout.HorizontalScope()) {
				GUILayout.Space(EditorGUI.indentLevel * 10);

				// Draw the inner scope with a toolbar style.
				using (var toolbar = new EditorGUILayout.HorizontalScope(style)) {
					if (content != null) {
						using (new NoIndentGroup()) {
							EditorGUILayout.LabelField(content, GUILayout.MinWidth(10));
						}
					}

					// Allow content to be drawn inside the toolbar.
					drawInToolbar?.Invoke(toolbar.rect);
				}
			}
		}

		/// <summary>
		/// Provides drag and drop functionality within a specified area.
		/// </summary>
		/// <typeparam name="T">The type of <see cref="UnityEngine.Object"/> that can be dropped.</typeparam>
		/// <param name="dropArea">The area in which the drag and drop functionality will occur.</param>
		/// <param name="allowMultiple"><see langword="true"/> if more than one object can be dropped; otherwise; <see langword="false"/>.</param>
		/// <param name="allowNonMatchingTypes"><see langword="true"/> if drag and drop should still occur even when an object not of type <typeparamref name="T"/> is present; otherwise, <see langword="false"/>.</param>
		/// <param name="visualMode">The visual indication mode for an allowed drag and drop.</param>
		/// <param name="dropAction">An action to perform when at least one object of type <typeparamref name="T"/> has been dropped within the drop area.</param>
		public static void DragDrop<T>(Rect dropArea, bool allowMultiple, bool allowNonMatchingTypes, DragAndDropVisualMode visualMode, Action<T[], UnityEngine.Object[]> dropAction) where T : UnityEngine.Object {
			EditorGUIHelper.DragDrop(dropArea, allowMultiple, allowNonMatchingTypes, visualMode, null, dropAction);
		}

		/// <summary>
		/// Provides drag and drop functionality within a specified area.
		/// </summary>
		/// <typeparam name="T">The type of <see cref="UnityEngine.Object"/> that can be dropped.</typeparam>
		/// <param name="dropArea">The area in which the drag and drop functionality will occur.</param>
		/// <param name="allowMultiple"><see langword="true"/> if more than one object can be dropped; otherwise; <see langword="false"/>.</param>
		/// <param name="allowNonMatchingTypes"><see langword="true"/> if drag and drop should still occur even when an object not of type <typeparamref name="T"/> is present; otherwise, <see langword="false"/>.</param>
		/// <param name="visualMode">The visual indication mode for an allowed drag and drop.</param>
		/// <param name="includeInDropFunction">A selector function that specifies whether individual dropped objects should be passed to <paramref name="dropAction"/> as matches.</param>
		/// <param name="dropAction">An action to perform when at least one matching object has been dropped within the drop area.</param>
		public static void DragDrop<T>(Rect dropArea, bool allowMultiple, bool allowNonMatchingTypes, DragAndDropVisualMode visualMode, Func<T, bool> includeInDropFunction, Action<T[], UnityEngine.Object[]> dropAction) where T : UnityEngine.Object {
			//Contract.Requires(dropAction != null);

			Func<T[], bool> canDropFunction = typeMatches => {
				if (!allowMultiple) {
					return typeMatches.Length == 1;
				}

				return true;
			};

			EditorGUIHelper.DragDrop(dropArea, allowNonMatchingTypes, visualMode, canDropFunction, includeInDropFunction, dropAction);
		}

		/// <summary>
		/// Provides drag and drop functionality within a specified area.
		/// </summary>
		/// <typeparam name="T">The type of <see cref="UnityEngine.Object"/> that can be dropped.</typeparam>
		/// <param name="dropArea">The area in which the drag and drop functionality will occur.</param>
		/// <param name="allowNonMatchingTypes"><see langword="true"/> if drag and drop should still occur even when an object not of type <typeparamref name="T"/> is present; otherwise, <see langword="false"/>.</param>
		/// <param name="visualMode">The visual indication mode for an allowed drag and drop.</param>
		/// <param name="canDropFunction">A function that determines whether the objects currently being dragged are allowed to be dropped.</param>
		/// <param name="includeInDropFunction">A selector function that specifies whether individual dropped objects should be passed to <paramref name="dropAction"/> as matches.</param>
		/// <param name="dropAction">An action to perform when at least one matching object has been dropped within the drop area.</param>
		public static void DragDrop<T>(Rect dropArea, bool allowNonMatchingTypes, DragAndDropVisualMode visualMode, Func<T[], bool> canDropFunction, Func<T, bool> includeInDropFunction, Action<T[], UnityEngine.Object[]> dropAction) where T : UnityEngine.Object {
			//Contract.Requires(dropAction != null);

			// Ensure the event is either a DragPerform or DragUpdated event.
			Event e = Event.current;
			if (e.type != EventType.DragPerform && e.type != EventType.DragUpdated) return;

			// Ensure the mouse is currently within the drop area.
			if (!dropArea.Contains(e.mousePosition)) return;

			// Get all game objects that are being dragged that are of type T.
			T[] typeMatches = DragAndDrop.objectReferences.Where(o => o is T).Cast<T>().ToArray();

			// If there are no objects being dragged of the correct type, don't continue.
			if (typeMatches.Length == 0) return;

			// If non-matching types are not allowed in the drag, and the current drag contains non-matching types, don't continue.
			if (!allowNonMatchingTypes && typeMatches.Length != DragAndDrop.objectReferences.Length) return;

			// Check if the dragged game objects can be dropped according to canDropFunction.
			if (canDropFunction != null && !canDropFunction(typeMatches)) return;

			if (e.type == EventType.DragUpdated) {
				if (includeInDropFunction == null || typeMatches.Any(includeInDropFunction)) {
					DragAndDrop.visualMode = visualMode;
					e.Use();
				}
			} else if (e.type == EventType.DragPerform) {
				// Get all game objects of type T that match according to includeInDropFunction.
				T[] includeMatches = includeInDropFunction != null ? typeMatches.Where(includeInDropFunction).ToArray() : typeMatches;

				// Only accept the drop if there was at least one valid game object being dropped.
				if (includeMatches.Any()) {
					DragAndDrop.AcceptDrag();

					UnityEngine.Object[] nonMatches = DragAndDrop.objectReferences.Except(includeMatches).ToArray();

					dropAction(includeMatches, nonMatches);
					e.Use();
				}
			}
		}

		/// <summary>
		/// Performs an action when the context button is pressed within the specified area.
		/// </summary>
		/// <param name="clickArea">The area in which the context button being pressed will perform the action.</param>
		/// <param name="clickAction">The action to perform.</param>
		/// <remarks>On Windows, the context button is the right mouse button.</remarks>
		public static void ContextClick(Rect clickArea, Action clickAction) {
			bool contextClick = Event.current.type == EventType.ContextClick && clickArea.Contains(Event.current.mousePosition);
			if (contextClick) {
				clickAction();
			}
		}

		/// <summary>
		/// Displays a context menu when the context button is pressed within the specified area.
		/// </summary>
		/// <param name="clickArea">The area in which the context button being pressed will display the context menu.</param>
		/// <param name="menuSetup">An action that sets up the context menu, prior to being displayed.</param>
		/// <remarks>On Windows, the context button is the right mouse button.</remarks>
		/// <example>
		/// The following example demonstrates the creation of a context menu within a specified area:
		/// <code>
		/// EditorGUIHelper.ContextMenu(new Rect(0, 0, 100, 100), menu => {
		///		menu.AddItem(new GUIContent("Item 1"), false, () => PerformAction1());
		///		menu.AddItem(new GUIContent("Item 2"), checked, () => ToggleChecked());
		///		menu.AddDisabledItem(new GUIContent("Disabled Item 3"));
		/// });
		/// </code>
		/// </example>
		public static void ContextMenu(Rect clickArea, Action<GenericMenu> menuSetup) {
			EditorGUIHelper.ContextClick(clickArea, () => {
				var menu = new GenericMenu();
				menuSetup(menu);
				menu.ShowAsContext();
			});
		}

		public static bool EditableLabel(string content, Rect area, GUIStyle textFieldStyle, string controlName, bool isEditing, Action<string> editAction) {
			// Start editing if the label is double clicked.
			if (EditorGUIHelper.IsDoubleClick(area)) {
				EditorGUI.FocusTextInControl(controlName);
				//EditorGUIUtility.editingTextField = true;
				Event.current.Use();
				return true;
			}

			if (isEditing) {
				using (new NoIndentGroup()) {

					// Stop editing if the Enter or Return keys are pressed.
					if (Event.current.type == EventType.KeyUp && Event.current.isKey && (Event.current.keyCode == KeyCode.KeypadEnter || Event.current.keyCode == KeyCode.Return)) {
						Event.current.Use();
						EditorGUIUtility.editingTextField = false;
						return false;
					}

					EditorGUI.BeginChangeCheck();
					GUI.SetNextControlName(controlName);
					Vector2 labelSize = textFieldStyle.CalcSize(new GUIContent(content));
					string newLabel = EditorGUILayout.DelayedTextField(content, textFieldStyle, GUILayout.ExpandWidth(true), GUILayout.MinWidth(labelSize.x));
					if (EditorGUI.EndChangeCheck()) {
						editAction(newLabel);
						EditorGUIUtility.editingTextField = false;
						return false;
					}

					// Stop editing if the focus is lost from the text field.
					if (Event.current.type != EventType.Used && GUI.GetNameOfFocusedControl() != controlName) {
						//if ((Event.current.isKey || Event.current.isMouse) && Event.current.type != EventType.Used && GUI.GetNameOfFocusedControl() != controlName) {
						EditorGUIUtility.editingTextField = false;
						return false;
					}
				}
			} else {
				using (new NoIndentGroup()) {
					Vector2 labelSize = EditorStyles.label.CalcSize(new GUIContent(content));
					EditorGUILayout.LabelField(new GUIContent(content, content), GUILayout.ExpandWidth(true), GUILayout.MinWidth(labelSize.x));
				}
			}

			return isEditing;
		}

		/// <summary>
		/// Gets a value indicating whether the current event is the left mouse button being released.
		/// </summary>
		/// <returns><see langword="true"/> if the current event is the left mouse button being released; otherwise, <see langword="false"/>.</returns>
		public static bool IsLeftMouseUp() {
			var e = Event.current;
			return e.type == EventType.MouseUp && e.button == 0;
		}

		/// <summary>
		/// Gets a value indicating whether the current event is the left mouse button being released in the specified area.
		/// </summary>
		/// <param name="clickArea">The area in which the mouse must be released.</param>
		/// <returns><see langword="true"/> if the current event is the left mouse button being released in the specified area; otherwise, <see langword="false"/>.</returns>
		public static bool IsLeftMouseUp(Rect clickArea) {
			return EditorGUIHelper.IsLeftMouseUp() && clickArea.Contains(Event.current.mousePosition);
		}

		/// <summary>
		/// Gets a value indicating whether the current event is the second time a mouse button has been pressed in quick succession.
		/// </summary>
		/// <returns><see langword="true"/> if the current event is the second time a mouse button has been pressed in quick succession; otherwise, <see langword="false"/>.</returns>
		public static bool IsDoubleClick() {
			var e = Event.current;
			return e.isMouse && e.type == EventType.MouseDown && e.clickCount == 2;
		}

		/// <summary>
		/// Gets a value indicating whether the current event is the second time a mouse button has been pressed in quick succession, in the specified area.
		/// </summary>
		/// <param name="area">The area in which the mouse must be released.</param>
		/// <returns><see langword="true"/> if the current event is the second time a mouse button has been pressed in quick succession, in the specified area; otherwise, <see langword="false"/>.</returns>
		public static bool IsDoubleClick(Rect area) {
			var e = Event.current;
			return EditorGUIHelper.IsDoubleClick() && area.Contains(e.mousePosition);
		}

		#region Tooltips.
		///// <summary>
		///// Gets the tooltip text to display for the specified member.
		///// </summary>
		///// <param name="member">The member whose tooltip should be retrieved.</param>
		///// <returns>The text of the tooltip for the specified member, or <see langword="null"/> if it has no tooltip.</returns>
		///// <remarks>
		///// <para>
		///// This method first looks for the <see cref="UnityEngine.TooltipAttribute"/> on the member,
		///// and if found, returns the value of <see cref="UnityEngine.TooltipAttribute.tooltip"/>.
		///// </para>
		///// <para>
		///// If the <see cref="UnityEngine.TooltipAttribute"/> is not found on the member, it proceeds to look for the
		///// <see cref="CustomTooltipAttribute"/>.
		///// </para>
		///// <para>If <see cref="CustomTooltipAttribute"/> is found on the member, the method returns the value of <see cref="CustomTooltipAttribute.Tooltip"/>.</para>
		///// <para> If neither attribute is found on the member, <see langword="null"/> is returned.</para>
		///// </remarks>
		//public static string GetTooltip(MemberInfo member) {
		//	// Look for the UnityEngine.TooltipAttribute first. The Unity attribute only supports fields.
		//	if (member.MemberType == MemberTypes.Field) {
		//		var attributes = (TooltipAttribute[])member.GetCustomAttributes(typeof(TooltipAttribute), true);
		//		if (attributes.Length > 0) {
		//			return attributes[0].tooltip;
		//		}
		//	}

		//	// Look for the CustomTooltipAttribute if the Unity attribute wasn't found. The custom one supports methods and properties too.
		//	if (member.MemberType == MemberTypes.Field || member.MemberType == MemberTypes.Property || member.MemberType == MemberTypes.Method) {
		//		var customAttributes = (CustomTooltipAttribute[])member.GetCustomAttributes(typeof(CustomTooltipAttribute), true);
		//		if (customAttributes.Length > 0) {
		//			return customAttributes[0].Tooltip;
		//		}
		//	}

		//	return null;
		//}

		///// <summary>
		///// Gets the tooltip text to display for the member with the given name on the specified type.
		///// </summary>
		///// <param name="type">The <see cref="Type"/> on which to look for the member with the given name.</param>
		///// <param name="memberName">The name of the member whose tooltip should be retrieved. The member should be an instance field or property.</param>
		///// <returns>The text of the tooltip for the specified member, or <see langword="null"/> if it has no tooltip or the member could not be found.</returns>
		///// <remarks>
		///// <para>
		///// This method first looks for the member with the given name on the specified type, limiting its search to instance fields and properties.
		///// If you need to retrieve the tootip from a different member type, use <see cref="EditorGUIHelper.GetTooltip(System.Reflection.MemberInfo)"/>.
		///// </para>
		///// <para>If the member with the specified name cannot be found, <see langword="null"/> is returned.</para>
		///// <para>
		///// Otherwise, this method looks for the <see cref="UnityEngine.TooltipAttribute"/> on the member,
		///// and if found, returns the value of <see cref="UnityEngine.TooltipAttribute.tooltip"/>.
		///// </para>
		///// <para>
		///// If the <see cref="UnityEngine.TooltipAttribute"/> is not found on the member, it proceeds to look for the
		///// <see cref="CustomTooltipAttribute"/>.
		///// </para>
		///// <para>If <see cref="CustomTooltipAttribute"/> is found on the member, the method returns the value of <see cref="CustomTooltipAttribute.Tooltip"/>.</para>
		///// <para> If neither attribute is found on the member, <see langword="null"/> is returned.</para>
		///// </remarks>
		//public static string GetTooltip(Type type, string memberName) {
		//	// Look for an instance field or property with the correct name.
		//	MemberInfo[] members = type.GetMember(memberName, MemberTypes.Field | MemberTypes.Property, BindingFlags.Instance);
		//	if (members.Length == 0) {
		//		return null;
		//	}

		//	return EditorGUIHelper.GetTooltip(members[0]);
		//}

		///// <summary>
		///// Gets the tooltip text to display for the member with the given name on the specified type.
		///// </summary>
		///// <typeparam name="T">The type on which to look for the member with the given name.</typeparam>
		///// <param name="memberName">The name of the member whose tooltip should be retrieved. The member should be an instance field or property.</param>
		///// <returns>The text of the tooltip for the specified member, or <see langword="null"/> if it has no tooltip or the member could not be found.</returns>
		///// <remarks>
		///// <para>
		///// This method first looks for the member with the given name on the specified type, limiting its search to instance fields and properties.
		///// If you need to retrieve the tootip from a different member type, use <see cref="EditorGUIHelper.GetTooltip(System.Reflection.MemberInfo)"/>.
		///// </para>
		///// <para>If the member with the specified name cannot be found, <see langword="null"/> is returned.</para>
		///// <para>
		///// Otherwise, this method looks for the <see cref="UnityEngine.TooltipAttribute"/> on the member,
		///// and if found, returns the value of <see cref="UnityEngine.TooltipAttribute.tooltip"/>.
		///// </para>
		///// <para>
		///// If the <see cref="UnityEngine.TooltipAttribute"/> is not found on the member, it proceeds to look for the
		///// <see cref="CustomTooltipAttribute"/>.
		///// </para>
		///// <para>If <see cref="CustomTooltipAttribute"/> is found on the member, the method returns the value of <see cref="CustomTooltipAttribute.Tooltip"/>.</para>
		///// <para> If neither attribute is found on the member, <see langword="null"/> is returned.</para>
		///// </remarks>
		//public static string GetTooltip<T>(string memberName) where T : class {
		//	return EditorGUIHelper.GetTooltip(typeof(T), memberName);
		//}

		///// <summary>
		///// Gets the tooltip text to display for the member with the given name on the object being inspected by the editor.
		///// </summary>
		///// <param name="editor">The <see cref="Editor"/> that is currently inspecting an object, on which to look for the member with the given name.</param>
		///// <param name="memberName">The name of the member whose tooltip should be retrieved. The member should be an instance field or property.</param>
		///// <returns>The text of the tooltip for the specified member, or <see langword="null"/> if it has no tooltip or the member could not be found.</returns>
		///// <remarks>
		///// <para>
		///// This method first looks for the member with the given name on the object being inspected by the editor, limiting its search to instance fields and properties.
		///// If you need to retrieve the tootip from a different member type, use <see cref="EditorGUIHelper.GetTooltip(System.Reflection.MemberInfo)"/>.
		///// </para>
		///// <para>If the member with the specified name cannot be found, <see langword="null"/> is returned.</para>
		///// <para>
		///// Otherwise, this method looks for the <see cref="UnityEngine.TooltipAttribute"/> on the member,
		///// and if found, returns the value of <see cref="UnityEngine.TooltipAttribute.tooltip"/>.
		///// </para>
		///// <para>
		///// If the <see cref="UnityEngine.TooltipAttribute"/> is not found on the member, it proceeds to look for the
		///// <see cref="CustomTooltipAttribute"/>.
		///// </para>
		///// <para>If <see cref="CustomTooltipAttribute"/> is found on the member, the method returns the value of <see cref="CustomTooltipAttribute.Tooltip"/>.</para>
		///// <para> If neither attribute is found on the member, <see langword="null"/> is returned.</para>
		///// </remarks>
		//public static string GetTooltip(this UnityEditor.Editor editor, string memberName) {
		//	return EditorGUIHelper.GetTooltip(editor.target.GetType(), memberName);
		//}
		#endregion
		
	}

}