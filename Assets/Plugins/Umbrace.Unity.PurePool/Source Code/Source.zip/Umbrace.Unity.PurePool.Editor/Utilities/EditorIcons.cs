﻿using Umbrace.Unity.Editor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	public static class EditorIcons {

		private static Texture2D greyBulletTexture;
		private static Texture2D yellowBulletTexture;
		private static Texture2D greenBulletTexture;
		private static Texture2D blueBulletTexture;
		private static Texture2D redBulletTexture;

		public static Texture2D GreyBulletTexture => EditorIcons.greyBulletTexture ?? (EditorIcons.greyBulletTexture = EditorAsset.LoadAsset<Texture2D>("bullet-grey.png"));

		public static Texture2D YellowBulletTexture => EditorIcons.yellowBulletTexture ?? (EditorIcons.yellowBulletTexture = EditorAsset.LoadAsset<Texture2D>("bullet-yellow.png"));

		public static Texture2D GreenBulletTexture => EditorIcons.greenBulletTexture ?? (EditorIcons.greenBulletTexture = EditorAsset.LoadAsset<Texture2D>("bullet-green.png"));

		public static Texture2D BlueBulletTexture => EditorIcons.blueBulletTexture ?? (EditorIcons.blueBulletTexture = EditorAsset.LoadAsset<Texture2D>("bullet-blue.png"));

		public static Texture2D RedBulletTexture => EditorIcons.redBulletTexture ?? (EditorIcons.redBulletTexture = EditorAsset.LoadAsset<Texture2D>("bullet-red.png"));

	}

}