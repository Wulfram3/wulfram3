using System;

using UnityEditor;

namespace Umbrace.Unity.PurePool.Editor {

	public class NoIndentGroup : IDisposable {

		private readonly int previousIndentLevel;

		public NoIndentGroup() {
			this.previousIndentLevel = EditorGUI.indentLevel;
			EditorGUI.indentLevel = 0;
		}

		public void Dispose() {
			EditorGUI.indentLevel = this.previousIndentLevel;
		}

	}

}