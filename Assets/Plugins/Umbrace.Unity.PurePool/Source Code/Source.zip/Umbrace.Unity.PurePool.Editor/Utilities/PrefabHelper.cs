﻿using UnityEditor;
using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal static class PrefabHelper {

		/// <summary>
		/// Marks the specified prefab or prefab instance as having changed.
		/// </summary>
		/// <param name="targetObject">The prefab or prefab instance.</param>
		/// <remarks>
		/// If <paramref name="targetObject"/> is a prefab, <see cref="EditorUtility.SetDirty"/> is called on it.
		/// If <paramref name="targetObject"/> is a prefab instance, <see cref="PrefabUtility.RecordPrefabInstancePropertyModifications"/> is called on it.
		/// Does nothing if <paramref name="targetObject"/> is not a prefab or prefab instance.
		/// </remarks>
		internal static void MarkPrefabChanged(Object targetObject) {
			if (PrefabUtility.GetPrefabType(targetObject) == PrefabType.PrefabInstance) {
				// Prefab instances need to record any changes to their properties.
				PrefabUtility.RecordPrefabInstancePropertyModifications(targetObject);
			} else if (PrefabUtility.GetPrefabType(targetObject) == PrefabType.Prefab) {
				// Prefabs need to be set dirty to ensure their instances are updated and reflect any changes.
				EditorUtility.SetDirty(targetObject);
			}
		}

	}

}