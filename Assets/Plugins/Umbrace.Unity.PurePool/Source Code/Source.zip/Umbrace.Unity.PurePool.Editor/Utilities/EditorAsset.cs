﻿using System.IO;
using System.Linq;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.Editor {

	public static class EditorAsset {

		public static T LoadAsset<T>(string relativePath) where T : Object {
			string file = EditorAsset.FindFilePath(relativePath);
			string relative = file.Substring(Application.dataPath.Length + 1);

			relative = Path.Combine("Assets", relative).Replace('\\', '/');

			var asset = (T)AssetDatabase.LoadAssetAtPath(relative, typeof(T));

			return asset;
		}

		private static string FindFilePath(string relativePath) {
			string assetPath = Application.dataPath;

			//string file = Path.Combine(assetPath, relativePath);
			//if (File.Exists(file)) return file;

			string file = Directory.GetFiles(assetPath, relativePath, SearchOption.AllDirectories).FirstOrDefault();

			return file;
		}

	}

}