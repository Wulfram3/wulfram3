﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class GameObjectHelper : Helper<GameObjectPoolManager, GameObjectPoolManagerSettings, GameObjectManagerEditorSettings, GameObjectPool, GameObjectPoolSettings, GameObject, GameObject> {

		public GameObjectHelper(GameObjectPoolManager manager) : base(manager) {
			// Do nothing.
		}
		
		public override string GetSourceName(GameObject source) {
			return source.name;
		}

		protected override Type GetPoolableObjectType() {
			return typeof(PoolableGameObject);
		}

	}

}