﻿using System;
using System.Collections.Generic;
using System.Linq;

using Umbrace.Unity.PurePool.ForEditor;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class ComponentPoolDrawer : PoolDrawer<ComponentPool, Type, Component, ComponentPoolSettings> {

		#region Fields.
		private readonly BoolEditorChangeValue sourceFieldTypesExpanded = new BoolEditorChangeValue(false);
		private readonly BoolEditorChangeValue newAdditionalComponentExpanded = new BoolEditorChangeValue(false);

		private readonly TypeSelectionDrawer sourceFieldDrawer;
		private readonly TypeSelectionDrawer additionalComponentDrawer;
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="ComponentPoolDrawer"/> class.
		/// </summary>
		public ComponentPoolDrawer(SerializedObject serializedObject, string root) : base(serializedObject, root) {
			this.sourceFieldDrawer = new TypeSelectionDrawer { AllowEmptyComponentMenu = false };
			this.additionalComponentDrawer = new TypeSelectionDrawer { AllowEmptyComponentMenu = false };
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="ComponentPoolDrawer"/> class.
		/// </summary>
		/// <param name="changeSourceAction">An action that is used to change the source object on the pool.</param>
		public ComponentPoolDrawer(Action<ComponentPool, Type> changeSourceAction) : base(changeSourceAction) {
			this.sourceFieldDrawer = new TypeSelectionDrawer { AllowEmptyComponentMenu = false };
			this.additionalComponentDrawer = new TypeSelectionDrawer { AllowEmptyComponentMenu = false };
		}
		#endregion

		/// <inheritdoc />
		protected override void CreateSerializedProperties(SerializedObject serializedObject, string root) {
			base.CreateSerializedProperties(serializedObject, root);

			this.sourceProp = serializedObject.FindProperty(root + ".componentType");
		}

		/// <inheritdoc />
		protected override void DrawSource(IEnumerable<KeyValuePair<ComponentPoolSettings, ComponentPool>> pools) {
			this.DrawSetting(pools,
				this.sourceProp,
				(s, p) => s.Source,
				(rect, s, p) => this.DrawSourceField(rect, s.Source),
				this.ChangeSourceField
			);
		}

		private Type DrawSourceField(Rect position, Type currentSource) {
			//EditorGUIHelper.DrawCustomFoldout(this.sourceFieldTypesExpanded, GUIStyle.none, (expanded, rect) => {
			//	this.DrawComponentTypeField(new GUIContent("Source Component", "The component to be pooled."), currentSource, EditorStyles.objectField);
			//}, false);

			bool changed = GUI.changed;

			EditorGUILayout.BeginHorizontal();
			var labelRect = new Rect(position) { width = EditorGUIUtility.labelWidth };
			if (GUI.enabled) {
				this.sourceFieldTypesExpanded.TargetValue = EditorGUI.Foldout(labelRect, this.sourceFieldTypesExpanded, new GUIContent("Source Component", "The component to be pooled."), true);
			} else {
				EditorGUI.LabelField(labelRect, new GUIContent("Source Component", "The component to be pooled."));
			}

			var fieldRect = new Rect(position);
			fieldRect.x += labelRect.width;
			fieldRect.width -= labelRect.width;
			this.DrawComponentTypeField(fieldRect, currentSource, EditorStyles.objectField);
			EditorGUILayout.EndHorizontal();

			this.sourceFieldTypesExpanded.ChangeValue();
			GUI.changed = changed;

			if (this.sourceFieldTypesExpanded) {
				EditorGUI.BeginChangeCheck();
				currentSource = this.sourceFieldDrawer.Draw(currentSource);
				if (EditorGUI.EndChangeCheck()) {
					this.sourceFieldTypesExpanded.ForceSet(false);
					GUI.changed = true;
				}
			}
			
			return currentSource;
		}

		protected override void ChangeSourceField(ISharedPoolSettings<Type> settings, ComponentPool pool, Type newSource) {
			base.ChangeSourceField(settings, pool, newSource);

			foreach (var poolableRequiredType in TypeHelper.FindPoolableComponents(newSource)) {
				this.AddAdditionalComponent((IComponentPoolSettings)settings, poolableRequiredType);
			}
		}

		protected override void DrawAfterSourceField(IEnumerable<KeyValuePair<ComponentPoolSettings, ComponentPool>> pools, bool drawAdvanced) {
			// No multi-editing support for the additional types.
			if (pools.Count() > 1) return;
			
			bool anyInitialised = pools.Any(kvp => kvp.Value != null && kvp.Value.IsInitialised);

			// Disable the Additional Type fields if any of the selected pools are initialised.
			EditorGUI.BeginDisabledGroup(anyInitialised);

			var deletions = new List<Type>();
			foreach (var additionalType in pools.First().Key.AdditionalComponentTypes) {
				bool delete = this.DrawDeletableComponentTypeField(new GUIContent("Additional Component"), additionalType, EditorStyles.textField);

				if (delete) {
					deletions.Add(additionalType);
				}
			}

			foreach (var additionalType in deletions) {
				pools.First().Key.AdditionalComponentTypes.Remove(additionalType);
			}

			// Only draw the Add Additional Type foldout if no pools are initialised, and the GUI is enabled.
			if (!anyInitialised && GUI.enabled) {
				this.newAdditionalComponentExpanded.TargetValue = EditorGUILayout.Foldout(this.newAdditionalComponentExpanded.CurrentValue, new GUIContent("Add Additional Component"), true);
				this.newAdditionalComponentExpanded.ChangeValue();

				if (this.newAdditionalComponentExpanded) {
					Type newComponentType = this.additionalComponentDrawer.Draw(null);
					if (newComponentType != null) {
						this.AddAdditionalComponent(pools.First().Key, newComponentType);
					}
				}
			}

			EditorGUI.EndDisabledGroup();
		}
		
		private void AddAdditionalComponent(IComponentPoolSettings poolSettings, Type componentType) {
			// If adding a component type that already exist, ensure multiple components of this type can be added.
			if ((poolSettings.Source == componentType || poolSettings.AdditionalComponentTypes.Contains(componentType)) && componentType.DisallowMultiple()) {
				Debug.LogWarning($"Unable to add additional component '{componentType.Name}', as only one component of this type is permitted.");
				return;
			}

			poolSettings.AdditionalComponentTypes.Add(componentType);

			foreach (var poolableRequiredType in TypeHelper.FindPoolableComponents(componentType)) {
				// Skip the IPoolable if one is already present. Some may be allowed to exist multiple times, but by default only one of them should be needed.
				if (poolSettings.Source == poolableRequiredType || poolSettings.AdditionalComponentTypes.Contains(poolableRequiredType)) continue;

				this.AddAdditionalComponent(poolSettings, poolableRequiredType);
			}
		}

		private string GetSourceName(Type source) {          
			if (source == null) return "None";
			return source.Name;
		}

		private void DrawComponentTypeField(Rect position, Type type, GUIStyle style) {
			EditorGUILayout.BeginHorizontal();
			using (new NoIndentGroup()) {
				EditorGUI.SelectableLabel(position, this.GetSourceName(type), style);
			}
			EditorGUILayout.EndHorizontal();
		}

		private bool DrawDeletableComponentTypeField(GUIContent content, Type type, GUIStyle style) {
			EditorGUILayout.BeginHorizontal();
			EditorGUILayout.BeginHorizontal();
			EditorGUILayout.PrefixLabel(content);
			Rect position = EditorGUILayout.GetControlRect(false, GUILayout.Height(EditorGUIUtility.singleLineHeight));
			this.DrawComponentTypeField(position, type, style);
			EditorGUILayout.EndHorizontal();
			bool pressed = GUILayout.Button("x", EditorStyles.miniButton, GUILayout.ExpandWidth(false));
			EditorGUILayout.EndHorizontal();

			return pressed;
		}

	}

}