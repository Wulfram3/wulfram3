﻿using System;
using System.Diagnostics.CodeAnalysis;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[CustomEditor(typeof(ComponentPool))]
	[CanEditMultipleObjects]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal class ComponentPoolEditor : BasePoolEditor<ComponentPool, ComponentPoolDrawer, Type, Component, ComponentPoolSettings> {
		
		#region Fields.
		private SerializedProperty instantiatedEventProp;
		private SerializedProperty acquiredEventProp;
		private SerializedProperty releasedEventProp;
		private SerializedProperty destroyedEventProp;
		#endregion
		
		#region BasePoolEditor overrides.
		protected override void OnEnable() {
			base.OnEnable();

			this.instantiatedEventProp = this.serializedObject.FindProperty(nameof(ComponentPool.ObjectInstantiatedEvent));
			this.acquiredEventProp = this.serializedObject.FindProperty(nameof(ComponentPool.ObjectAcquiredEvent));
			this.releasedEventProp = this.serializedObject.FindProperty(nameof(ComponentPool.ObjectReleasedEvent));
			this.destroyedEventProp = this.serializedObject.FindProperty(nameof(ComponentPool.ObjectDestroyedEvent));
		}

		protected override ComponentPoolDrawer CreatePoolDrawer() {
			return new ComponentPoolDrawer(this.serializedObject, "currentSettings");
		}

		protected override void DrawUnityEvents() {
			this.eventsExpanded.TargetValue = EditorGUILayout.Foldout(this.eventsExpanded, "UnityEvents", true, this.boldFoldoutStyle);
			if (this.eventsExpanded) {
				EditorGUILayout.PropertyField(this.instantiatedEventProp);
				EditorGUILayout.PropertyField(this.acquiredEventProp);
				EditorGUILayout.PropertyField(this.releasedEventProp);
				EditorGUILayout.PropertyField(this.destroyedEventProp);
			}
		}
		#endregion

		#region Importing and exporting.
		[MenuItem("CONTEXT/ComponentPool/Export Pool Settings")]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void ExportPoolSettings(MenuCommand menuCommand) {
			var pool = menuCommand.context as ComponentPool;
			if (pool == null) return;

			// Choose the file to save the pool settings to.
			string path = EditorUtility.SaveFilePanel("Export Pool Settings", String.Empty, pool.name, "json");

			if (path.Length != 0) {
				var exporter = new ComponentPoolExporter();
				exporter.Export(path, pool);
			}
		}

		[MenuItem("CONTEXT/ComponentPool/Export Pool Settings", true)]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static bool ValidateExportPoolSettings() {
			// Only allow exporting of settings when a single pool is selected.
			return Selection.objects.Length == 1;
		}

		[MenuItem("CONTEXT/ComponentPool/Import Pool Settings")]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void ImportPoolSettings(MenuCommand menuCommand) {
			var pool = menuCommand.context as ComponentPool;
			if (pool == null) return;

			// Choose the file to load the pool settings from.
			string path = EditorUtility.OpenFilePanel("Import Pool Settings", String.Empty, "json");

			if (path.Length != 0) {
				var importer = new ComponentPoolImporter();
				importer.Import(path, pool);
			}
		}

		[MenuItem("CONTEXT/ComponentPool/Import Pool Settings", true)]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static bool ValidateImportPoolSettings() {
			// Only allow importing of settings when a single pool is selected.
			return Selection.objects.Length == 1;
		}
		#endregion

	}

}