﻿using System;
using System.Diagnostics.CodeAnalysis;

using UnityEditor;
using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	using TypedHelper = Helper<ComponentPoolManager, ComponentPoolManagerSettings, ComponentManagerEditorSettings, ComponentPool, ComponentPoolSettings, Type, Component>;
	using TypedPoolDrawer = PoolDrawer<ComponentPool, Type, Component, ComponentPoolSettings>;

	[CustomEditor(typeof(ComponentPoolManager))]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal class ComponentPoolManagerEditor : BasePoolManagerEditor<ComponentPoolManager, ComponentPoolManagerSettings, ComponentManagerEditorSettings, ComponentPool, ComponentPoolSettings, Type, Component> {
		
		#region Properties.
		//private ComponentPoolManager Manager => (ComponentPoolManager)this.target;
		
		protected override string DefaultSettingsHelpText => "The default settings will be used when a new pool is created automatically. " +
															"For example, when an instance of a component is requested from the manager at runtime, and no pool exists for it.";
		#endregion

		#region BasePoolManagerEditor method overrides.
		protected override TypedHelper CreateHelper() => new ComponentHelper(this.Manager);

		protected override TypedPoolDrawer CreatePoolDrawer() => new ManagerComponentPoolDrawer(this.Manager, (pool, source) => this.helper.ChangeSourceObject(pool, source));

		protected override TypedPoolDrawer CreateDefaultSettingsDrawer() {
			return new ManagerComponentPoolDrawer(this.Manager, this.serializedObject, "settings.defaultPoolSettings") {
				DrawSourceObject = false // The default settings have no need for a source object.
			};
		}

		/// <inheritdoc />
		protected override void DrawPoolMain(ComponentPool pool, bool drawAdvanced = true) {
			this.poolDrawer.DrawPool(pool, "currentSettings", drawAdvanced);
		}

		private Rect buttonRect;
		protected override void QuickAddField() {
			var buttonStyle = new GUIStyle(GUI.skin.button) {
				fontSize = 12
			};
			buttonStyle.active = buttonStyle.normal;

			// Draw a centred Quick Add Pool button, that opens a popup.
			EditorGUILayout.BeginHorizontal();
			GUILayout.FlexibleSpace();
			if (GUILayout.Button("Quick Add Pool", buttonStyle, GUILayout.Width(230), GUILayout.Height(23))) {
				PopupWindow.Show(this.buttonRect, new TypeSelectionPopup {
					Size = new Vector2(230, 320),
					OnSelectionMade = type => this.CreatePool(this.Manager.transform, type)
				});
			}
			if (Event.current.type == EventType.Repaint) this.buttonRect = GUILayoutUtility.GetLastRect();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
		}

		protected override ComponentPoolSettings CreatePoolSettingsClone(ComponentPoolSettings settings) {
			return new ComponentPoolSettings(settings);
		}

		protected override ComponentPool CreatePoolInternal(Transform parent, Type source, bool expand = true) {
			var newPool = base.CreatePoolInternal(parent, source, expand);

			// Add the IPoolable component(s) for the source type to the pool.
			foreach (var poolable in TypeHelper.FindPoolableComponents(source)) {
				// Ignore duplicates that are disallowed.
				if (poolable.DisallowMultiple() && newPool.AdditionalComponentTypes.Contains(poolable)) continue;

				newPool.AdditionalComponentTypes.Add(poolable);
			}

			return newPool;
		}
		#endregion

		#region Exporting.
		[MenuItem("CONTEXT/ComponentPoolManager/Export Manager Settings")]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void ExportManagerSettings(MenuCommand menuCommand) {
			var manager = menuCommand.context as ComponentPoolManager;
			if (manager == null) return;

			// Determine which export mode that user wishes to use.
			string message = $"Please choose whether you wish to export only the manager's settings, or whether you wish to export the settings of the pools beneath the manager too.";
			int result = EditorUtility.DisplayDialogComplex("Export Mode", message, "Export Settings", "Export Pools", "Cancel");

			// Cancel was chosen.
			if (result == 2) return;

			var exportMode = result == 0 ? ManagerExportMode.ManagerSettingsOnly : ManagerExportMode.ManagerSettingsWithPools;

			// Choose the file to save the pool settings to.
			string path = EditorUtility.SaveFilePanel("Export Manager Settings", string.Empty, manager.name, "json");

			if (path.Length != 0) {
				var exporter = new ComponentPoolManagerExporter();
				exporter.Export(path, manager, exportMode);
			}
		}

		[MenuItem("CONTEXT/ComponentPoolManager/Export Manager Settings", true)]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static bool ValidateExportManagerSettings() {
			// Only allow exporting of settings when a single pool is selected.
			return Selection.objects.Length == 1;
		}
		#endregion

		#region Importing.
		[MenuItem("CONTEXT/ComponentPoolManager/Import Manager Settings")]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void ImportManagerSettings(MenuCommand menuCommand) {
			var manager = menuCommand.context as ComponentPoolManager;
			if (manager == null) return;

			// Choose the file to load the pool settings from.
			string path = EditorUtility.OpenFilePanel("Import Manager Settings", string.Empty, "json");

			if (path.Length != 0) {
				var importer = new ComponentPoolManagerImporter();
				importer.Import(path, manager);
			}
		}

		[MenuItem("CONTEXT/ComponentPoolManager/Import Pool Settings", true)]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static bool ValidateImportManagerSettings() {
			// Only allow importing of settings when a single pool is selected.
			return Selection.objects.Length == 1;
		}
		#endregion

	}

}