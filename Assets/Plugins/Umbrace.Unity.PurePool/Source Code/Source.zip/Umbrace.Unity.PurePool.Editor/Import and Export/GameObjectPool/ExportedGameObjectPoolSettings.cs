using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class ExportedGameObjectPoolSettings : ExportedPoolSettings<GameObject, GameObjectPoolSettings> {

		public ExportedGameObjectPoolSettings(PoolExportMetadata metadata, GameObjectPoolSettings settings) : base(metadata, settings) {
			
		}

	}

}