﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class GameObjectPoolExporter : PoolExporter<GameObject, GameObject, GameObjectPoolSettings, ExportedGameObjectPoolSettings, GameObjectPool> {
		
		/// <inheritdoc />
		protected override Version Version => new Version(1, 0);

		/// <inheritdoc />
		protected override string ExportSubType => Editor.ExportSubType.GameObjectPool;

		/// <inheritdoc />
		protected override string PoolTypeName => nameof(GameObjectPool);
		
		/// <inheritdoc />
		protected override ExportedGameObjectPoolSettings CreateExportDataInternal(PoolExportMetadata metadata, GameObjectPoolSettings settings) {
			return new ExportedGameObjectPoolSettings(metadata, settings);
		}

	}

}