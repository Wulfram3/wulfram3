﻿using System;
using System.Collections.Generic;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class ExportedGameObjectManagerSettings : ExportedManagerSettings<GameObject, GameObjectPoolSettings, GameObjectPoolManagerSettings, ExportedGameObjectPoolSettings> {
		
		public ExportedGameObjectManagerSettings(ManagerExportMetadata metadata, GameObjectPoolManagerSettings managerSettings) : base(metadata, managerSettings) {
			
		}

		public ExportedGameObjectManagerSettings(ManagerExportMetadata metadata, GameObjectPoolManagerSettings managerSettings, IEnumerable<ExportedGameObjectPoolSettings> poolSettings)
			: base(metadata, managerSettings, poolSettings) {
			
		}

	}

}