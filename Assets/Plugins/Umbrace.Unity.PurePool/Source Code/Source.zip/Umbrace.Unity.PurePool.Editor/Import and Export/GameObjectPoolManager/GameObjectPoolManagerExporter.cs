﻿using System;
using System.Collections.Generic;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class GameObjectPoolManagerExporter : PoolManagerExporter<GameObjectPoolManager, GameObjectPoolManagerSettings, GameObjectPool, GameObjectPoolSettings, ExportedGameObjectManagerSettings, ExportedGameObjectPoolSettings, GameObjectPoolExporter, GameObject, GameObject> {
		
		/// <inheritdoc />
		protected override Version Version => new Version(1, 0);

		/// <inheritdoc />
		protected override string ExportSubType => Editor.ExportSubType.GameObjectPoolManager;

		/// <inheritdoc />
		protected override string PoolManagerTypeName => nameof(GameObjectPoolManager);
		
		/// <inheritdoc />
		protected override GameObjectPoolExporter CreatePoolExporter() {
			return new GameObjectPoolExporter();
		}

		/// <inheritdoc />
		protected override ExportedGameObjectManagerSettings CreateExportedManagerSettings(ManagerExportMetadata metadata, GameObjectPoolManagerSettings managerSettings) {
			return new ExportedGameObjectManagerSettings(metadata, managerSettings);
		}

		/// <inheritdoc />
		protected override ExportedGameObjectManagerSettings CreateExportedManagerSettings(ManagerExportMetadata metadata, GameObjectPoolManagerSettings managerSettings, IEnumerable<ExportedGameObjectPoolSettings> poolSettings) {
			return new ExportedGameObjectManagerSettings(metadata, managerSettings, poolSettings);
		}

	}

}