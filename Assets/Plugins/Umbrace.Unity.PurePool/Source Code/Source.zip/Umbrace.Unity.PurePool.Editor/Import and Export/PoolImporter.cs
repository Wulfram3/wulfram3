﻿using System;
using System.IO;

using Umbrace.Unity.Contracts;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal abstract class PoolImporter<TSource, TInstance, TPoolSettings, TExportSettings, TPool>
		where TPool : PoolBase<TSource, TInstance, TPoolSettings>
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TExportSettings : ExportedPoolSettings<TSource, TPoolSettings> {

		/// <summary>
		/// When overridden in a derived class, gets the minimum version number that this importer supports.
		/// </summary>
		protected abstract Version MinimumSupportedVersion { get; }

		/// <summary>
		/// When overridden in a derived class, gets the maximum version number that this importer supports.
		/// </summary>
		protected abstract Version MaximumSupportedVersion { get; }

		/// <summary>
		/// When overridden in a derived class, gets the export sub-type that this importer supports.
		/// </summary>
		protected abstract string ExportSubType { get; }

		/// <summary>
		/// When overridden in a derived class, gets the display name of the type of pool that this importer supports.
		/// </summary>
		protected abstract string PoolTypeName { get; }

		/// <summary>
		/// Imports the settings from the specified file into the given pool.
		/// </summary>
		/// <param name="path">The path to the file to import.</param>
		/// <param name="pool">The pool to import the settings into.</param>
		public void Import(string path, TPool pool) {
			Contract.RequiresNotNull(path, nameof(path));
			Contract.RequiresNotNull(pool, nameof(pool));

			string message;

			TExportSettings importData = this.ReadImportData(path);

			Debug.Log($"Importing pool settings. Version {importData.Metadata.Version}.");

			// Ensure the settings being imported are from a supported version.
			try {
				this.EnsureVersion(importData.Metadata.Version);
			}
			catch (VersionNotSupportedException) {
				message = $"Failed to import the pool settings. The specified file contains settings in an unsupported version.{Environment.NewLine}{Environment.NewLine}" +
						$"File Version: {importData.Metadata.Version}{Environment.NewLine}" +
						$"Supported Versions: {this.MinimumSupportedVersion} to {this.MaximumSupportedVersion}{Environment.NewLine}" +
						$"File: {path}";
				Debug.LogError(message);
				EditorUtility.DisplayDialog("Import Error", message, "OK");
				return;
			}

			// Ensure the settings are for a supported type.
			try {
				this.EnsureExportType(importData.Metadata.ExportType, importData.Metadata.ExportSubType);
			}
			catch (ExportTypeMismatchException) {
				message = $"Failed to import the pool settings. The specified file does not contain settings for a {this.PoolTypeName} pool.{Environment.NewLine}{Environment.NewLine}" +
						$"File Version: {importData.Metadata.Version}{Environment.NewLine}" +
						$"Export Type: {importData.Metadata.ExportType}{Environment.NewLine}" +
						$"Export Sub-Type: {importData.Metadata.ExportSubType}{Environment.NewLine}" +
						$"File: {path}";
				Debug.LogError(message);
				EditorUtility.DisplayDialog("Import Error", message, "OK");
				return;
			}

			message = $"Importing will overwrite the existing settings of the pool. " +
					$"Are you sure you want to import the {this.PoolTypeName} settings?{Environment.NewLine}{Environment.NewLine}" +
					$"Importing From: {path}{Environment.NewLine}" +
					$"Importing To: {pool.transform.GetPath()}{Environment.NewLine}{Environment.NewLine}" +
					$"Export Date: {importData.Metadata.ExportDateTime}{Environment.NewLine}" +
					$"Exported From: {importData.Metadata.PoolGameObjectPath}";
			if (EditorUtility.DisplayDialog("Import Confirmation", message, "Import", "Cancel")) {
				this.ImportSettings(importData, pool);

				message = $"Successfully imported {this.PoolTypeName} settings to \"{pool.name}\".{Environment.NewLine}{Environment.NewLine}" +
						$"Export Date: {importData.Metadata.ExportDateTime}{Environment.NewLine}" +
						$"Exported From: {importData.Metadata.PoolGameObjectPath}";
				EditorUtility.DisplayDialog("Import Successful", message, "OK");
			}
		}

		private TExportSettings ReadImportData(string path) {
			string json = File.ReadAllText(path);

			return JsonUtility.FromJson<TExportSettings>(json);
		}

		/// <summary>
		/// Imports the specified settings into the specified pool.
		/// </summary>
		/// <param name="importData">The settings to import.</param>
		/// <param name="pool">The pool to import the settings into.</param>
		/// <exception cref="VersionNotSupportedException">If the version is not valid for this importer.</exception>
		/// <exception cref="ExportTypeMismatchException">If the export type and sub-type are not valid for this importer.</exception>
		internal void ImportSettings(TExportSettings importData, TPool pool) {
			// Ensure the settings being imported are from a supported version.
			this.EnsureVersion(importData.Metadata.Version);

			// Ensure the settings are for a supported type.
			this.EnsureExportType(importData.Metadata.ExportType, importData.Metadata.ExportSubType);

			Undo.RecordObject(pool, "Import Pool Settings");
			string poolSettings = JsonUtility.ToJson(importData.Settings);
			JsonUtility.FromJsonOverwrite(poolSettings, pool.Settings);
		}

		/// <summary>
		/// Ensures the specified version is valid for this importer.
		/// </summary>
		/// <param name="version">The version to check.</param>
		/// <exception cref="VersionNotSupportedException">If the version is not valid for this importer.</exception>
		private void EnsureVersion(Version version) {
			// Ensure the settings being imported are from a supported version.
			if (version < this.MinimumSupportedVersion || version > this.MaximumSupportedVersion) {
				string message = $"The specified file contains settings in an unsupported version.{Environment.NewLine}{Environment.NewLine}" +
								$"File Version: {version}{Environment.NewLine}" +
								$"Supported Versions: {this.MinimumSupportedVersion} to {this.MaximumSupportedVersion}";
				throw new VersionNotSupportedException(message);
			}
		}

		/// <summary>
		/// Ensures the specified export type and sub-type are valid for this importer.
		/// </summary>
		/// <param name="exportType">The export type to check.</param>
		/// <param name="exportSubType">The export sub-type to check.</param>
		/// <exception cref="ExportTypeMismatchException">If the export type and sub-type are not valid for this importer.</exception>
		private void EnsureExportType(string exportType, string exportSubType) {
			// Ensure the settings are for the correct pool sub-type.
			if (exportType != ExportType.Pool || exportSubType != this.ExportSubType) {
				string message = $"The specified file does not contain settings for a {this.PoolTypeName} pool.{Environment.NewLine}{Environment.NewLine}" +
								$"Export Type: {exportType}{Environment.NewLine}" +
								$"Export Sub-Type: {exportSubType}";
				throw new ExportTypeMismatchException(message);
			}
		}

	}

}