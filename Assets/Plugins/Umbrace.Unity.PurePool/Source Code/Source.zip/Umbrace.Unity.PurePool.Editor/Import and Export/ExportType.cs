﻿namespace Umbrace.Unity.PurePool.Editor {

	internal static class ExportType {

		internal static readonly string Pool = "Pool";
		internal static readonly string PoolManager = "Manager";

	}

}