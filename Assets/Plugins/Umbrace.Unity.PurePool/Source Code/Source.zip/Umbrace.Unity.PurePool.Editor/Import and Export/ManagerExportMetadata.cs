﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class ManagerExportMetadata {

		[SerializeField, HideInInspector]
		private SerialisableVersion version;

		[SerializeField, HideInInspector]
		private string exportType = "Manager";

		[SerializeField, HideInInspector]
		private string exportSubType;

		[SerializeField, HideInInspector]
		private string managerName;

		[SerializeField, HideInInspector]
		private string managerGameObjectPath;

		[SerializeField, HideInInspector]
		private SerialisableDateTimeOffset exportDateTime;

		public Version Version => this.version;

		public string ExportType => this.exportType;

		public string ExportSubType => this.exportSubType;

		public string ManagerName => this.managerName;

		public string ManagerGameObjectPath => this.managerGameObjectPath;

		public DateTimeOffset ExportDateTime => this.exportDateTime;

		public ManagerExportMetadata(Version version, string managerName, string managerGameObjectPath, DateTimeOffset exportDateTime, string exportSubType) {
			this.version = version;
			this.managerName = managerName;
			this.managerGameObjectPath = managerGameObjectPath;
			this.exportDateTime = exportDateTime;
			this.exportSubType = exportSubType;
		}

	}

}