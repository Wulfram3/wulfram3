﻿using System;
using System.IO;

using Umbrace.Unity.Contracts;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal abstract class PoolExporter<TSource, TInstance, TPoolSettings, TExportSettings, TPool>
		where TPool : PoolBase<TSource, TInstance, TPoolSettings>
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TExportSettings : ExportedPoolSettings<TSource, TPoolSettings> {

		/// <summary>
		/// When overridden in a derived class, gets the version number of this exporter.
		/// </summary>
		protected abstract Version Version { get; }

		/// <summary>
		/// When overridden in a derived class, gets the export sub-type of this exporter.
		/// </summary>
		protected abstract string ExportSubType { get; }

		/// <summary>
		/// When overridden in a derived class, gets the display name of the type of pool that this exporter supports.
		/// </summary>
		protected abstract string PoolTypeName { get; }

		/// <summary>
		/// Exports the settings from the specified pool into the given file.
		/// </summary>
		/// <param name="path">The path to the file to export to.</param>
		/// <param name="pool">The pool to export the settings from.</param>
		public void Export(string path, TPool pool) {
			Contract.RequiresNotNull(path, nameof(path));
			Contract.RequiresNotNull(pool, nameof(pool));

			var exportData = this.CreateExportData(pool);

			string json = JsonUtility.ToJson(exportData, true);

			try {
				File.WriteAllText(path, json);

				string message = $"Successfully exported {this.PoolTypeName} settings for \"{exportData.Metadata.PoolName}\".{Environment.NewLine}{Environment.NewLine}" +
								$"Export Date: {exportData.Metadata.ExportDateTime}{Environment.NewLine}" +
								$"Exported From: {exportData.Metadata.PoolGameObjectPath}";
				EditorUtility.DisplayDialog("Export Successful", message, "OK");
			} catch (Exception ex) {
				string message = $"Failed to export {this.PoolTypeName} settings for \"{exportData.Metadata.PoolName}\".{Environment.NewLine}{Environment.NewLine}" +
								$"Reason: {ex}";
				EditorUtility.DisplayDialog("Export Failed", message, "OK");
			}
		}

		internal TExportSettings CreateExportData(TPool pool) {
			var exportMetadata = new PoolExportMetadata(this.Version, pool.name, pool.transform.GetPath(), DateTimeOffset.Now, this.ExportSubType);
			var exportData = this.CreateExportDataInternal(exportMetadata, pool.Settings);

			return exportData;
		}

		/// <summary>
		/// When implemented in a derived class, creates the export data for the specified metadata and pool settings.
		/// </summary>
		/// <param name="metadata">The export metadata.</param>
		/// <param name="settings">The pool settings.</param>
		/// <returns>A <typeparamref name="TExportSettings"/> that contains the specified metadata and pool settings.</returns>
		protected abstract TExportSettings CreateExportDataInternal(PoolExportMetadata metadata, TPoolSettings settings);

	}

}