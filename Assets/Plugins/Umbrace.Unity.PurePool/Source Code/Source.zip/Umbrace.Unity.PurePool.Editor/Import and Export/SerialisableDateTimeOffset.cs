﻿using System;
using System.Globalization;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class SerialisableDateTimeOffset : ISerializationCallbackReceiver {

		private DateTimeOffset realDateTimeOffset;

		[SerializeField, HideInInspector]
		private string dateTimeOffset;

		public SerialisableDateTimeOffset(DateTimeOffset dateTimeOffset) {
			this.realDateTimeOffset = dateTimeOffset;
		}

		public SerialisableDateTimeOffset(DateTime dateTime, TimeSpan utcOffset) {
			this.realDateTimeOffset = new DateTimeOffset(dateTime, utcOffset);
		}

		public void OnAfterDeserialize() {
			this.realDateTimeOffset = DateTimeOffset.Parse(this.dateTimeOffset);
		}

		public void OnBeforeSerialize() {
			this.dateTimeOffset = this.realDateTimeOffset.ToString(CultureInfo.InvariantCulture);
		}

		public static implicit operator SerialisableDateTimeOffset(DateTimeOffset dt) {
			return new SerialisableDateTimeOffset(dt.DateTime, dt.Offset);
		}

		public static implicit operator DateTimeOffset(SerialisableDateTimeOffset dt) {
			return dt.realDateTimeOffset;
		}

	}

}