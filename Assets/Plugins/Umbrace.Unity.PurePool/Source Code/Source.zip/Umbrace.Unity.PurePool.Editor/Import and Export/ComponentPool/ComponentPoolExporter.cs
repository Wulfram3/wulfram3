﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class ComponentPoolExporter : PoolExporter<Type, Component, ComponentPoolSettings, ExportedComponentPoolSettings, ComponentPool> {
		
		/// <inheritdoc />
		protected override Version Version => new Version(1, 0);

		/// <inheritdoc />
		protected override string ExportSubType => Editor.ExportSubType.ComponentPool;

		/// <inheritdoc />
		protected override string PoolTypeName => nameof(ComponentPool);
		
		/// <inheritdoc />
		protected override ExportedComponentPoolSettings CreateExportDataInternal(PoolExportMetadata metadata, ComponentPoolSettings settings) {
			return new ExportedComponentPoolSettings(metadata, settings);
		}

	}

}