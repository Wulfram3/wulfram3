﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class SerialisableVersion {

		[SerializeField, HideInInspector]
		private int major;
		[SerializeField, HideInInspector]
		private int minor;
		[SerializeField, HideInInspector]
		private int build;
		[SerializeField, HideInInspector]
		private int revision;

		public int Major => this.major;
		public int Minor => this.minor;
		public int Build => this.build;
		public int Revision => this.revision;

		public SerialisableVersion(int major, int minor) : this(major, minor, -1) {

		}

		public SerialisableVersion(int major, int minor, int build) : this(major, minor, build, -1) {

		}

		public SerialisableVersion(int major, int minor, int build, int revision) {
			this.major = major;
			this.minor = minor;
			this.build = build;
			this.revision = revision;
		}

		public override string ToString() {
			return $"{this.major}.{this.minor}.{this.build}.{this.revision}";
		}

		public static implicit operator SerialisableVersion(Version v) {
			return new SerialisableVersion(v.Major, v.Minor, v.Build, v.Revision);
		}

		public static implicit operator Version(SerialisableVersion v) {
			if (v.Revision > -1) {
				return new Version(v.Major, v.Minor, v.Build, v.Revision);
			}
			if (v.Build > -1) {
				return new Version(v.Major, v.Minor, v.Build);
			}
			return new Version(v.Major, v.Minor);
		}

	}

}