﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal abstract class ExportedPoolSettings<TSource, TPoolSettings>
		where TPoolSettings : SharedPoolSettings<TSource>, new() {

		[SerializeField, HideInInspector]
		private PoolExportMetadata metadata;

		[SerializeField, HideInInspector]
		private TPoolSettings settings;

		public PoolExportMetadata Metadata => this.metadata;

		public TPoolSettings Settings => this.settings;

		protected ExportedPoolSettings(PoolExportMetadata metadata, TPoolSettings settings) {
			this.metadata = metadata;
			this.settings = settings;
		}

	}

}