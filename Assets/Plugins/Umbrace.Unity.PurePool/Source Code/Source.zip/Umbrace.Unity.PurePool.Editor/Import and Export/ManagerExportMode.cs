﻿namespace Umbrace.Unity.PurePool.Editor {

	internal enum ManagerExportMode {

		ManagerSettingsOnly,

		ManagerSettingsWithPools

	}

}