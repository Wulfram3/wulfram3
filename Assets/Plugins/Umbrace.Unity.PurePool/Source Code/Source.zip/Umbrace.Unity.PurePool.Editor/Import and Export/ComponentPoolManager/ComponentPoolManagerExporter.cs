﻿using System;
using System.Collections.Generic;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class ComponentPoolManagerExporter : PoolManagerExporter<ComponentPoolManager, ComponentPoolManagerSettings, ComponentPool, ComponentPoolSettings, ExportedComponentManagerSettings, ExportedComponentPoolSettings, ComponentPoolExporter, Type, Component> {

		/// <inheritdoc />
		protected override Version Version => new Version(1, 0);

		/// <inheritdoc />
		protected override string ExportSubType => Editor.ExportSubType.ComponentPoolManager;

		/// <inheritdoc />
		protected override string PoolManagerTypeName => nameof(ComponentPoolManager);
		
		/// <inheritdoc />
		protected override ComponentPoolExporter CreatePoolExporter() {
			return new ComponentPoolExporter();
		}

		/// <inheritdoc />
		protected override ExportedComponentManagerSettings CreateExportedManagerSettings(ManagerExportMetadata metadata, ComponentPoolManagerSettings managerSettings) {
			return new ExportedComponentManagerSettings(metadata, managerSettings);
		}

		/// <inheritdoc />
		protected override ExportedComponentManagerSettings CreateExportedManagerSettings(ManagerExportMetadata metadata, ComponentPoolManagerSettings managerSettings, IEnumerable<ExportedComponentPoolSettings> poolSettings) {
			return new ExportedComponentManagerSettings(metadata, managerSettings, poolSettings);
		}

	}

}