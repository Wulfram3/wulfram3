﻿using System;
using System.Diagnostics.CodeAnalysis;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[CustomEditor(typeof(GameObjectPool))]
	[CanEditMultipleObjects]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal class GameObjectPoolEditor : BasePoolEditor<GameObjectPool, GameObjectPoolDrawer, GameObject, GameObject, GameObjectPoolSettings> {
		
		#region Fields.
		private SerializedProperty instantiatedEventProp;
		private SerializedProperty acquiredEventProp;
		private SerializedProperty releasedEventProp;
		private SerializedProperty destroyedEventProp;
		#endregion

		#region BasePoolEditor overrides.
		protected override void OnEnable() {
			base.OnEnable();

			this.instantiatedEventProp = this.serializedObject.FindProperty(nameof(GameObjectPool.ObjectInstantiatedEvent));
			this.acquiredEventProp = this.serializedObject.FindProperty(nameof(GameObjectPool.ObjectAcquiredEvent));
			this.releasedEventProp = this.serializedObject.FindProperty(nameof(GameObjectPool.ObjectReleasedEvent));
			this.destroyedEventProp = this.serializedObject.FindProperty(nameof(GameObjectPool.ObjectDestroyedEvent));
		}

		protected override GameObjectPoolDrawer CreatePoolDrawer() {
			return new GameObjectPoolDrawer(this.serializedObject, "currentSettings");
			//return new GameObjectPoolDrawer();
		}

		protected override void DrawUnityEvents() {
			this.eventsExpanded.TargetValue = EditorGUILayout.Foldout(this.eventsExpanded, "UnityEvents", true, this.boldFoldoutStyle);
			if (this.eventsExpanded) {
				EditorGUILayout.PropertyField(this.instantiatedEventProp);
				EditorGUILayout.PropertyField(this.acquiredEventProp);
				EditorGUILayout.PropertyField(this.releasedEventProp);
				EditorGUILayout.PropertyField(this.destroyedEventProp);
			}
		}
		#endregion

		#region Importing and exporting.
		[MenuItem("CONTEXT/GameObjectPool/Export Pool Settings")]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void ExportPoolSettings(MenuCommand menuCommand) {
			var pool = menuCommand.context as GameObjectPool;
			if (pool == null) return;

			// Choose the file to save the pool settings to.
			string path = EditorUtility.SaveFilePanel("Export Pool Settings", String.Empty, pool.name, "json");

			if (path.Length != 0) {
				var exporter = new GameObjectPoolExporter();
				exporter.Export(path, pool);
			}
		}

		[MenuItem("CONTEXT/GameObjectPool/Export Pool Settings", true)]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static bool ValidateExportPoolSettings() {
			// Only allow exporting of settings when a single pool is selected.
			return Selection.objects.Length == 1;
		}

		[MenuItem("CONTEXT/GameObjectPool/Import Pool Settings")]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void ImportPoolSettings(MenuCommand menuCommand) {
			var pool = menuCommand.context as GameObjectPool;
			if (pool == null) return;

			// Choose the file to load the pool settings from.
			string path = EditorUtility.OpenFilePanel("Import Pool Settings", String.Empty, "json");

			if (path.Length != 0) {
				var importer = new GameObjectPoolImporter();
				importer.Import(path, pool);
			}
		}

		[MenuItem("CONTEXT/GameObjectPool/Import Pool Settings", true)]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static bool ValidateImportPoolSettings() {
			// Only allow importing of settings when a single pool is selected.
			return Selection.objects.Length == 1;
		}
		#endregion

	}

}