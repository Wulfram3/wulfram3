﻿using System;
using System.Collections.Generic;
using System.Linq;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class ManagerGameObjectPoolDrawer : GameObjectPoolDrawer {

		private readonly GameObjectPoolManager manager;

		public ManagerGameObjectPoolDrawer(GameObjectPoolManager manager, SerializedObject serializedObject, string root) : base(serializedObject, root) {
			this.manager = manager;
		}
		
		public ManagerGameObjectPoolDrawer(GameObjectPoolManager manager, Action<GameObjectPool, GameObject> changeSourceAction) : base(changeSourceAction) {
			this.manager = manager;
		}

		protected override void DrawPoolAdditionalActions(IEnumerable<KeyValuePair<GameObjectPoolSettings, GameObjectPool>> pools) {
			base.DrawPoolAdditionalActions(pools);

			if (pools.Any(kvp => kvp.Value.IsInitialised)) {
				// Draw the Attach and Detach buttons.
				if (pools.Any(kvp => !this.manager.IsAttached(kvp.Value))) {
					// Disable the Attach button if the manager already has a pool that handles the object.
					EditorGUI.BeginDisabledGroup(pools.Any(kvp => this.manager.HasPool(kvp.Value.Source)));
					if (GUILayout.Button(new GUIContent("Attach", "Attach the pool to the manager."))) {
						foreach (var pool in pools.Select(kvp => kvp.Value).Where(p => p.IsInitialised)) {
							this.manager.AttachPool(pool);
						}
					}
					EditorGUI.EndDisabledGroup();
				}
				if (pools.Any(kvp => this.manager.IsAttached(kvp.Value))) {
					if (GUILayout.Button(new GUIContent("Detach", "Detach the pool from the manager."))) {
						foreach (var pool in pools.Select(kvp => kvp.Value).Where(p => p.IsInitialised)) {
							this.manager.DetachPool(pool);
						}
					}
				}
			}

		}

	}

}