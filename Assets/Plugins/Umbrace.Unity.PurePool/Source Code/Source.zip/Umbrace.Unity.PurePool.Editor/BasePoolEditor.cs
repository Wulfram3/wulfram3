﻿using System.Diagnostics.CodeAnalysis;
using System.Linq;

using Umbrace.Unity.PurePool.ForEditor;

using UnityEditor;
using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal abstract class BasePoolEditor<TPool, TPoolDrawer, TSource, TInstance, TPoolSettings> : UnityEditor.Editor 
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TPool : PoolBase<TSource, TInstance, TPoolSettings>
		where TPoolDrawer : PoolDrawer<TPool, TSource, TInstance, TPoolSettings>
		where TSource : class {

		#region Constants.
		private const float MinimumLabelWidth = 180;
		#endregion

		#region Fields.
		private TPool[] pools;
		private TPoolDrawer drawer;

		private PoolSettingsComponent poolSettingsComponent;
		private BoolEditorChangeValue definitionExpanded;
		private BoolEditorChangeValue statisticsExpanded;
		private BoolEditorChangeValue settingsExpanded;
		protected BoolEditorChangeValue eventsExpanded;
		
		protected GUIStyle boldFoldoutStyle;
		#endregion

		#region Editor methods.
		[SuppressMessage("ReSharper", "UnusedMemberHierarchy.Global")]
		protected virtual void OnEnable() {
			this.pools = this.targets.Cast<TPool>().ToArray();
			this.drawer = this.CreatePoolDrawer();

			this.poolSettingsComponent = GameObjectHelper.GetHiddenComponent<PoolSettingsComponent>();

			this.definitionExpanded = this.poolSettingsComponent.PoolSettings.DefinitionExpanded;
			this.statisticsExpanded = this.poolSettingsComponent.PoolSettings.StatisticsExpanded;
			this.settingsExpanded = this.poolSettingsComponent.PoolSettings.ShowDetails;
			this.eventsExpanded = this.poolSettingsComponent.PoolSettings.EventsExpanded;
		}

		public override void OnInspectorGUI() {
			this.serializedObject.Update();

			// Set up the styles that are needed.
			this.boldFoldoutStyle = this.boldFoldoutStyle ?? new GUIStyle(EditorStyles.foldout) {
				fontStyle = FontStyle.Bold
			};
			this.poolSettingsComponent.ChangeValues();

			// Set the minimum label width to be larger than the default, so the labels aren't cut off.
			using (new LabelWidthGroup(MinimumLabelWidth)) {
				this.DrawDefaultInspector();

				// Draw the Enabled toggle button for the pools.
				this.drawer.DrawSetting(this.pools,
					this.serializedObject.FindProperty("currentSettings.isPoolingEnabled"),
					p => p.Enabled,
					(rect, p) => EditorGUI.Toggle(rect, "Pooling Enabled", p.Enabled),
					(pool, newValue) => pool.Enabled = newValue
				);

				if (this.pools.All(p => !p.Enabled)) {
					EditorGUILayout.HelpBox("Pooling is currently disabled. " +
											$"The pool will appear empty, and acquiring from it will only work if {nameof(ComponentPool.InstantiateWhenEmpty)} is true.", MessageType.Warning);
				} else if (this.pools.Any(p => !p.Enabled)) {
					EditorGUILayout.HelpBox("Pooling is currently disabled for some pools. " +
											$"These pools will appear empty, and acquiring from them will only work if {nameof(ComponentPool.InstantiateWhenEmpty)} is true.", MessageType.Warning);
				}

				this.DrawDefinition();

				this.DrawUnityEvents();

				this.serializedObject.SetIsDifferentCacheDirty();
				this.serializedObject.ApplyModifiedProperties();
			}
		}

		public override bool RequiresConstantRepaint() {
			// Repaint the editor constantly while the statistics are shown, as the statistics will always be updating.
			return base.RequiresConstantRepaint() || (this.statisticsExpanded && this.pools.Any(p => p.IsInitialised));
		}
		#endregion

		#region Private methods.
		private void DrawDefinition() {
			// If the pool has been initialised, draw the pool's definition (the settings that were used to initialise it).
			if (this.pools.Any(p => p.IsInitialised)) {
				this.definitionExpanded.TargetValue = EditorGUILayout.Foldout(this.definitionExpanded, "Definition", true, this.boldFoldoutStyle);
				if (this.definitionExpanded) {
					this.DrawInitialisedPoolDefinition(true);
				}

				this.statisticsExpanded.TargetValue = EditorGUILayout.Foldout(this.statisticsExpanded, "Statistics", true, this.boldFoldoutStyle);
				if (this.statisticsExpanded) {
					this.DrawInitialisedPoolStatistics();
				}
			}

			this.settingsExpanded.TargetValue = EditorGUILayout.Foldout(this.settingsExpanded, "Settings", true, this.boldFoldoutStyle);
			if (this.settingsExpanded) {
				// Draw the main controls for the pool - this includes things that will be drawn only when the pool hasn't been initialised, as well as those that are drawn all the time.
				this.DrawPoolMain(true);
			}
		}

		private void DrawInitialisedPoolDefinition(bool drawAdvanced = true) {
			// Show a helpful explanation of what the pool definition is.
			EditorGUILayout.HelpBox("The definition shows the values that the pool had at the time it was initialised. You can use it to compare the current values of the pool with its initial values.", MessageType.Info);

			// The definition cannot be changed, so disable the controls.
			EditorGUI.BeginDisabledGroup(true);
			this.drawer.DrawPoolDefinition(this.pools.Where(p => p.IsInitialised), drawAdvanced);
			EditorGUI.EndDisabledGroup();
		}

		private void DrawInitialisedPoolStatistics() {
			this.drawer.TimeDisplayMode = this.poolSettingsComponent.TimeDisplayMode;
			this.drawer.DrawPoolStatistics(this.pools);
			this.poolSettingsComponent.TimeDisplayMode = this.drawer.TimeDisplayMode;
		}

		private void DrawPoolMain(bool drawAdvanced = true) {
			this.drawer.DrawPool(this.pools, drawAdvanced);
		}
		#endregion

		#region Abstract methods.
		/// <summary>
		/// When implemented in a derived class, creates the pool drawer.
		/// </summary>
		/// <returns>An instance of the drawer for <typeparamref name="TPool"/> pools.</returns>
		protected abstract TPoolDrawer CreatePoolDrawer();

		/// <summary>
		/// When implemented in a derived class, draws the Unity Events controls for the pools.
		/// </summary>
		protected abstract void DrawUnityEvents();
		#endregion

	}

}