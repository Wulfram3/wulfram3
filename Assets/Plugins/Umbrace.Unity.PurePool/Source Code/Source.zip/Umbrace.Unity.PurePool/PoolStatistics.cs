﻿using System;

using Umbrace.Unity.Contracts;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains general operational statistics about an object pool.
	/// </summary>
	[Serializable]
	public class PoolStatistics {

		#region Fields.
		[SerializeField, HideInInspector] private int objectsAliveInsideAndOutsidePool;
		[SerializeField, HideInInspector] private int objectsAliveOutsidePool;

		[SerializeField, HideInInspector] private int instantiationCount;
		[SerializeField, HideInInspector] private int destructionCount;
		[SerializeField, HideInInspector] private int acquireCount;
		[SerializeField, HideInInspector] private int releaseCount;
		[SerializeField, HideInInspector] private int highestAliveCount;

		[SerializeField, HideInInspector] private int recommendedPoolSize;

		[SerializeField, HideInInspector] private TimeInstant initialisedTime;
		[SerializeField, HideInInspector] private bool initialisedTimeHasValue;
		[SerializeField, HideInInspector] private TimeInstant lastAcquireTime;
		[SerializeField, HideInInspector] private bool lastAcquireTimeHasValue;
		[SerializeField, HideInInspector] private TimeInstant lastReleaseTime;
		[SerializeField, HideInInspector] private bool lastReleaseTimeHasValue;
		[SerializeField, HideInInspector] private TimeInstant lastInstantiateTime;
		[SerializeField, HideInInspector] private bool lastInstantiateTimeHasValue;
		[SerializeField, HideInInspector] private TimeInstant lastDestroyTime;
		[SerializeField, HideInInspector] private bool lastDestroyTimeHasValue;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets the number of objects currently owned by the pool, including both those in the pool and those acquired from, but not yet returned to, the pool.
		/// </summary>
		public int ObjectsAliveInsideAndOutsidePool {
			get => this.objectsAliveInsideAndOutsidePool;
			internal set => this.objectsAliveInsideAndOutsidePool = value < 0 ? 0 : value;
		}

		/// <summary>
		/// Gets the number of objects currently owned by the pool that have been acquired from, but not yet returned to, the pool.
		/// </summary>
		public int ObjectsAliveOutsidePool {
			get => this.objectsAliveOutsidePool;
			internal set => this.objectsAliveOutsidePool = value < 0 ? 0 : value;
		}

		/// <summary>
		/// Gets the number of objects that have been instantiated by the pool when the pool was empty.
		/// </summary>
		public int InstantiationCount {
			get => this.instantiationCount;
			internal set => this.instantiationCount = value < 0 ? 0 : value;
		}

		/// <summary>
		/// Gets the number of objects that have been destroyed by the pool when the pool was full.
		/// </summary>
		public int DestructionCount {
			get => this.destructionCount;
			internal set => this.destructionCount = value < 0 ? 0 : value;
		}

		/// <summary>
		/// Gets the number of times that objects have been acquired from the pool, without instantiation.
		/// </summary>
		public int AcquireCount {
			get => this.acquireCount;
			internal set => this.acquireCount = value < 0 ? 0 : value;
		}

		/// <summary>
		/// Gets the number of times that objects have been released to the pool, without destruction.
		/// </summary>
		public int ReleaseCount {
			get => this.releaseCount;
			internal set => this.releaseCount = value < 0 ? 0 : value;
		}

		/// <summary>
		/// Gets the highest count of objects owned by the pool at any one time.
		/// </summary>
		/// <remarks>This value represents the size that the pool would have had to have been upon initialisation, to avoid instantiations being made at runtime.</remarks>
		public int HighestAliveCount {
			get => this.highestAliveCount;
			internal set => this.highestAliveCount = value < 0 ? 0 : value;
		}

		/// <summary>
		/// Gets the recommended size that the pool should have been at initialisation time, to avoid instantiations.
		/// </summary>
		public int RecommendedPoolSize {
			get => this.recommendedPoolSize;
			internal set => this.recommendedPoolSize = value < 0 ? 0 : value;
		}

		/// <summary>
		/// Gets the time at which the pool was initialised.
		/// </summary>
		public TimeInstant? InitialisedTime {
			get => this.initialisedTimeHasValue ? this.initialisedTime : (TimeInstant?)null;
			internal set {
				if (value.HasValue) {
					this.initialisedTime = value.Value;
				}
				this.initialisedTimeHasValue = value.HasValue;
			}
		}

		/// <summary>
		/// Gets the time at which an object was last acquired from the pool.
		/// </summary>
		public TimeInstant? LastAcquireTime {
			get => this.lastAcquireTimeHasValue ? this.lastAcquireTime : (TimeInstant?)null;
			internal set {
				if (value.HasValue) {
					this.lastAcquireTime = value.Value;
				}
				this.lastAcquireTimeHasValue = value.HasValue;
			}
		}

		/// <summary>
		/// Gets the time at which an object was last released to the pool.
		/// </summary>
		public TimeInstant? LastReleaseTime {
			get => this.lastReleaseTimeHasValue ? this.lastReleaseTime : (TimeInstant?)null;
			internal set {
				if (value.HasValue) {
					this.lastReleaseTime = value.Value;
				}
				this.lastReleaseTimeHasValue = value.HasValue;
			}
		}

		/// <summary>
		/// Gets the time at which an object was last instantiated by the pool.
		/// </summary>
		public TimeInstant? LastInstantiateTime {
			get => this.lastInstantiateTimeHasValue ? this.lastInstantiateTime : (TimeInstant?)null;
			internal set {
				if (value.HasValue) {
					this.lastInstantiateTime = value.Value;
				}
				this.lastInstantiateTimeHasValue = value.HasValue;
			}
		}

		/// <summary>
		/// Gets the time at which an object was last destroyed by the pool.
		/// </summary>
		public TimeInstant? LastDestroyTime {
			get => this.lastDestroyTimeHasValue ? this.lastDestroyTime : (TimeInstant?)null;
			internal set {
				if (value.HasValue) {
					this.lastDestroyTime = value.Value;
				}
				this.lastDestroyTimeHasValue = value.HasValue;
			}
		}
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="PoolStatistics"/> class.
		/// </summary>
		internal PoolStatistics() {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolStatistics"/> class.
		/// </summary>
		/// <param name="other">The pool statistics to copy values from.</param>
		internal PoolStatistics(PoolStatistics other) {
			Contract.RequiresNotNull(other, nameof(other));

			this.CopyFrom(other);
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Copies the statistics from another object into this one, overwriting the existing statistics.
		/// </summary>
		/// <param name="other">The <see cref="PoolStatistics"/> object to copy values from.</param>
		internal void CopyFrom(PoolStatistics other) {
			Contract.RequiresNotNull(other, nameof(other));

			this.objectsAliveInsideAndOutsidePool = other.objectsAliveInsideAndOutsidePool;
			this.objectsAliveOutsidePool = other.objectsAliveOutsidePool;

			this.instantiationCount = other.instantiationCount;
			this.destructionCount = other.destructionCount;
			this.acquireCount = other.acquireCount;
			this.releaseCount = other.releaseCount;

			this.highestAliveCount = other.highestAliveCount;
			this.recommendedPoolSize = other.recommendedPoolSize;

			this.InitialisedTime = other.InitialisedTime;
			this.LastAcquireTime = other.LastAcquireTime;
			this.LastReleaseTime = other.LastReleaseTime;
			this.LastInstantiateTime = other.LastInstantiateTime;
			this.LastDestroyTime = other.LastDestroyTime;
		}
		#endregion

	}

}