﻿using System;
using System.Collections.Generic;

using Umbrace.Unity.Contracts;

using UnityEngine;

using Debug = System.Diagnostics.Debug;
using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A serialisable object pool for <see cref="GameObject"/>-type objects.
	/// </summary>
	/// <remarks>
	/// <para>
	/// By virtue of being serialisable, <see cref="SerialisableGameObjectPool"/> can survive an assembly reload caused by live recompilation
	/// inside of the Unity editor.
	/// </para>
	/// <para>
	/// <see cref="SerialisableGameObjectPool"/> achieves this by serialising the instances of the object that were contained in the pool,
	/// and then re-adding them to the pool after deserialisation.
	/// </para>
	/// <para>
	/// To use the <see cref="SerialisableGameObjectPool"/>, initialise a new instance using the constructor, and then set the properties to appropriate values.
	/// Once all properties have been set, invoke the <see cref="SerialisableObjectPool{T}.Initialise()"/> method. A pool cannot be used without being initialised in this way.
	/// </para>
	/// </remarks>
	/// <example>
	/// <code language="cs">
	/// // Create the pool.
	/// var pool = new SerialisableGameObjectPool(prefab, parentContainer) {
	/// 	InitialSize = 50,
	/// 	MaximumSize = 200,
	/// 	InstantiateWhenEmpty = true,
	/// 	NotificationMode = NotificationMode.Interface,
	/// 	LogMessages = LogLevel.Warning
	/// };
	/// 
	/// // Initialise the pool. It will contain 50 objects.
	/// pool.Initialise();
	/// 
	/// // Acquire one of the 50 objects from the pool. The Acquire method can be used safely if InstantiateWhenEmpty is true, or if a check is made to CanAcquire beforehand.
	/// GameObject instance = pool.Acquire();
	/// 
	/// // Acquire one of the 49 remaining objects from the pool. TryAcquire can be used safely even when InstantiateWhenEmpty is false.
	/// GameObject secondInstance;
	/// if (pool.TryAcquire(out secondInstance)) {
	/// 	// Release the object back to the pool. It now contains 49 objects again.
	/// 	pool.Release(secondInstance);
	///	}
	/// 
	/// // Release the object back to the pool. It now contains 50 objects.
	/// pool.Release(instance);
	/// </code>
	/// </example>
	/// <seealso cref="SerialisableObjectPool{T}"/>
	/// <seealso cref="GameObjectPool"/>
	[Serializable]
	public class SerialisableGameObjectPool : SerialisableObjectPool<GameObject> {

		// TODO: Replace all GetComponent<PoolableGameObject> calls with cache lookups?

		#region Fields.
		/// <summary>
		/// The object to be pooled.
		/// </summary>
		[SerializeField, HideInInspector]
		private GameObject sourceObject;

		/// <summary>
		/// The parent transform to which all pooled objects will be parented in the hierarchy,
		/// if <see cref="reparentPooledObjects"/> is <see langword="true"/>.
		/// </summary>
		[SerializeField, HideInInspector]
		private Transform parent;

		/// <summary>
		/// The way in which pooled objects are notified about being acquired from, and returned to, the pool.
		/// </summary>
		[SerializeField, HideInInspector]
		private NotificationMode notificationMode = NotificationMode.Interface;

		/// <summary>
		/// Whether to re-parent the pooled objects to the <see cref="parent"/> transform,
		/// after the objects are returned to the pool.
		/// </summary>
		[SerializeField, HideInInspector]
		private bool reparentPooledObjects = true;

		/// <summary>
		/// Whether to log a warning message when a poolable object is destroyed (either inside of the pool, or while in use).
		/// </summary>
		[SerializeField, HideInInspector]
		private bool warnOnDestroy = true;

		/// <summary>
		/// A dictionary mapping pooled objects to their PoolableObject component. This is necessary as we can't use GetComponent from OnAfterDeserialize.
		/// </summary>
		[SerializeField, HideInInspector]
		private GameObjectToPoolableObjectDictionary gameObjectToPoolable = new GameObjectToPoolableObjectDictionary();

		/// <summary>
		/// The objects contained by the pool at the time the pool was serialised by Unity.
		/// </summary>
		[SerializeField, HideInInspector]
		private List<GameObject> serialisedGameObjects;

		/// <summary>
		/// A cached copy of the source object's Transform component, for performance reasons.
		/// </summary>
		[SerializeField, HideInInspector]
		private Transform sourceObjectTransform;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets the source object that is being pooled.
		/// </summary>
		public GameObject SourceObject => this.sourceObject;

		/// <summary>
		/// Gets or sets the parent transform to which all pooled objects will be parented in the hierarchy,
		/// if <see cref="ReparentPooledObjects"/> is <see langword="true"/>.
		/// </summary>
		/// <seealso cref="ReparentPooledObjects"/>
		public Transform Parent {
			get => this.parent;
			set {
				this.parent = value;

				// Update the parent transform for all objects in the pool.
				foreach (var instance in this.Items) {
					instance.transform.SetParent(value, false);
				}
			}
		}

		/// <summary>
		/// Gets or sets the way in which pooled objects are notified about being acquired from, and returned to, the pool.
		/// Cannot be set once the pool has been initialised.
		/// </summary>
		public NotificationMode NotificationMode {
			get => this.notificationMode;
			set {
				Contract.Requires(!this.IsInitialised, $"The {nameof(this.NotificationMode)} property cannot be set once the pool has been initialised.");
				this.notificationMode = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to re-parent the pooled objects to the <see cref="Parent"/> transform,
		/// after the objects are returned to the pool.
		/// </summary>
		/// <remarks>
		/// Re-parenting is enabled by default and is the safest option, but comes with a small performance penalty.
		/// Disabling re-parenting provides the best performance but there is the increased risk of any of the objects being affected
		/// by other scripts. As the objects will be parented beneath various other objects, deleting of an unrelated object
		/// may cause the pooled object to also be deleted.
		/// You should pay great attention to what objects you destroy if re-parenting is disabled.
		/// </remarks>
		/// <seealso cref="Parent"/>
		public bool ReparentPooledObjects {
			get => this.reparentPooledObjects;
			set => this.reparentPooledObjects = value;
		}

		/// <summary>
		/// Gets or sets a value indicating whether to log a warning message when a poolable object is destroyed (either inside of the pool, or while in use).
		/// </summary>
		/// <remarks>
		/// <para>
		/// Poolable objects should be released to the pool and re-used, rather than being destroyed.
		/// This property ensures any destruction of the pooled objects is logged.
		/// </para>
		/// <para>
		/// Unfortunately, scene changes may also cause pooled objects to be destroyed. In this case, the warning message will be shown incorrectly,
		/// and can safely be ignored.
		/// </para>
		/// </remarks>
		public bool WarnOnDestroy {
			get => this.warnOnDestroy;
			set => this.warnOnDestroy = value;
		}

		/// <summary>
		/// Gets a cached copy of the source object's Transform component, for performance reasons.
		/// </summary>
		private Transform SourceTransform {
			get {
				// Use the cached transform if available, or take it from the source object and then cache it.
				// Don't use the null-coalescing operator (??) here, since it doesn't make use of Unity's overridden equality operator.
				// ReSharper disable once ConvertIfStatementToNullCoalescingExpression
				if (this.sourceObjectTransform == null) {
					this.sourceObjectTransform = this.SourceObject.transform;
				}
				
				return this.sourceObjectTransform;
			}
		}

		/// <summary>
		/// Gets a value indiciating whether to refill the pool with new objects after the pool is reinitialised,
		/// as happens from deserialisation.
		/// </summary>
		protected override bool RefillPoolOnReinitialise => false; // We don't want the pool to be refilled with new objects, as we can just re-add the serialised objects.
		#endregion

		#region Constructor.
		/// <summary>
		/// Initialises a new instance of the <see cref="SerialisableGameObjectPool"/> class.
		/// </summary>
		/// <param name="sourceObject">The object to be pooled.</param>
		/// <param name="parent">The parent transform to which all pooled <see cref="GameObject"/> objects will be parented in the hierarchy.</param>
		public SerialisableGameObjectPool(GameObject sourceObject, Transform parent) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			
			this.sourceObject = sourceObject;
			this.parent = parent;
			this.serialisedGameObjects = new List<GameObject>();
		}
		#endregion

		#region SerialisableObjectPool overrides.
		/// <inheritdoc />
		protected override Func<GameObject> GetObjectFactory() {
			return () => {
				// Create a new instance of the source object.
				GameObject instance = Object.Instantiate(this.sourceObject);

				// Optionally, parent the instance to belong to the pool.
				if (this.ReparentPooledObjects) {
					instance.transform.SetParent(this.parent, false);
				}

				// Attach the PoolableObject component to the new instance.
				// This component allows us to ensure only instances of the source object can be returned to this pool.
				// It also allows other components on the object to run code when the object is released to the pool, to reset their state.
				var poolable = instance.AddComponent<PoolableGameObject>(); // TODO: Check if PoolableGameObject component is already on the prefab? Maybe some settings could be set up on it in advance.
				poolable.SourceObject = this.sourceObject;
				poolable.NotificationMode = this.notificationMode;
				poolable.IsInPool = true;
				poolable.CachePoolableComponents = true;
				poolable.Destroyed += this.HandlePoolObjectDestroyed; // This event handler is re-added in OnAfterDeserialize, since it can't be serialised.
				poolable.Initialised = true;

				// Disable the object whilst in the pool.
				instance.SetActive(false);

				this.gameObjectToPoolable[instance] = poolable;

				return instance;
			};
		}

		/// <inheritdoc />
		protected override void OnObjectAcquired(GameObject instance, bool instantiated) {
			// Shouldn't need to check if the GameObject is null (been destroyed while in pool).
			// A handler already exists for the Destroyed event that removes the object from the pool.

			// Set the pooled object's active state back to that of the source object.
			instance.SetActive(this.SourceObject.activeSelf);

			// Reinitialise the transform and detach it from the pool container.
			instance.Set(null, this.SourceTransform.position, this.SourceTransform.rotation); // TODO: This changing of the parent transform can be unnecessary, as the parent is set in some of the Acquire methods.

			// Tell the components on the object to reinitialise themselves.
			var poolable = instance.GetComponent<PoolableGameObject>();
			poolable.IsInPool = false;
			poolable.OnAcquire();

			base.OnObjectAcquired(instance, instantiated);
		}

		/// <inheritdoc />
		protected override void OnObjectReleased(GameObject instance, bool destroying) {
			// If the object is about to be destroyed, we don't need to do anything to it.
			if (!destroying) {
				// Get the PoolableGameObject component, which allows the components on the game object to carry out actions when being released to the pool.
				var poolable = instance.GetComponent<PoolableGameObject>();

				// If the PoolableGameObject component has not been initialised yet (object may have been placed in the scene), initialise it now.
				if (!poolable.Initialised) {
					poolable.NotificationMode = this.notificationMode;
					poolable.CachePoolableComponents = true;
					poolable.Destroyed += this.HandlePoolObjectDestroyed;
					this.gameObjectToPoolable[instance] = poolable;

					poolable.Initialised = true;
				}

				poolable.IsInPool = true;
				poolable.OnRelease();

				// Disable the object whilst in the pool.
				instance.SetActive(false);

				// Optionally attach the object to the pool container.
				if (this.ReparentPooledObjects) {
					instance.transform.SetParent(this.parent, false);
				}
			}

			base.OnObjectReleased(instance, destroying);
		}

		/// <inheritdoc />
		protected override void OnObjectDestroyed(GameObject instance) {
			base.OnObjectDestroyed(instance);

			// Get the PoolableObject component, which allows the components on the game object to carry out actions when being released to the pool.
			var poolable = instance.GetComponent<PoolableGameObject>();
			poolable.Destroyed -= this.HandlePoolObjectDestroyed;

			this.gameObjectToPoolable.Remove(instance);

			Object.Destroy(instance);
		}

		/// <inheritdoc />
		protected override void OnBeforeSerialize() {
			base.OnBeforeSerialize();

			// Remember the game objects that belong to the pool - Unity will serialise them as part of the scene,
			// and we'll need to re-add them to the pool after deserialisation.
			if (this.IsInitialised) {
				this.serialisedGameObjects.Clear();
				this.serialisedGameObjects.AddRange(this.Items);
			}
		}

		/// <inheritdoc />
		protected override void OnAfterDeserialize() {
			// Deserialise as normal. RefillPoolOnReinitialise is false to prevent the base method from trying to recreate the game objects.
			base.OnAfterDeserialize();

			// Add the serialised game objects back to the pool.
			foreach (var serialisedGameObject in this.serialisedGameObjects) {
				this.InternalAdd(serialisedGameObject);

				// Re-add the event handlers, as event handlers aren't serialised.
				this.gameObjectToPoolable[serialisedGameObject].Destroyed += this.HandlePoolObjectDestroyed;
			}
			this.serialisedGameObjects.Clear();
		}

		/// <inheritdoc />
		protected override void ReleaseInternal(GameObject instance) {
			// Get the PoolableGameObject component, which allows the components on the game object to carry out actions when being released to the pool.
			var poolable = instance.GetComponent<PoolableGameObject>(); // TODO: The PoolableGameObject component is also retrieved in the OnObjectReleased method, duplicating the GetComponent call.

			// Ensure the object being returned has a PoolableGameObject component, otherwise we can't verify that it belongs to the pool.
			if (poolable == null) {
				DebugHelper.LogError(this.LogMessages, $"Unable to release a game object ('{instance.name}') to the pool without a {nameof(PoolableGameObject)} component on it. " +
														"The object may not have originated from this pool. The game object has been destroyed.");
				Object.Destroy(instance);
				return;
			}

			// Ensure the object being returned is an instance of the pool's source object.
			if (poolable.SourceObject != this.SourceObject) {
				DebugHelper.LogError(this.LogMessages, "Unable to release a game object to the pool due to source object mismatch. " +
														$"The object didn't originate from this pool. The game object has been destroyed.{Environment.NewLine}" +
														$"Pool contains '{this.SourceObject.name}' objects, but game object is '{poolable.SourceObject?.name ?? "null"}'.");
				Object.Destroy(instance);
				return;
			}

			base.ReleaseInternal(instance);
		}
		#endregion

		#region Acquire methods.
		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of the source object, <see cref="SourceObject"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Transform, out GameObject)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public GameObject Acquire(Transform parent) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.Acquire(parent, false);
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <returns>An instance of the source object, <see cref="SourceObject"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Transform, out GameObject)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public GameObject Acquire(Transform parent, bool spawnInWorldSpace) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			GameObject instance = this.Acquire();
			Debug.Assert(instance != null);
			instance.Set(parent, spawnInWorldSpace);

			return instance;
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <returns>An instance of the source object, <see cref="SourceObject"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Vector3, Quaternion, out GameObject)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public GameObject Acquire(Vector3 position, Quaternion rotation) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			GameObject instance = this.Acquire();
			Debug.Assert(instance != null);

			instance.Set(position, rotation);

			return instance;
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of the source object, <see cref="SourceObject"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Vector3, Quaternion, Transform, out GameObject)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public GameObject Acquire(Vector3 position, Quaternion rotation, Transform parent) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			GameObject instance = this.Acquire();
			Debug.Assert(instance != null);
			instance.Set(parent, position, rotation);

			return instance;
		}
		#endregion

		#region TryAcquire methods.
		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <see cref="SourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <see cref="SourceObject"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Transform)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire(Transform parent, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			return this.TryAcquire(parent, false, out instance);
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <param name="instance">When this method returns, contains the instance of <see cref="SourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <see cref="SourceObject"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Transform)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire(Transform parent, bool spawnInWorldSpace, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			if (this.TryAcquire(out instance)) {
				Debug.Assert(instance != null);
				instance.Set(parent,spawnInWorldSpace);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of <see cref="SourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <see cref="SourceObject"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Vector3, Quaternion)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire(Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			if (this.TryAcquire(out instance)) {
				Debug.Assert(instance != null);
				instance.Set(position, rotation);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <see cref="SourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <see cref="SourceObject"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Vector3, Quaternion, Transform)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire(Vector3 position, Quaternion rotation, Transform parent, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			if (this.TryAcquire(out instance)) {
				Debug.Assert(instance != null);
				instance.Set(parent, position, rotation);
				return true;
			}

			return false;
		}
		#endregion

		#region InternalTryInstantiate(out T) methods.
		/// <summary>
		/// Instantiates a new object if <see cref="SerialisableObjectPool{T}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Transform parent, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");

			return this.InternalTryInstantiate(parent, false, out instance);
		}

		/// <summary>
		/// Instantiates a new object if <see cref="SerialisableObjectPool{T}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Transform parent, bool spawnInWorldSpace, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.Set(parent, spawnInWorldSpace);
			}
			return result;
		}

		/// <summary>
		/// Instantiates a new object if <see cref="SerialisableObjectPool{T}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.Set(position, rotation);
			}
			return result;
		}

		/// <summary>
		/// Instantiates a new object if <see cref="SerialisableObjectPool{T}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Transform parent, Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.Set(parent, position, rotation);
			}
			return result;
		}
		#endregion

		#region Private methods.
		/// <summary>
		/// Handles the <see cref="PoolableObject{T}.Destroyed"/> event.
		/// </summary>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="e">The event data.</param>
		private void HandlePoolObjectDestroyed(object sender, DestroyedEventArgs e) {
			// This method is called when the PoolableObject component is removed from the object.
			// The whole object may be being destroyed, or just the component may have been destroyed.
			// The object may reside in the pool, or may have been acquired from the pool and not yet been returned.

			var poolable = (PoolableGameObject)sender;
			var instance = poolable.gameObject;

			// If the object is in the pool, remove it and destroy it. It cannot exist in the pool without the PoolableObject component.
			if (this.Remove(instance)) {
				// Ignore if the object is being destroyed because the application is quitting, or the destruction was expected (pooling disabled).
				if (!e.ApplicationQuit && !e.ExpectDestroy) {
					if (this.WarnOnDestroy) {
						DebugHelper.LogError(this.LogMessages,
							$"An instance of the '{this.SourceObject.name}' object was destroyed, or had its {nameof(PoolableGameObject)} component destroyed, while it was still in the pool. " +
							"You should identify the code that destroyed the object or component, and ensure it no longer modifies objects that have been returned to the pool.");
					}
					Object.Destroy(instance);
				}
			} else {
#if POOL_STATISTICS
				if (this.RecordStatistics) {
					// Decrement the number of objects alive outside the pool. This object has been destroyed.
					this.Statistics.ObjectsAliveOutsidePool--;
				}
#endif
#if UNITY_EDITOR
				// Ignore if the object is being destroyed because the application is quitting, or the destruction was expected.
				if (!e.ApplicationQuit && !e.ExpectDestroy) {
					if (this.WarnOnDestroy) {
						// If the object is not in the pool, we'll ignore it for now. When the object is attempted to be returned to the pool, it will be rejected.
						DebugHelper.LogWarning(this.LogMessages,
							$"An instance of the '{this.SourceObject.name}' object was destroyed, or had its {nameof(PoolableGameObject)} component destroyed, while in use (outside of the pool). " +
							"You should refrain from destroying pooled objects, as this negates the purpose of pooling and may cause performance problems. " +
							$"Instead, release them back to the pool using the {nameof(this.Release)} method.");
					}
				}
#endif
			}
		}
#endregion

	}

}