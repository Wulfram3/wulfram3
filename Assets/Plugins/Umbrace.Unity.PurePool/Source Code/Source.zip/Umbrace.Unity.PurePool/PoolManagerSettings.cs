﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A container class for the settings that a <see cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}"/> can have.
	/// </summary>
	/// <typeparam name="TPoolSettings">The type of settings used by individual pools.</typeparam>
	/// <typeparam name="TSource">The type of object being pooled.</typeparam>
	[Serializable]
	public abstract class PoolManagerSettings<TPoolSettings, TSource> where TPoolSettings : SharedPoolSettings<TSource> {

		#region Fields.
		[SerializeField, HideInInspector]
		private bool dontDestroyOnLoad;

		[SerializeField, HideInInspector]
		private bool attachDescendentPools;

		[SerializeField, HideInInspector]
		private bool isPoolingEnabled;

		[SerializeField, HideInInspector]
		private AcquireNoPoolMode acquireMode;

		[SerializeField, HideInInspector]
		private TPoolSettings defaultPoolSettings;
		#endregion

		#region Properties.
		public bool DontDestroyOnLoad {
			get => this.dontDestroyOnLoad;
			set => this.dontDestroyOnLoad = value;
		}

		public bool AttachDescendentPools {
			get => this.attachDescendentPools;
			set => this.attachDescendentPools = value;
		}

		public bool IsPoolingEnabled {
			get => this.isPoolingEnabled;
			set => this.isPoolingEnabled = value;
		}

		public AcquireNoPoolMode AcquireMode {
			get => this.acquireMode;
			set => this.acquireMode = value;
		}

		public TPoolSettings DefaultPoolSettings {
			get => this.defaultPoolSettings;
			set => this.defaultPoolSettings = value;
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Initialises a new instance of the <see cref="PoolManagerSettings{TPoolSettings, TSource}"/> class.
		/// </summary>
		protected PoolManagerSettings() {
			// Do nothing.
		}
		#endregion

	}

}