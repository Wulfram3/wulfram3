﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

using Umbrace.Unity.Contracts;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A serialisable object pool for a <see cref="Component"/>, where the component type is not known at compile time.
	/// </summary>
	/// <remarks>
	/// <para>
	/// By virtue of being serialisable, <see cref="SerialisableComponentPool"/> can survive an assembly reload caused by live recompilation
	/// inside of the Unity editor.
	/// </para>
	/// <para>
	/// <see cref="SerialisableComponentPool"/> achieves this by serialising the instances of the component that were contained in the pool,
	/// and then re-adding them to the pool after deserialisation.
	/// </para>
	/// <para>
	/// To use the <see cref="SerialisableComponentPool"/>, initialise a new instance using the constructor, and then set the properties to appropriate values.
	/// Once all properties have been set, invoke the <see cref="SerialisableObjectPool{T}.Initialise()"/> method. A pool cannot be used without being initialised in this way.
	/// </para>
	/// </remarks>
	/// <example>
	/// <code language="cs">
	/// // Create the pool.
	/// var pool = new SerialisableComponentPool(typeof(AudioSource), parentContainer) {
	/// 	InitialSize = 50,
	/// 	MaximumSize = 200,
	/// 	InstantiateWhenEmpty = true,
	/// 	NotificationMode = NotificationMode.Interface,
	/// 	LogMessages = LogLevel.Warning
	/// };
	/// 
	/// // Initialise the pool. It will contain 50 objects.
	/// pool.Initialise();
	/// 
	/// // Acquire one of the 50 components from the pool. The Acquire method can be used safely if InstantiateWhenEmpty is true, or if a check is made to CanAcquire beforehand.
	/// AudioSource instance = pool.Acquire&lt;AudioSource&gt;();
	/// 
	/// // Acquire one of the 49 remaining components from the pool. TryAcquire can be used safely even when InstantiateWhenEmpty is false.
	/// AudioSource secondInstance;
	/// if (pool.TryAcquire(out secondInstance)) {
	/// 	// Release the component back to the pool. It now contains 49 objects again.
	/// 	pool.Release(secondInstance);
	///	}
	/// 
	/// // Release the component back to the pool. It now contains 50 objects.
	/// pool.Release(instance);
	/// </code>
	/// </example>
	/// <seealso cref="SerialisableGenericComponentPool{T}"/>
	/// <seealso cref="SerialisableObjectPool{T}"/>
	[Serializable]
	public class SerialisableComponentPool : SerialisableGenericComponentPool<Component> {

		// TODO: Replace all GetComponent<PoolableComponent> calls with cache lookups?

		#region Fields.
		[SerializeField, HideInInspector]
		private SerialisableType componentType;
		#endregion

		#region Properties.
		/// <inheritdoc />
		public override Type ComponentType => this.componentType;
		#endregion

		#region Constructor.
		/// <summary>
		/// Initialises a new instance of the <see cref="SerialisableComponentPool"/> class.
		/// </summary>
		/// <param name="componentType">The type of the component to pool.</param>
		/// <param name="parent">The parent transform to which all pooled <see cref="GameObject"/> objects will be parented in the hierarchy.</param>
		/// <param name="additionalComponents">An optional list of additional component types, that should be added to the same GameObject as the main component type.</param>
		public SerialisableComponentPool(Type componentType, Transform parent, params Type[] additionalComponents) : base(parent, additionalComponents) {
			Contract.RequiresNotNull(componentType, nameof(componentType));
			Contract.RequiresMessage(componentType.CanAddAsComponent(), componentTypeName => $"The type '{componentTypeName}' cannot be used as the component type in a {nameof(SerialisableComponentPool)}, as it is not a valid component type.", componentType.Name);

			this.componentType = new SerialisableType(componentType);
		}
		#endregion

		#region Acquire methods.
		/// <summary>
		/// Acquires an instance of the component.
		/// </summary>
		/// <typeparam name="T">The type of component being acquired.</typeparam>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(out T)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public T Acquire<T>() where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			this.CheckType<T>();
			return (T)this.Acquire();
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <typeparam name="T">The type of component being acquired.</typeparam>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Transform, out T)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public T Acquire<T>(Transform parent) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			this.CheckType<T>();
			return (T)this.Acquire(parent);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <typeparam name="T">The type of component being acquired.</typeparam>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the components's transform to.</param>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Vector3, Quaternion, out T)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public T Acquire<T>(Vector3 position, Quaternion rotation) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			this.CheckType<T>();
			return (T)this.Acquire(position, rotation);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <typeparam name="T">The type of component being acquired.</typeparam>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Transform, Vector3, Quaternion, out T)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public T Acquire<T>(Transform parent, Vector3 position, Quaternion rotation) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			this.CheckType<T>();
			return (T)this.Acquire(parent, position, rotation);
		}
		#endregion

		#region TryAcquire methods.
		/// <summary>
		/// Acquires an instance of the component.
		/// </summary>
		/// <typeparam name="T">The type of component being acquired.</typeparam>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}()"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire<T>(out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			this.CheckType<T>();

			Component baseInstance;
			bool result = base.TryAcquire(out baseInstance);

			instance = (T)baseInstance;
			return result;
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <typeparam name="T">The type of component being acquired.</typeparam>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Transform)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire<T>(Transform parent, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			this.CheckType<T>();

			Component baseInstance;
			bool result = base.TryAcquire(parent, out baseInstance);

			instance = (T)baseInstance;
			return result;
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <typeparam name="T">The type of component being acquired.</typeparam>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Vector3, Quaternion)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire<T>(Vector3 position, Quaternion rotation, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			this.CheckType<T>();

			Component baseInstance;
			bool result = base.TryAcquire(position, rotation, out baseInstance);

			instance = (T)baseInstance;
			return result;
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <typeparam name="T">The type of component being acquired.</typeparam>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Transform, Vector3, Quaternion)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire<T>(Transform parent, Vector3 position, Quaternion rotation, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			this.CheckType<T>();

			Component baseInstance;
			bool result = base.TryAcquire(parent, position, rotation, out baseInstance);

			instance = (T)baseInstance;
			return result;
		}
		#endregion

		#region CheckType method.
		/// <summary>
		/// A conditionally-compiled helper method that checks if the type <typeparamref name="T"/> is assignable from <see cref="ComponentType"/>.
		/// </summary>
		/// <typeparam name="T">The type to check.</typeparam>
		/// <param name="memberName">The name of the member that is calling this method.</param>
		[Conditional("UNITY_EDITOR")]
		protected internal void CheckType<T>([CallerMemberName] string memberName = null) {
			if (!typeof(T).IsAssignableFrom(this.ComponentType)) {
				DebugHelper.LogError($"Invalid generic type argument \"{typeof(T).Name}\" used in the generic method \"{memberName}\" of {nameof(SerialisableComponentPool)}. " +
									$"You should only use a type argument that is assignable from the component type, \"{this.ComponentType.Name}\".");
			}
		}
		#endregion

	}

}