﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {
	
	/// <summary>
	/// A container class for the settings that a <see cref="GameObjectPool"/> can have.
	/// </summary>
	[Serializable]
	public class GameObjectPoolSettings : SharedPoolSettings<GameObject>, IGameObjectPoolSettings {

		#region Fields.
		private static readonly GameObjectPoolSettings defaultSettings = new GameObjectPoolSettings(null) {
			InitialSize = 10,
			InitialiseOnStart = true,
			Enabled = true,
			LogMessages = LogLevel.Information,
			NotificationMode = NotificationMode.Interface,
			DontDestroyOnLoad = false,
			InstantiateWhenEmpty = true,
			ReparentPooledObjects = true,
			MaximumSize = 20,
			RecordStatistics = true,
			WarnOnDestroy = true
		};

		[SerializeField, HideInInspector]
		private GameObject sourceObject;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets the default settings.
		/// </summary>
		public static GameObjectPoolSettings DefaultSettings {
			get {
				if (!GameObjectPoolSettings.defaultSettings.Frozen) {
					GameObjectPoolSettings.defaultSettings.Freeze();
				}

				return GameObjectPoolSettings.defaultSettings;
			}
		}

		/// <summary>
		/// Gets or sets the game object that the pool will be used for.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="Source"/>, if the <see cref="GameObjectPoolSettings"/> has been frozen.</exception>
		public override GameObject Source {
			get => this.sourceObject;
			set {
				this.EnsureNotFrozen();
				this.sourceObject = value;
			}
		}
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="GameObjectPoolSettings"/> class.
		/// </summary>
		public GameObjectPoolSettings() : this(GameObjectPoolSettings.DefaultSettings) {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="GameObjectPoolSettings"/> class, using the specified settings.
		/// </summary>
		/// <param name="settings">The settings to copy the values from.</param>
		public GameObjectPoolSettings(GameObjectPoolSettings settings) : base(settings) {
			if (settings != null) {
				this.sourceObject = settings.sourceObject;
			}
		}
		#endregion

	}

}