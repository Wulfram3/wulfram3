﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.ForEditor {

	/// <summary>
	/// Encapsulates changes to a value for use within custom inspector editors. The value is only changed when <see cref="ChangeValue"/> is called.
	/// </summary>
	/// <typeparam name="T">The type of value to store.</typeparam>
	[Serializable]
	internal class EditorChangeValue<T> {

		[SerializeField, HideInInspector] private T currentValue;
		[SerializeField, HideInInspector] private T targetValue;

		/// <summary>
		/// Gets the current value.
		/// </summary>
		public T CurrentValue => this.currentValue;

		/// <summary>
		/// Sets the target value, which will become the current value at the start of the next <see cref="EventType.Layout"/> pass.
		/// </summary>
		public T TargetValue {
			set { this.targetValue = value; }
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="EditorChangeValue{T}"/> class.
		/// </summary>
		public EditorChangeValue() {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="EditorChangeValue{T}"/> class.
		/// </summary>
		/// <param name="value">The current value.</param>
		public EditorChangeValue(T value) {
			this.currentValue = value;
			this.targetValue = value;
		}

		/// <summary>
		/// Changes <see cref="CurrentValue"/> to <see cref="TargetValue"/>.
		/// </summary>
		/// <remarks>
		/// This method should be called at the beginning of the <see cref="EventType.Layout"/> pass.
		/// </remarks>
		public void ChangeValue() {
			this.currentValue = this.targetValue;
		}

		/// <summary>
		/// Forcibly sets the current value immediately, without waiting for <see cref="ChangeValue"/> to be called.
		/// </summary>
		/// <param name="newValue">The new value to use.</param>
		public void ForceSet(T newValue) {
			this.currentValue = newValue;
			this.targetValue = newValue;
		}

	}

	/// <summary>
	/// Encapsulates changes to a boolean value for use within custom inspector editors. The value is only changed when <see cref="EditorChangeValue{T}.ChangeValue"/> is called.
	/// </summary>
	[Serializable]
	internal class BoolEditorChangeValue : EditorChangeValue<bool> {

		/// <summary>
		/// Initialises a new instance of the <see cref="BoolEditorChangeValue"/> class.
		/// </summary>
		public BoolEditorChangeValue() {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="BoolEditorChangeValue"/> class.
		/// </summary>
		/// <param name="value">The current value.</param>
		public BoolEditorChangeValue(bool value) : base(value) {
			// Do nothing.
		}

		/// <summary>
		/// Toggles the value, setting <see cref="EditorChangeValue{T}.TargetValue"/> to the negated <see cref="EditorChangeValue{T}.CurrentValue"/>.
		/// </summary>
		public void Toggle() {
			this.TargetValue = !this.CurrentValue;
		}

		/// <summary>
		/// Implicit conversion from <see cref="BoolEditorChangeValue"/> to <see cref="bool"/>.
		/// </summary>
		/// <param name="x"></param>
		/// <returns></returns>
		public static implicit operator bool(BoolEditorChangeValue x) {
			return x.CurrentValue;
		}

	}

}
