﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;

using Umbrace.Unity.Contracts;

using UnityEngine;

using Debug = System.Diagnostics.Debug;

namespace Umbrace.Unity.PurePool {
	
	/// <summary>
	/// A serialisable, generic implementation of an object pool, that allows for recycling and reuse of objects of type <typeparamref name="T"/>.
	/// </summary>
	/// <typeparam name="T">The type of object being pooled.</typeparam>
	/// <remarks>
	/// <para>
	/// By virtue of being serialisable, <see cref="SerialisableObjectPool{T}"/> can survive an assembly reload caused by live recompilation inside of the Unity editor.
	/// However, to ensure Unity is able to serialise fields containing pools, you should subclass <see cref="SerialisableObjectPool{T}"/>
	/// by creating a new, non-generic, class derived from it.
	/// </para>
	/// <para>
	/// <see cref="SerialisableObjectPool{T}"/> achieves this by serialising the number of instances of the object that were contained in the pool,
	/// and then recreating them after deserialisation. In other cases, it's possible to let Unity serialise the objects contained in the pool, and
	/// simply add them back into the pool after deserialisation.
	/// </para>
	/// <para>
	/// To use the <see cref="SerialisableObjectPool{T}"/>, derive a new, non-generic, class from it and override the <see cref="GetObjectFactory"/> method.
	/// This method is responsible for providing an object factory that can create new instances of the desired object.
	/// Initialise a new instance of the derived class using the constructor, and then set the properties to appropriate values.
	/// Once all properties have been set, invoke the <see cref="Initialise()"/> method. A pool cannot be used without being initialised in this way.
	/// </para>
	/// </remarks>
	/// <seealso cref="IObjectPool{T}"/>
	/// <seealso cref="GenericObjectPool{T}"/>
	[Serializable]
	public abstract class SerialisableObjectPool<T> : ISerializationCallbackReceiver, IObjectPool<T> {

		#region Constants.
		/// <summary>
		/// The default initial size of newly-created pools.
		/// </summary>
		public const int DefaultInitialSize = 0;

		/// <summary>
		/// The default maximum size of newly-created pools.
		/// </summary>
		public const int DefaultMaximumPoolSize = 1000;
		#endregion

		#region Fields.
		private GenericObjectPool<T> objectPool;
		
		[SerializeField, HideInInspector]
		private bool isInitialised;
		[SerializeField, HideInInspector]
		private LogLevel logMessages = LogLevel.Warning;
		[SerializeField, HideInInspector]
		private bool instantiateWhenEmpty = true;
		[SerializeField, HideInInspector]
		private int initialPoolSize = SerialisableObjectPool<T>.DefaultInitialSize;
		[SerializeField, HideInInspector]
		private int maximumPoolSize = SerialisableObjectPool<T>.DefaultMaximumPoolSize;
		[SerializeField, HideInInspector]
		private bool recordStatistics = true;
		
		[SerializeField, HideInInspector]
		private int countWhenSerialised;
		[SerializeField, HideInInspector]
		internal PoolStatistics serialisedStatistics;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets a value indicating whether the pool has been initialised.
		/// </summary>
		/// <remarks>An initialised pool cannot have its <see cref="InitialSize"/> property changed.</remarks>
		/// <seealso cref="Initialise()"/>
		public bool IsInitialised => this.isInitialised;

		/// <summary>
		/// Gets or sets the level of log messaging that the pool will output.
		/// </summary>
		public LogLevel LogMessages {
			get {
				if (this.IsInitialised) return this.objectPool.LogMessages;
				return this.logMessages;
			}
			set {
				this.logMessages = value;
				if (this.IsInitialised) this.objectPool.LogMessages = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to instantiate a new object when the pool is empty, and an attempt is made to acquire from the pool.
		/// </summary>
		public bool InstantiateWhenEmpty {
			get {
				if (this.IsInitialised) return this.objectPool.InstantiateWhenEmpty;
				return this.instantiateWhenEmpty;
			}
			set {
				this.instantiateWhenEmpty = value;
				if (this.IsInitialised) this.objectPool.InstantiateWhenEmpty = value;
			}
		}

		/// <summary>
		/// Gets or sets the initial size of the pool. Cannot be set once the pool has been initialised.
		/// </summary>
		/// <remarks>
		/// <para>This property cannot be set once the pool has been initialised.</para>
		/// <para>The initial size must be greater than, or equal to, zero. It cannot be a negative number.</para>
		/// </remarks>
		/// <seealso cref="Count"/>
		/// <seealso cref="MaximumSize"/>
		public int InitialSize {
			get => this.initialPoolSize;
			set {
				Contract.RequiresMessage(value >= 0, () => $"The {nameof(this.InitialSize)} property cannot be set to a negative number.");
				Contract.RequiresMessage(!this.IsInitialised, () => $"The {nameof(this.InitialSize)} property cannot be set once the pool has been initialised.");

				if (this.InitialSize == value) return;
				this.initialPoolSize = value;
			}
		}

		/// <summary>
		/// Gets or sets the maximum size of the pool, which is the maximum number of objects it can contain.
		/// </summary>
		/// <remarks>
		/// <para>The maximum size must be greater than, or equal to, zero. It cannot be a negative number.</para>
		/// <para>If an object is released to the pool while the pool is full, the object will be destroyed.</para>
		/// <para>
		/// If <see cref="MaximumSize"/> is set to a value lower than the current <see cref="Count"/>, the pool will be
		/// reduced in size by destroying excess objects.
		/// </para>
		/// </remarks>
		/// <seealso cref="Count"/>
		/// <seealso cref="InitialSize"/>
		public int MaximumSize {
			get {
				if (this.IsInitialised) return this.objectPool.MaximumSize;
				return this.maximumPoolSize;
			}
			set {
				Contract.RequiresMessage(value >= 0, () => $"The {nameof(this.MaximumSize)} property cannot be set to a negative number.");

				this.maximumPoolSize = value;
				if (this.IsInitialised) this.objectPool.MaximumSize = value;
			}
		}

		/// <summary>
		/// Gets the number of objects currently contained by the pool.
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		/// <seealso cref="IsInitialised"/>
		/// <seealso cref="IsFull"/>
		/// <seealso cref="IsEmpty"/>
		/// <seealso cref="InitialSize"/>
		/// <seealso cref="MaximumSize"/>
		/// <seealso cref="CountChanged"/>
		public int Count {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Count)} property cannot be accessed until the pool has been initialised.");
				return this.objectPool.Count;
			}
		}

		/// <summary>
		/// Gets a list of items currently contained by the pool.
		/// </summary>
		/// <remarks>
		/// <para>This property cannot be accessed until the pool has been initialised.</para>
		/// <para>
		/// This property always creates a new <see cref="List{T}"/> each time the property getter is accessed.
		/// For performance reasons the value should be cached where possible, to avoid the costs of object instantiation and garbage collection.
		/// </para>
		/// <para>See the <see cref="GetItems"/> method for a way to avoid the allocation of a new <see cref="List{T}"/> object.</para>
		/// </remarks>
		/// <seealso cref="GetItems"/>
		public IList<T> Items {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Items)} property cannot be accessed until the pool has been initialised.");
				return this.objectPool.Items;
			}
		}

		/// <summary>
		/// Gets an object containing general operational statistics about the pool.
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		public PoolStatistics Statistics {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Statistics)} property cannot be accessed until the pool has been initialised.");
				return this.objectPool.Statistics;
			}
		}

		/// <summary>
		/// Gets a value indicating whether the pool is empty and contains no objects.
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		/// <seealso cref="Count"/>
		/// <seealso cref="IsFull"/>
		public bool IsEmpty {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.IsEmpty)} property cannot be accessed until the pool has been initialised.");
				return this.objectPool.IsEmpty;
			}
		}

		/// <summary>
		/// Gets a value indicating whether the pool is full, and cannot contain any more objects.
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		/// <seealso cref="Count"/>
		/// <seealso cref="IsEmpty"/>
		public bool IsFull {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.IsFull)} property cannot be accessed until the pool has been initialised.");
				return this.objectPool.IsFull;
			}
		}

		/// <summary>
		/// <para>Gets a value indicating whether an instance can be acquired from the pool.</para>
		/// <para>An instance can be acquired when the pool contains at least one instance, or when <see cref="InstantiateWhenEmpty"/> is <see langword="true"/>.</para>
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		/// <seealso cref="IsEmpty"/>
		/// <seealso cref="InstantiateWhenEmpty"/>
		/// <seealso cref="CanAcquireChanged"/>
		public bool CanAcquire {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.CanAcquire)} property cannot be accessed until the pool has been initialised.");
				return this.objectPool.CanAcquire;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to record pool statistics.
		/// </summary>
		/// <seealso cref="Statistics"/>
		public bool RecordStatistics {
			get {
				if (this.IsInitialised) return this.objectPool.RecordStatistics;
				return this.recordStatistics;
			}
			set {
				this.recordStatistics = value;
				if (this.IsInitialised) this.objectPool.RecordStatistics = value;
			}
		}

		/// <summary>
		/// Gets a value indiciating whether to refill the pool with new objects after the pool is reinitialised,
		/// as happens from deserialisation.
		/// </summary>
		protected virtual bool RefillPoolOnReinitialise => true;
		#endregion

		#region Events.
		/// <summary>
		/// Occurs when the pool is initialised.
		/// </summary>
		public event EventHandler Initialised;

		/// <summary>
		/// Occurs when a new object is instantiated.
		/// </summary>
		/// <remarks>
		/// This event can occur before the pool is fully initialised. This happens when <see cref="Initialise()"/> is first called,
		/// and <see cref="InitialSize"/> is greater than zero. Care should be taken to avoid using any methods or properties on the pool
		/// that require the pool to be initialised, unless suitable checks are made to <see cref="IsInitialised"/>.
		/// </remarks>
		public event EventHandler<PoolObjectEventArgs<T>> ObjectInstantiated;

		/// <summary>
		/// Occurs when an object is acquired from the pool.
		/// </summary>
		/// <remarks>
		/// This event will also be invoked for objects that are instantiated when the pool is empty, in addition to <see cref="ObjectInstantiated"/>.
		/// In this situation, the <see cref="PoolObjectAcquiredEventArgs{T}.Instantiated"/> property is set to <see langword="true"/> to indicate that the acquired object was instantiated.
		/// </remarks>
		public event EventHandler<PoolObjectAcquiredEventArgs<T>> ObjectAcquired;

		/// <summary>
		/// Occurs when an object is released back to the pool.
		/// </summary>
		/// <remarks>
		/// This event will also be invoked for objects that are released to a pool that has reached its maximum size.
		/// In this situation, the <see cref="PoolObjectReleasedEventArgs{T}.Destroying"/> property is set to <see langword="true"/> to indicate that the released object is about to be destroyed.
		/// </remarks>
		public event EventHandler<PoolObjectReleasedEventArgs<T>> ObjectReleased;

		/// <summary>
		/// Occurs when an object is destroyed.
		/// </summary>
		public event EventHandler<PoolObjectEventArgs<T>> ObjectDestroyed;

		/// <summary>
		/// Occurs when the value of <see cref="CanAcquire"/> changes.
		/// </summary>
		/// <seealso cref="CanAcquire"/>
		public event EventHandler<PoolCanAcquireChangedEventArgs> CanAcquireChanged;

		/// <summary>
		/// Occurs when <see cref="Count"/> changes.
		/// </summary>
		/// <seealso cref="Count"/>
		public event EventHandler<PoolCountChangedEventArgs> CountChanged;
		#endregion

		#region Constructor.
		/// <summary>
		/// Initialises a new instance of the <see cref="SerialisableObjectPool{T}"/> class.
		/// </summary>
		/// <remarks>An instance of <see cref="SerialisableObjectPool{T}"/> must be initialised using the <see cref="Initialise()"/> method.</remarks>
		protected SerialisableObjectPool() {
			// Do nothing. The object is initialised after construction using the Initialise method.
		}
		#endregion

		#region Initialise methods.
		/// <summary>
		/// Initialises the pool, populating it with objects and making it ready for use.
		/// </summary>
		public void Initialise() {
			Contract.RequiresMessage(!this.IsInitialised, "Unable to initialise the pool as it's already been initialised. A pool can only be initialised once.");
			
			this.Initialise(reinitialise: false);

			#if POOL_STATISTICS
			if (this.objectPool.RecordStatistics) {
				this.Statistics.InitialisedTime = new TimeInstant(Time.frameCount, Time.realtimeSinceStartup, Time.time, Time.unscaledTime);
			}
			#endif

			Debug.Assert(this.IsInitialised);
		}

		/// <summary>
		/// Initialises the pool, making it ready for use, and optionally populating it with objects.
		/// </summary>
		/// <param name="reinitialise">A value indicating whether the pool is being reinitialised after deserialisation.</param>
		/// <exception cref="InvalidOperationException">No public parameterless constructor could be found on type <typeparamref name="T"/>, or, <see cref="GetObjectFactory"/> threw an exception.</exception>
		protected void Initialise(bool reinitialise) {
			//Contract.Requires(!this.IsInitialised);
			
			Func<T> objectFactory;

			try {
				objectFactory = this.GetObjectFactory();
			} catch (Exception ex) {
				throw new InvalidOperationException($"{nameof(this.GetObjectFactory)} threw an exception. Ensure the type you are trying to pool ({typeof(T).FullName}) has a public parameterless constructor, or override {nameof(this.GetObjectFactory)} to implement your own factory method for object creation.", ex);
			}

			if (objectFactory == null) {
				throw new InvalidOperationException($"{nameof(this.GetObjectFactory)} returned null. Ensure the type you are trying to pool ({typeof(T).FullName}) has a public parameterless constructor, or override {nameof(this.GetObjectFactory)} to implement your own factory method for object creation.");
			}

			// Create the internal object pool and set the properties.
			this.objectPool = new GenericObjectPool<T>(objectFactory) {
				LogMessages = this.logMessages,
				InstantiateWhenEmpty = this.instantiateWhenEmpty,
				MaximumSize = this.maximumPoolSize,
				RecordStatistics = this.recordStatistics
			};
			this.serialisedStatistics = this.objectPool.Statistics;

			// Hook up to the internal pool's events.
			this.objectPool.ObjectInstantiated += (sender, args) => this.OnObjectInstantiated(args.Instance);
			this.objectPool.ObjectDestroyed += (sender, args) => this.OnObjectDestroyed(args.Instance);
			this.objectPool.ObjectAcquired += (sender, args) => this.OnObjectAcquired(args.Instance, args.Instantiated);
			this.objectPool.ObjectReleased += (sender, args) => this.OnObjectReleased(args.Instance, args.Destroying);
			this.objectPool.CanAcquireChanged += (sender, args) => this.OnCanAcquireChanged(args.CanAcquire);
			this.objectPool.CountChanged += (sender, args) => this.OnCountChanged(args.Count);

			// Populate the pool with the initial number of objects, but only if we're not reinitialising after deserialisation.
			if (!reinitialise) {
				this.objectPool.SetSize(this.initialPoolSize);
			}

			this.isInitialised = true;

			if (!reinitialise) {
				// Raise the Initialised event.
				this.OnInitialised();
			}

			Debug.Assert(this.IsInitialised);
		}
		#endregion

		#region Acquire method.
		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <returns>An object from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire"/>
		/// <seealso cref="Release"/>
		public T Acquire() {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			//Contract.Ensures(Contract.Result<T>() != null);

			T instance = this.objectPool.Acquire();
			Debug.Assert(instance != null);
			return instance;
		}
		#endregion

		#region TryAcquire(out T) method.
		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <param name="instance">When this method returns, contains the object from the pool, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire"/>
		/// <seealso cref="Release"/>
		public bool TryAcquire(out T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			//Contract.Ensures(!Contract.Result<bool>() || Contract.ValueAtReturn(out instance) != null);

			bool result = this.objectPool.TryAcquire(out instance);
			Debug.Assert(!result || instance != null);
			return result;
		}
		#endregion

		#region Release(T) method.
		/// <summary>
		/// Releases an object back to the pool.
		/// </summary>
		/// <param name="instance">The object to release to the pool.</param>
		public void Release(T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Release)} method cannot be called until the pool has been initialised.");
			Contract.RequiresNotNull(instance, nameof(instance));

			// Use a separate virtual method, to ensure the contract preconditions are always present even when overridden.
			this.ReleaseInternal(instance);
		}

		/// <summary>
		/// Releases an object back to the pool.
		/// </summary>
		/// <param name="instance">The object to release to the pool.</param>
		protected virtual void ReleaseInternal(T instance) {
			this.objectPool.Release(instance);
		}
		#endregion

		#region SetSize(int), Fill, Clear, Remove(T), Contains(T) methods.
		/// <summary>
		/// Sets the number of objects contained by the pool, either destroying excess pooled objects, or instantiating new ones.
		/// </summary>
		/// <param name="poolSize">The target number of objects the pool should contain.</param>
		/// <remarks>
		/// <paramref name="poolSize"/> cannot be a negative number, and cannot be larger than <see cref="MaximumSize"/>.
		/// </remarks>
		/// <seealso cref="Fill"/>
		/// <seealso cref="Clear"/>
		public void SetSize(int poolSize) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.SetSize)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(poolSize >= 0, () => $"{nameof(poolSize)} cannot be a negative number.");
			Contract.RequiresMessage(poolSize <= this.MaximumSize, () => $"{nameof(poolSize)} cannot be larger than {nameof(this.MaximumSize)}.");

			this.objectPool.SetSize(poolSize);
		}

		/// <summary>
		/// Fills the pool, populating it with pooled objects until it reaches the maximum pool size.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Clear"/>
		/// <seealso cref="MaximumSize"/>
		public void Fill() {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Fill)} method cannot be called until the pool has been initialised.");
			//Contract.Ensures(this.Count == this.MaximumSize);

			this.objectPool.Fill();
		}

		/// <summary>
		/// Clears the pool, emptying it of all pooled objects.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Fill"/>
		public void Clear() {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Clear)} method cannot be called until the pool has been initialised.");
			//Contract.Ensures(this.Count == 0);

			this.objectPool.Clear();
		}

		/// <summary>
		/// Removes the specified instance from the pool.
		/// </summary>
		/// <param name="instance">The instance of the source object that should be removed from the pool.</param>
		/// <returns><see langword="true"/> if the instance was found in the pool and removed; otherwise, <see langword="false"/>.</returns>
		public bool Remove(T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Remove)} method cannot be called until the pool has been initialised.");
			Contract.RequiresNotNull(instance, nameof(instance));

			return this.objectPool.Remove(instance);
		}

		/// <summary>
		/// Determines whether an instance is in the pool.
		/// </summary>
		/// <param name="instance">The instance of the source object to locate in the pool.</param>
		/// <returns><see langword="true"/> if <paramref name="instance"/> is found in the pool; otherwise, <see langword="false"/>.</returns>
		public bool Contains(T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Contains)} method cannot be called until the pool has been initialised.");
			Contract.RequiresNotNull(instance, nameof(instance));

			return this.objectPool.Contains(instance);
		}
		#endregion

		#region GetItems method.
		/// <summary>
		/// Gets a list of items currently contained by the pool, and stores them in the specified <see cref="List{T}"/>.
		/// </summary>
		/// <param name="list">The existing list in which the items should be stored.</param>
		/// <seealso cref="Items"/>
		public void GetItems(List<T> list) {
			Contract.RequiresNotNull(list, nameof(list));

			this.objectPool.GetItems(list);
		}
		#endregion

		#region InternalAdd(T) method.
		/// <summary>
		/// Adds an instance directly to the pool. This method is used internally and should be used with caution.
		/// </summary>
		/// <param name="instance">The instance to add to the pool.</param>
		/// <remarks>
		/// <para>If the maximum size of the pool would be exceeded by adding the instance, the instance is destroyed.</para>
		/// <para>
		/// This method does not inform the instance that it is being returned to the pool, and does not raise
		/// any events. It should only be used to add instances to the pool that were previously already in the pool,
		/// such as those serialised during live recompilation.
		/// </para>
		/// </remarks>
		internal void InternalAdd(T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalAdd)} method cannot be called until the pool has been initialised.");
			Contract.RequiresNotNull(instance, nameof(instance));

			this.objectPool.InternalAdd(instance);
		}
		#endregion

		#region InternalTryInstantiate(out T) method.
		/// <summary>
		/// Instantiates a new object if <see cref="InstantiateWhenEmpty"/> is <see langword="true"/>.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(out T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			//Contract.Ensures(!Contract.Result<bool>() || Contract.ValueAtReturn(out instance) != null);

			bool result = this.objectPool.InternalTryInstantiate(out instance);
			Debug.Assert(!result || instance != null);
			return result;
		}
		#endregion

		#region ISerializationCallbackReceiver implementation.
		void ISerializationCallbackReceiver.OnAfterDeserialize() {
			this.OnAfterDeserialize();
		}

		void ISerializationCallbackReceiver.OnBeforeSerialize() {
			this.OnBeforeSerialize();
		}

		/// <summary>
		/// Performs actions after the object has been deserialised.
		/// </summary>
		protected virtual void OnAfterDeserialize() {
			if (this.IsInitialised) {
				PoolStatistics previousStatistics = this.serialisedStatistics;

				// Initialise the pool but don't populate it with the initial number of objects.
				this.Initialise(reinitialise: true);

				// Check if we should refill the pool. Subclasses might not require this behaviour.
				if (this.RefillPoolOnReinitialise) {
					// Re-fill the pool to the same size as before it was serialised.
					this.objectPool.SetSize(this.countWhenSerialised);
				}

				// Restore the pool statistic values.
				this.Statistics.CopyFrom(previousStatistics);
			}
		}

		/// <summary>
		/// Performs actions prior to the object being serialised.
		/// </summary>
		protected virtual void OnBeforeSerialize() {
			if (this.IsInitialised) {
				// Ensure we serialise the number of objects in the pool, so we can repopulate it to the correct size.
				this.countWhenSerialised = this.Count;

				// This method is called other times than for hot reload of assemblies.
				// As we can't guarantee it's going to be deserialised, we don't clear the pool here.
			}
		}
		#endregion

		#region GetObjectFactory method.
		/// <summary>
		/// Gets a function used to create new instances of the pooled type.
		/// By default, this method uses the public parameterless constructor of type <typeparamref name="T"/>.
		/// This method should be overridden in a subclass if different behaviour is required.
		/// </summary>
		/// <returns>A function that can be used to create new instances of the pooled type.</returns>
		/// <exception cref="InvalidOperationException">No public parameterless constructor could be found on type <typeparamref name="T"/>.</exception>
		protected virtual Func<T> GetObjectFactory() {
			// Use the public parameterless constructor for type T as the object factory method.
			ConstructorInfo defaultConstructor = typeof(T).GetConstructor(Type.EmptyTypes);
			if (defaultConstructor == null) throw new InvalidOperationException($"No public parameterless constructor could be found on the pooled type ({typeof(T).FullName}). Override the {nameof(this.GetObjectFactory)} method in a subclass to return a suitable object factory.");
			return Expression.Lambda<Func<T>>(Expression.New(defaultConstructor)).Compile();
		}
		#endregion

		#region Event raisers.
		/// <summary>
		/// Raises the <see cref="Initialised"/> event.
		/// </summary>
		protected virtual void OnInitialised() {
			this.Initialised?.Invoke(this, EventArgs.Empty);
		}
		
		/// <summary>
		/// Raises the <see cref="ObjectInstantiated"/> event.
		/// </summary>
		/// <param name="instance">The object that was instantiated.</param>
		protected virtual void OnObjectInstantiated(T instance) {
			this.ObjectInstantiated.InvokeEventPooled(this, instance);
		}

		/// <summary>
		/// Raises the <see cref="ObjectAcquired"/> event.
		/// </summary>
		/// <param name="instance">The object that was acquired from the pool.</param>
		/// <param name="instantiated">A value indicating whether the acquired object was instantiated specifically for this acquisition, rather than being taken from the pool.</param>
		protected virtual void OnObjectAcquired(T instance, bool instantiated) {
			this.ObjectAcquired.InvokeEventPooled(this, instance, instantiated);
		}

		/// <summary>
		/// Raises the <see cref="ObjectReleased"/> event.
		/// </summary>
		/// <param name="instance">The object that was released back to the pool.</param>
		/// <param name="destroying">A value indicating whether the released object is about to be destroyed.</param>
		protected virtual void OnObjectReleased(T instance, bool destroying) {
			this.ObjectReleased.InvokeEventPooled(this, instance, destroying);
		}

		/// <summary>
		/// Raises the <see cref="ObjectDestroyed"/> event.
		/// </summary>
		/// <param name="instance">The object that was destroyed.</param>
		protected virtual void OnObjectDestroyed(T instance) {
			this.ObjectDestroyed.InvokeEventPooled(this, instance);
		}

		/// <summary>
		/// Raises the <see cref="CanAcquireChanged"/> event.
		/// </summary>
		/// <param name="canAcquire">The new value of <see cref="CanAcquire"/>.</param>
		protected virtual void OnCanAcquireChanged(bool canAcquire) {
			this.CanAcquireChanged.InvokeEventPooled(this, canAcquire);
		}

		/// <summary>
		/// Raises the <see cref="CountChanged"/> event.
		/// </summary>
		/// <param name="count">The new value of <see cref="Count"/>.</param>
		protected virtual void OnCountChanged(int count) {
			this.CountChanged.InvokeEventPooled(this, count);
		}
		#endregion

	}

}