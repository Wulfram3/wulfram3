﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEngine;
using UnityEngine.SceneManagement;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// An abstract class that provides shared functionality to manage a collection of <see cref="PoolBase{TSource,TInstance,TSettings}"/> components, simplifying access to the pools and allowing for automatic pool creation.
	/// </summary>
	/// <typeparam name="TManagerSettings">The type of the manager's settings.</typeparam>
	/// <typeparam name="TPool">The type of the pools maintained by the manager.</typeparam>
	/// <typeparam name="TPoolSettings">The type of the settings used by the pools.</typeparam>
	/// <typeparam name="TSource">The type used to identify the desired source when acquiring an instance.</typeparam>
	/// <typeparam name="TInstance">The type of the instances returned from the pools.</typeparam>
	public abstract class PoolManagerBase<TManagerSettings, TPool, TPoolSettings, TSource, TInstance> : MonoBehaviour, ISerializationCallbackReceiver
		where TManagerSettings : PoolManagerSettings<TPoolSettings, TSource>
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TPool : PoolBase<TSource, TInstance, TPoolSettings> {

		// TODO: Have a list of pools that will be attached on Start? They could exist anywhere in the scene, not just under the manager.
		
		#region Properties.
		/// <summary>
		/// When overridden in a derived class, gets the internal object pool dictionary, mapping from the source object to its pool.
		/// </summary>
		protected abstract IDictionary<TSource, TPool> ObjectPools { get; }

		/// <summary>
		/// When overridden in a derived class, gets or sets the current settings used by the manager.
		/// </summary>
		internal abstract TManagerSettings Settings { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether pooling is enabled.
		/// </summary>
		/// <remarks>
		/// When <see cref="Enabled"/> is set to <see langword="false"/>, all pools accessed through the <see cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}"/> will appear empty,
		/// and acquiring from them will only work if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>.
		/// </remarks>
		public bool Enabled {
			get => this.Settings.IsPoolingEnabled;
			set => this.Settings.IsPoolingEnabled = value;
		}

		/// <summary>
		/// Gets or sets a value indicating whether the pool manager (and the pools beneath it) will remain in the scene when a new scene is loaded.
		/// </summary>
		/// <remarks>
		/// <para>
		/// Upon setting the <see cref="DontDestroyOnLoad"/> property to <see langword="true"/>, the manager will be prevented from
		/// being destroyed when loading a new scene. In addition, all pools that are parented beneath the manager in the hierarchy will
		/// also be prevented from being destroyed.
		/// </para>
		/// <para>
		/// It's important to make the distinction that it's actually the root transform of the <see cref="GameObject"/> to which the manager is attached that
		/// will persist between scene changes. The root transform is the top-most transform in the hierarchy.
		/// Therefore, every object that is parented beneath the root transform in the hierarchy will persist between scene changes, and not only the manager.
		/// </para>
		/// <para>
		/// If the <see cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}"/> component is removed from its game object, the game object will still persist through scene changes.
		/// </para>
		/// <para>
		/// Pools that are attached to the manager using <see cref="AttachPool"/>, but that are not parented beneath the manager in the hierarchy,
		/// are not affected by this property.
		/// </para>
		/// </remarks>
		public new bool DontDestroyOnLoad {
			get => this.Settings.DontDestroyOnLoad;
			set {
				this.Settings.DontDestroyOnLoad = value;

				if (value && Application.isPlaying) { // The DontDestroyOnLoad method can only be called in play mode.
					// Only top-level game objects can be marked, so mark the root.
					Object.DontDestroyOnLoad(this.transform.root.gameObject);
				}
			}
		}

		/// <summary>
		/// Gets or sets value indicating whether to attach all descendent pools to the manager on startup.
		/// </summary>
		public bool AttachDescendentPools {
			get => this.Settings.AttachDescendentPools;
			set => this.Settings.AttachDescendentPools = value;
		}

		/// <summary>
		/// Gets or sets the way in which to handle attempts to acquire an object, for which no pool exists.
		/// </summary>
		public AcquireNoPoolMode AcquireMode {
			get => this.Settings.AcquireMode;
			set => this.Settings.AcquireMode = value;
		}

		/// <summary>
		/// Gets the number of pools attached to the manager.
		/// </summary>
		public int PoolCount => this.ObjectPools.Count;

		/// <summary>
		/// Gets the collection of pools attached to the manager.
		/// </summary>
		public IEnumerable<TPool> Pools => this.ObjectPools.Values.Skip(0);

		/// <summary>
		/// Gets the settings that are used when a new pool is created.
		/// </summary>
		public TPoolSettings DefaultPoolSettings => this.Settings.DefaultPoolSettings;
		#endregion

		#region Events.
		/// <summary>
		/// Occurs when a <see cref="GameObjectPool"/> is attached to the manager.
		/// </summary>
		public event EventHandler<PoolEventArgs<TPool>> PoolAttached;

		/// <summary>
		/// Occurs when a <see cref="GameObjectPool"/> is detached from the manager.
		/// </summary>
		public event EventHandler<PoolEventArgs<TPool>> PoolDetached;

		/// <summary>
		/// Occurs when a <see cref="GameObjectPool"/> is created by the manager.
		/// </summary>
		public event EventHandler<PoolEventArgs<TPool>> PoolCreated;

		/// <summary>
		/// Occurs when a <see cref="GameObjectPool"/> is destroyed by the manager.
		/// </summary>
		public event EventHandler<PoolEventArgs<TPool>> PoolDestroyed;
		#endregion

		#region Initialisation and shutdown methods.
		protected virtual void Awake() {
			// Set up if the pool manager (and its pools) should remain in the scene after a new scene is loaded.
			// The object that this component is on, as well as all children below it, will remain.
			if (this.DontDestroyOnLoad) {
				Object.DontDestroyOnLoad(this.transform.root.gameObject);
			}

			// Listen for a new scene being loaded. This is used to destroy the manager if DontDestroyOnLoad is changed back from true to false, since that action can't be undone.
			SceneManager.sceneLoaded += this.SceneManagerOnSceneLoaded;

			// Attach any pools that are parented beneath the manager in the hierarchy.
			if (this.AttachDescendentPools) {
				this.AttachChildren();
			}
		}

		private void SceneManagerOnSceneLoaded(Scene scene, LoadSceneMode mode) {
			// If the manager shouldn't be kept through scene changes, ensure it gets destroyed.
			// This is necessary as it's only possible to mark an object as persisting through scene changes - there's no way to undo it once it's been marked.
			if (!this.DontDestroyOnLoad && mode == LoadSceneMode.Single) {
				Object.Destroy(this);
			}
		}

		private void PoolOnInitialised(object sender, EventArgs eventArgs) {
			var pool = (TPool)sender;

			// Ignore if the pool is not a descendant of the manager anymore.
			if (!pool.transform.IsChildOf(this.transform)) return;

			// Ignore if the manager already has a pool handling this object.
			if (this.HasPool(pool.Source)) return;

			// Ignore if the pool is already attached.
			if (this.IsAttached(pool)) return;

			this.AttachPool(pool);
		}
		#endregion

		#region Acquire(TSource) methods.
		/// <summary>
		/// Acquires an instance of <paramref name="source"/> from an attached pool.
		/// </summary>
		/// <param name="source">The source to acquire an instance of.</param>
		/// <returns>An instance of <paramref name="source"/> acquired from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire(TSource, out TInstance)"/>
		/// <seealso cref="Release"/>
		public TInstance Acquire(TSource source) {
			Contract.RequiresNotNull(source, nameof(source));
			Contract.Requires(this.CanAcquire(source));
			
			// Get the pool that contains instances of the source.
			TPool pool;
			TInstance instance;
			if (this.InternalGetPoolOrAcquire(source, out pool, out instance)) {
				// Get an instance of the source from the pool.
				instance = pool.Acquire();
			}
			
			return instance;
		}

		///// <summary>
		///// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform.
		///// </summary>
		///// <param name="sourceObject">The game object to acquire an instance of.</param>
		///// <param name="parent">The transform to which the instance should be parented.</param>
		///// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		///// <seealso cref="CanAcquire"/>
		///// <seealso cref="TryAcquire(GameObject, Transform, out GameObject)"/>
		///// <seealso cref="Release"/>
		//public GameObject Acquire(GameObject sourceObject, Transform parent) {
		//	Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
		//	Contract.Requires(this.CanAcquire(sourceObject));

		//	// Acquire and set the parent.
		//	return this.Acquire(sourceObject).Set(parent);
		//}
		
		///// <summary>
		///// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its position and rotation.
		///// </summary>
		///// <param name="sourceObject">The game object to acquire an instance of.</param>
		///// <param name="position">The position to set the instance's transform to.</param>
		///// <param name="rotation">The rotation to set the instance's transform to.</param>
		///// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		///// <seealso cref="CanAcquire"/>
		///// <seealso cref="TryAcquire(GameObject, Vector3, Quaternion, out GameObject)"/>
		///// <seealso cref="Release"/>
		//public GameObject Acquire(GameObject sourceObject, Vector3 position, Quaternion rotation) {
		//	Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
		//	Contract.Requires(this.CanAcquire(sourceObject));

		//	// Acquire and set the position and rotation.
		//	return this.Acquire(sourceObject).Set(position, rotation);
		//}

		///// <summary>
		///// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform, position and rotation.
		///// </summary>
		///// <param name="sourceObject">The game object to acquire an instance of.</param>
		///// <param name="parent">The transform to which the instance should be parented.</param>
		///// <param name="position">The position to set the instance's transform to.</param>
		///// <param name="rotation">The rotation to set the instance's transform to.</param>
		///// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		///// <seealso cref="CanAcquire"/>
		///// <seealso cref="TryAcquire(GameObject, Transform, Vector3, Quaternion, out GameObject)"/>
		///// <seealso cref="Release"/>
		//public GameObject Acquire(GameObject sourceObject, Transform parent, Vector3 position, Quaternion rotation) {
		//	Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
		//	Contract.Requires(this.CanAcquire(sourceObject));

		//	// Acquire and set the parent, position and rotation.
		//	return this.Acquire(sourceObject).Set(parent, position, rotation);
		//}
		#endregion
		
		#region TryAcquire(out TInstance) methods.
		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		public bool TryAcquire(TSource sourceObject, out TInstance instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			// Get the pool that contains instances of the object.
			TPool pool;
			if (!this.InternalGetPoolOrAcquire(sourceObject, out pool, out instance)) {
				// No pool exists, but an instance of the object was obtained.
				return true;
			}

			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return pool.InternalTryInstantiate(out instance);

			// Get an instance of the object from the pool.
			return pool.TryAcquire(out instance);
		}

		///// <summary>
		///// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform.
		///// </summary>
		///// <param name="sourceObject">The game object to acquire an instance of.</param>
		///// <param name="parent">The transform to which the instance should be parented.</param>
		///// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		///// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		///// <seealso cref="Acquire(GameObject, Transform)"/>
		///// <seealso cref="Release"/>
		//public bool TryAcquire(GameObject sourceObject, Transform parent, out GameObject instance) {
		//	Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

		//	if (this.TryAcquire(sourceObject, out instance)) {
		//		instance.Set(parent);
		//		return true;
		//	}

		//	return false;
		//}

		///// <summary>
		///// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its position and rotation.
		///// </summary>
		///// <param name="sourceObject">The game object to acquire an instance of.</param>
		///// <param name="position">The position to set the instance's transform to.</param>
		///// <param name="rotation">The rotation to set the instance's transform to.</param>
		///// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		///// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		///// <seealso cref="Acquire(GameObject, Vector3, Quaternion)"/>
		///// <seealso cref="Release"/>
		//public bool TryAcquire(GameObject sourceObject, Vector3 position, Quaternion rotation, out GameObject instance) {
		//	Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

		//	if (this.TryAcquire(sourceObject, out instance)) {
		//		instance.Set(position, rotation);
		//		return true;
		//	}

		//	return false;
		//}

		///// <summary>
		///// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform, position and rotation.
		///// </summary>
		///// <param name="sourceObject">The game object to acquire an instance of.</param>
		///// <param name="parent">The transform to which the instance should be parented.</param>
		///// <param name="position">The position to set the instance's transform to.</param>
		///// <param name="rotation">The rotation to set the instance's transform to.</param>
		///// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		///// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		///// <seealso cref="Acquire(GameObject, Transform, Vector3, Quaternion)"/>
		///// <seealso cref="Release"/>
		//public bool TryAcquire(GameObject sourceObject, Transform parent, Vector3 position, Quaternion rotation, out GameObject instance) {
		//	Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

		//	if (this.TryAcquire(sourceObject, out instance)) {
		//		instance.Set(parent, position, rotation);
		//		return true;
		//	}

		//	return false;
		//}
		#endregion
		
		#region Release methods.
		/// <summary>
		/// Releases an instance that was previously acquired from an attached pool.
		/// </summary>
		/// <param name="instance">The instance to release back to the pool.</param>
		public void Release(TInstance instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			this.ReleaseInternal(instance);
		}

		/// <summary>
		/// Releases an instance that was previously acquired from an attached pool, after a specified time delay.
		/// </summary>
		/// <param name="instance">The instance to release to the pool.</param>
		/// <param name="delay">The period of time to wait before releasing the instance to the pool.</param>
		/// <remarks>
		/// The delay is measured in scaled time, and is therefore affected by <see cref="Time.timeScale"/>.
		/// </remarks>
		public void Release(TInstance instance, float delay) {
			Contract.RequiresNotNull(instance, nameof(instance));

			this.StartCoroutine(this.ReleaseLater(instance, delay));
		}

		/// <summary>
		/// When overridden in a derived class, releases an instance that was previously acquired from an attached pool.
		/// </summary>
		/// <param name="instance">The instance to release back to the pool.</param>
		protected abstract void ReleaseInternal(TInstance instance);
		#endregion

		#region HasPool(TSource), GetPool(TSource), TryGetPool(TSource, out TPool) methods.
		/// <summary>
		/// Determines whether the manager has a pool that handles instances of the specified source object.
		/// </summary>
		/// <param name="sourceObject">The source object to check.</param>
		/// <returns><see langword="true"/> if the manager has a pool that handles instances of <paramref name="sourceObject"/>; otherwise, <see langword="false"/>.</returns>
		public bool HasPool(TSource sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			return this.ObjectPools.ContainsKey(sourceObject);
		}

		/// <summary>
		/// Gets the pool that handles instances of the specified source object.
		/// The manager must contain a matching pool to use this method.
		/// </summary>
		/// <param name="sourceObject">The source object to retrieve the pool for.</param>
		/// <returns>A <typeparamref name="TPool"/> that handles instances of <paramref name="sourceObject"/>.</returns>
		public TPool GetPool(TSource sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.RequiresMessage(this.HasPool(sourceObject), "There are no pools that handle the specified source object attached to the manager.");

			return this.ObjectPools[sourceObject];
		}

		/// <summary>
		/// Gets the pool that handles instances of the specified source object.
		/// </summary>
		/// <param name="sourceObject">The source object to retrieve the pool for.</param>
		/// <param name="pool">When this method returns, contains the pool that handles the specified source object, if one is found; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if the manager contains a pool that handles the specified source object; otherwise, <see langword="false"/>.</returns>
		public bool TryGetPool(TSource sourceObject, out TPool pool) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			return this.ObjectPools.TryGetValue(sourceObject, out pool);
		}
		#endregion

		#region CreatePool and DestroyPool methods.
		/// <summary>
		/// Creates a new pool using the specified settings, and attaches it to the manager.
		/// The pool is created on a child object of the manager's game object.
		/// </summary>
		/// <param name="settings">The settings to create the pool with.</param>
		/// <returns>The newly-created pool.</returns>
		public TPool CreatePool(TPoolSettings settings) {
			Contract.RequiresNotNull(settings, nameof(settings));
			Contract.RequiresNotNull(settings.Source, nameof(settings.Source));
			Contract.Requires(!this.HasPool(settings.Source));

			// Create the pool on a child object of the manager's game object.
			return this.CreatePool(settings, this.gameObject, true);
		}

		/// <summary>
		/// Creates a new pool using the specified settings, and attaches it to the manager.
		/// </summary>
		/// <param name="settings">The settings to create the pool with.</param>
		/// <param name="parent">The <see cref="GameObject"/> that the pool should be attached to, either directly or indirectly depending on <paramref name="createContainer"/>.</param>
		/// <param name="createContainer"><see langword="true"/> to create the pool on a child object parented to <paramref name="parent"/>; <see langword="false"/> to create the pool directly on <paramref name="parent"/>.</param>
		/// <param name="containerName">The name of the child object to be used as a container for the pool. If this is not specified, the name of the source will be used.</param>
		/// <returns>The newly-created pool.</returns>
		public TPool CreatePool(TPoolSettings settings, GameObject parent, bool createContainer = false, string containerName = null) {
			Contract.RequiresNotNull(settings, nameof(settings));
			Contract.RequiresNotNull(settings.Source, nameof(settings.Source));
			Contract.Requires(!this.HasPool(settings.Source));
			
			GameObject container;

			// Create a containing game object for the pool.
			if (createContainer) {
				container = new GameObject(containerName ?? this.GetSourceName(settings.Source) + " Pool");
				container.transform.SetParent(parent.transform, false);
			} else {
				container = parent;
			}

			// Create the new pool.
			var pool = container.AddComponent<TPool>();

			// Initialise the pool using the specified settings.
			pool.Initialise(settings);

			// Raise the PoolCreated event.
			this.OnPoolCreated(pool);

			// Attach the pool to the manager.
			this.AttachPool(pool);

			return pool;
		}

		/// <summary>
		/// Destroys the specified pool that's attached to the manager.
		/// </summary>
		/// <param name="pool">The pool to destroy. It must be attached to the manager.</param>
		/// <param name="destroyContainer">Whether the <see cref="GameObject"/> the pool was attached to should also be destroyed.</param>
		public void DestroyPool(TPool pool, bool destroyContainer = false) {
			Contract.RequiresNotNull(pool, nameof(pool));
			Contract.RequiresMessage(this.IsAttached(pool), "The pool being destroyed must be attached to the manager.");

			var container = pool.gameObject;

			// Detach the pool from the manager.
			this.DetachPool(pool);

			// Destroy the pool component.
			Object.Destroy(pool);

			// Optionally, destroy the game object that the pool was attached to.
			if (destroyContainer) {
				Object.Destroy(container);
			}

			// Raise the PoolDestroyed event.
			this.OnPoolDestroyed(pool);
		}
		#endregion

		#region GetPooledCount(TSource), IsPoolEmpty(TSource), CanAcquire(TSource) methods.
		/// <summary>
		/// Gets the number of instances of the specified object contained in the pool.
		/// </summary>
		/// <param name="sourceObject">The game object to check.</param>
		/// <returns>The number of instances of the specified object contained in the pool.</returns>
		public int GetPooledCount(TSource sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			// When pooling is disabled, all pools appear empty.
			if (!this.Enabled) return 0;

			TPool pool;
			if (!this.ObjectPools.TryGetValue(sourceObject, out pool)) return 0;
			return pool.Count;
		}

		/// <summary>
		/// Determines whether the pool is empty for instances of the specified object.
		/// </summary>
		/// <param name="sourceObject">The game object to check.</param>
		/// <returns><see langword="true"/> if the pool is empty for instances of the specified object; otherwise, <see langword="false"/>.</returns>
		public bool IsPoolEmpty(TSource sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			return this.GetPooledCount(sourceObject) == 0;
		}

		/// <summary>
		/// Determines whether an instance of <paramref name="sourceObject"/> can be acquired from its pool.
		/// </summary>
		/// <param name="sourceObject">The game object to check.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> can be acquired from its pool; otherwise, <see langword="false"/>.</returns>
		/// <remarks>An instance can be acquired when its pool contains at least one instance, or when <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>.</remarks>
		public bool CanAcquire(TSource sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			// Check if we have a pool for the source object.
			TPool pool;
			if (!this.ObjectPools.TryGetValue(sourceObject, out pool)) {
				// No pool exists, so check AcquireMode to see if we can create a new pool or instantiate.
				switch (this.AcquireMode) {
					case AcquireNoPoolMode.Error:
						return false;
					case AcquireNoPoolMode.Instantiate:
					case AcquireNoPoolMode.CreatePool:
						return true;
					default:
						throw new NotImplementedException();
				}
			}

			return !this.IsPoolEmpty(sourceObject) || pool.InstantiateWhenEmpty;
		}
		#endregion

		#region AttachPool(TPool), DetachPool(TPool), IsAttached(TPool) methods.
		/// <summary>
		/// Attaches the specified pool to the manager, allowing the manager to acquire and release instances from it.
		/// </summary>
		/// <param name="pool">The pool to attach.</param>
		public void AttachPool(TPool pool) {
			Contract.RequiresNotNull(pool, nameof(pool));
			Contract.RequiresMessage(pool.IsInitialised, "Pools must be initialised before they can be attached to the manager.");
			Contract.RequiresMessage(!this.IsAttached(pool), "Cannot attach a pool that's already attached to the manager.");
			Contract.RequiresMessage(!this.HasPool(pool.Source), "Another pool that handles the specified source is already attached to the manager.");

			this.ObjectPools[pool.Source] = pool;
			pool.Destroyed += this.HandlePoolDestroyed; // This event handler won't survive deserialisation. It will be re-added in OnAfterDeserialize.

			// Raise the PoolAttached event.
			this.OnPoolAttached(pool);
		}

		/// <summary>
		/// Detaches the specified pool from the manager, without destroying it.
		/// </summary>
		/// <param name="pool">The pool to detach.</param>
		public void DetachPool(TPool pool) {
			Contract.RequiresNotNull(pool, nameof(pool));
			Contract.RequiresMessage(this.IsAttached(pool), "Cannot detach a pool that isn't attached to the manager.");

			pool.Destroyed -= this.HandlePoolDestroyed;
			this.ObjectPools.Remove(pool.Source);
			
			// Raise the PoolDetached event.
			this.OnPoolDetached(pool);
		}

		/// <summary>
		/// Determines whether the specified pool is attached to the manager.
		/// </summary>
		/// <param name="pool">The pool to check.</param>
		/// <returns><see langword="true"/> if the pool is attached to the manager; otherwise, <see langword="false"/>.</returns>
		public bool IsAttached(TPool pool) {
			Contract.RequiresNotNull(pool, nameof(pool));

			// The pool must have been initialised to be attached.
			if (!pool.IsInitialised) return false;

			// Check whether any pool is attached using the same source object.
			TPool existingPool;
			if (!this.ObjectPools.TryGetValue(pool.Source, out existingPool)) {
				return false;
			}

			// Ensure the attached pool is actually the one being checked.
			return existingPool == pool;
		}
		#endregion

		#region FindChildPools method.
		/// <summary>
		/// Finds all pools that are parented to the manager's game object.
		/// </summary>
		/// <param name="includeInactive"><see langword="true"/> to include pools attached to inactive game objects; otherwise, <see langword="false"/>.</param>
		/// <returns>The pools that were found, as an array of <typeparamref name="TPool"/>.</returns>
		public TPool[] FindChildPools(bool includeInactive = true) {
			return this.gameObject.GetComponentsInChildren<TPool>(includeInactive);
		}
		#endregion

		#region Protected abstract methods.
		/// <summary>
		/// When implemented in a derived class, gets the name of the specified source.
		/// </summary>
		/// <param name="source">The source to get the name of.</param>
		/// <returns>The name of the specified source.</returns>
		protected abstract string GetSourceName(TSource source);
		#endregion

		#region Private methods.
		private IEnumerator ReleaseLater(TInstance instance, float delay) {
			Contract.RequiresNotNull(instance, nameof(instance));

			yield return new WaitForSeconds(delay);

			this.Release(instance);
		}

		/// <summary>
		/// Attaches all pools that are descendents of the manager, and adds an event to wait for any that aren't yet initialised.
		/// </summary>
		private void AttachChildren() {
			// Attach all child pools to the manager, including those on inactive game objects.
			foreach (TPool pool in this.FindChildPools(true)) {

				// If the pool isn't initialised, wait until it is before attaching it.
				if (!pool.IsInitialised) {
					pool.Initialised += this.PoolOnInitialised;
					continue;
				}

				// Ignore those for which the manager already has a pool handling that source object.
				if (this.HasPool(pool.Source)) continue;

				// Ignore those that are already attached.
				if (this.IsAttached(pool)) continue;

				this.AttachPool(pool);
			}
		}

		/// <summary>
		/// Gets the pool for the specified source object, if one exists; otherwise, takes a further action depending upon the value of <see cref="AcquireMode"/>.
		/// </summary>
		/// <param name="sourceObject">The source game object of the pool to retrieve.</param>
		/// <param name="pool">When this method returns, contains the pool for the specified source object, if one exists; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if no pool exists for the specified source object, and <see cref="AcquireMode"/> is set to <see cref="AcquireNoPoolMode.Instantiate"/>; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if a pool exists for the specified source object; otherwise, <see langword="false"/>.</returns>
		/// <remarks>
		/// <list type="bullet">
		/// <item><description>
		/// If <see cref="AcquireMode"/> is set to <see cref="AcquireNoPoolMode.Error"/> and no pool exists for the specified source object, an <see cref="ArgumentException"/> is thrown.
		/// </description></item>
		/// <item><description>
		/// If <see cref="AcquireMode"/> is set to <see cref="AcquireNoPoolMode.Instantiate"/> and no pool exists for the specified source object, a new instance of <paramref name="sourceObject"/>
		/// is instantiated. <paramref name="instance"/> is set to the new instance, and the method returns <see langword="false"/>.
		/// </description></item>
		/// <item><description>
		/// If <see cref="AcquireMode"/> is set to <see cref="AcquireNoPoolMode.CreatePool"/> and no pool exists for the specified source object, a new pool is created and attached
		/// to the manager. <paramref name="pool"/> is set to the new pool, and the method returns <see langword="true"/>.
		/// </description></item>
		/// </list>
		/// </remarks>
		/// <exception cref="ArgumentException">If no pool exists for the specified source object, and <see cref="AcquireMode"/> is set to <see cref="AcquireNoPoolMode.Error"/>.</exception>
		private bool InternalGetPoolOrAcquire(TSource sourceObject, out TPool pool, out TInstance instance) {
			// Check if a pool exists for the source object.
			if (this.ObjectPools.TryGetValue(sourceObject, out pool)) {
				instance = default(TInstance);
				return true;
			}

			// As no pool exists for the source object, decide what to do next.
			return this.InternalAcquire(sourceObject, out pool, out instance);
		}

		/// <summary>
		/// When implemented in a derived class, attempts to acquire an instance of a source according to <see cref="AcquireMode"/>.
		/// </summary>
		/// <param name="sourceObject">The source to acquire an instance of.</param>
		/// <param name="pool">When this method returns, contains the pool for the specified source, if one was created; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <param name="instance">When this method returns, contains the instance of the specified source, if one was created; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if a pool exists for the specified source; otherwise, <see langword="false"/>.</returns>
		/// <exception cref="ArgumentException">If no pool exists for the specified source, and <see cref="AcquireMode"/> is set to <see cref="AcquireNoPoolMode.Error"/>.</exception>
		protected abstract bool InternalAcquire(TSource sourceObject, out TPool pool, out TInstance instance);
		#endregion

		#region HandlePoolDestroyed method.
		/// <summary>
		/// Handles the <see cref="PoolBase{TSource,TInstance,TSettings}.Destroyed"/> event on an attached pool.
		/// </summary>
		/// <param name="sender">The sender of the event, which should be a <see cref="GameObjectPool"/>.</param>
		/// <param name="e">The event data.</param>
		private void HandlePoolDestroyed(object sender, EventArgs e) {
			var pool = (TPool)sender;
			
			// If the pool isn't attached to the manager anymore, it's been destroyed by the manager.
			// We don't need to unregister the HandlePoolDestroyed handler, as detaching will have already done so.
			if (!this.ObjectPools.ContainsKey(pool.Source)) return;
			
			pool.Destroyed -= this.HandlePoolDestroyed;
			this.ObjectPools.Remove(pool.Source);
		}
		#endregion

		#region Event raisers.
		/// <summary>
		/// Raises the <see cref="PoolAttached"/> event.
		/// </summary>
		/// <param name="pool">The pool that was attached to the manager.</param>
		protected virtual void OnPoolAttached(TPool pool) {
			this.PoolAttached.InvokeEventPooled(this, pool);
		}

		/// <summary>
		/// Raises the <see cref="PoolDetached"/> event.
		/// </summary>
		/// <param name="pool">The pool that was detached from the manager.</param>
		protected virtual void OnPoolDetached(TPool pool) {
			this.PoolDetached.InvokeEventPooled(this, pool);
		}

		/// <summary>
		/// Raises the <see cref="PoolCreated"/> event.
		/// </summary>
		/// <param name="pool">The pool that was created by the manager.</param>
		protected virtual void OnPoolCreated(TPool pool) {
			this.PoolCreated.InvokeEventPooled(this, pool);
		}

		/// <summary>
		/// Raises the <see cref="PoolDestroyed"/> event.
		/// </summary>
		/// <param name="pool">The pool that was destroyed by the manager.</param>
		protected virtual void OnPoolDestroyed(TPool pool) {
			this.PoolDestroyed.InvokeEventPooled(this, pool);
		}
		#endregion

		#region ISerializationCallbackReceiver implementation.
		/// <inheritdoc />
		void ISerializationCallbackReceiver.OnBeforeSerialize() {
			// Do nothing.
		}

		/// <inheritdoc />
		void ISerializationCallbackReceiver.OnAfterDeserialize() {
			// Restore the event handlers that aren't able to be serialised.
			foreach (var pool in this.ObjectPools.Values) {
				pool.Destroyed += this.HandlePoolDestroyed;
			}
		}
		#endregion
		
	}

}