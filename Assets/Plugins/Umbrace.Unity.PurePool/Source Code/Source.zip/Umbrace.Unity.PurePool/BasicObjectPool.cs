﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq.Expressions;
using System.Reflection;

using Umbrace.Unity.Contracts;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A basic implementation of an object pool, that allows for recycling and reuse of objects.
	/// </summary>
	/// <typeparam name="T">The type of object being pooled.</typeparam>
	/// <seealso cref="IObjectPool{T}"/>
	internal class BasicObjectPool<T> : IObjectPool<T> {

		// T could be constrained to only classes, but this would prohibit the use of structs as containers of multiple references.
		// Whenever the number of objects in the pool changes, a check should be made to see if CanAcquire has changed value, and if so, OnCanAcquireChanged should be called.

		#region Constants.
		/// <summary>
		/// The default initial size of newly-created pools.
		/// </summary>
		public const int DefaultInitialSize = 0;

		/// <summary>
		/// The default maximum size of newly-created pools.
		/// </summary>
		public const int DefaultMaximumSize = 1000;
		#endregion

		#region Fields.
		private readonly List<T> pooledObjects = new List<T>();

		private readonly Func<T> objectFactory;

		/// <summary>
		/// A value indicating whether the pooled type <typeparamref name="T"/> implements the <see cref="IPoolable"/> interface.
		/// </summary>
		private readonly bool pooledTypeImplementsIPoolable;

		private int maximumSize;
		private bool instantiateWhenEmpty = true;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets or sets the level of log messaging that the pool will output.
		/// </summary>
		public LogLevel LogMessages { get; set; } = LogLevel.Warning;

		/// <summary>
		/// Gets or sets a value indicating whether to instantiate a new object when the pool is empty, and an attempt is made to acquire from the pool.
		/// </summary>
		public bool InstantiateWhenEmpty {
			get => this.instantiateWhenEmpty;
			set {
				if (this.instantiateWhenEmpty == value) return;

				bool previousCanAcquire = this.CanAcquire;
				this.instantiateWhenEmpty = value;
				if (previousCanAcquire != this.CanAcquire) {
					// Raise the CanAcquireChanged event.
					this.OnCanAcquireChanged(this.CanAcquire);
				}
			}
		}

		/// <summary>
		/// Gets or sets the maximum size of the pool, which is the maximum number of objects it can contain.
		/// </summary>
		/// <remarks>
		/// <para>The maximum size must be greater than, or equal to, zero. It cannot be a negative number.</para>
		/// <para>If an object is released to the pool while the pool is full, the object will be destroyed.</para>
		/// <para>
		/// If <see cref="MaximumSize"/> is set to a value lower than the current <see cref="Count"/>, the pool will be
		/// reduced in size by destroying excess objects.
		/// </para>
		/// </remarks>
		/// <seealso cref="Count"/>
		public int MaximumSize {
			get => this.maximumSize;
			set {
				Contract.Requires(value >= 0, $"The {nameof(this.MaximumSize)} property cannot be set to a negative number.");

				if (this.MaximumSize == value) return;
				this.maximumSize = value;

				// If there are too many objects, remove any over the maximum amount.
				if (this.Count > this.MaximumSize) {
					this.SetSize(this.MaximumSize);
				}
			}
		}

		/// <summary>
		/// Gets the number of objects currently contained by the pool.
		/// </summary>
		/// <seealso cref="IsFull"/>
		/// <seealso cref="IsEmpty"/>
		/// <seealso cref="CountChanged"/>
		/// <seealso cref="CountChangedHandler"/>
		/// <seealso cref="MaximumSize"/>
		public int Count => this.pooledObjects.Count;

		/// <summary>
		/// Gets a value indicating whether the pool is empty and contains no objects.
		/// </summary>
		/// <seealso cref="Count"/>
		/// <seealso cref="IsFull"/>
		public bool IsEmpty => this.Count == 0;

		/// <summary>
		/// Gets a value indicating whether the pool is full, and cannot contain any more objects.
		/// </summary>
		/// <seealso cref="Count"/>
		/// <seealso cref="IsEmpty"/>
		public bool IsFull => this.Count == this.MaximumSize;

		/// <summary>
		/// <para>Gets a value indicating whether an instance can be acquired from the pool.</para>
		/// <para>An instance can be acquired when the pool contains at least one instance, or when <see cref="InstantiateWhenEmpty"/> is <see langword="true"/>.</para>
		/// </summary>
		/// <seealso cref="IsEmpty"/>
		/// <seealso cref="InstantiateWhenEmpty"/>
		/// <seealso cref="CanAcquireChanged"/>
		/// <seealso cref="CanAcquireChangedHandler"/>
		public bool CanAcquire => !this.IsEmpty || this.InstantiateWhenEmpty;

		/// <summary>
		/// Gets a list of items currently contained by the pool.
		/// </summary>
		/// <remarks>
		/// <para>
		/// This property always creates a new <see cref="List{T}"/> each time the property getter is accessed.
		/// For performance reasons the value should be cached where possible, to avoid the costs of object instantiation and garbage collection.
		/// </para>
		/// <para>See the <see cref="GetItems"/> method for a way to avoid the allocation of a new <see cref="List{T}"/> object.</para>
		/// </remarks>
		/// <seealso cref="GetItems"/>
		public IList<T> Items => new List<T>(this.pooledObjects);
		#endregion

		#region Events.
		/// <summary>
		/// Occurs when a new object is instantiated.
		/// </summary>
		public event EventHandler ObjectInstantiated;

		/// <summary>
		/// Occurs when an object is acquired from the pool.
		/// </summary>
		/// <remarks>
		/// This event will be invoked for objects that are instantiated when the pool is empty, in addition to <see cref="ObjectInstantiated"/>.
		/// </remarks>
		public event EventHandler ObjectAcquired;

		/// <summary>
		/// Occurs when an object is released back to the pool.
		/// </summary>
		/// <remarks>
		/// This event will be invoked for objects that are released to a pool that has reached its maximum size, and are therefore destroyed,
		/// in addition to <see cref="ObjectDestroyed"/>.
		/// </remarks>
		public event EventHandler ObjectReleased;

		/// <summary>
		/// Occurs when an object is destroyed.
		/// </summary>
		public event EventHandler ObjectDestroyed;

		/// <summary>
		/// Occurs when the value of <see cref="CanAcquire"/> changes.
		/// </summary>
		/// <seealso cref="CanAcquire"/>
		public event EventHandler CanAcquireChanged;

		/// <summary>
		/// Occurs when <see cref="Count"/> changes.
		/// </summary>
		/// <seealso cref="Count"/>
		public event EventHandler CountChanged;
		#endregion

		#region Event-like actions.
		/// <summary>
		/// An action that will be invoked when a new object is instantiated. The new object is passed as a parameter.
		/// </summary>
		public Action<T> ObjectInstantiatedHandler { get; set; }

		/// <summary>
		/// An action that will be invoked when an object is acquired from the pool.
		/// The object is passed as a parameter, as well as a value indicating whether the object was instantiated.
		/// </summary>
		/// <remarks>
		/// This action will be invoked for objects that are instantiated when the pool is empty, in addition to <see cref="ObjectInstantiatedHandler"/>.
		/// In this situation, the second parameter is set to <see langword="true"/> to indicate that the acquired object was instantiated.
		/// </remarks>
		public Action<T, bool> ObjectAcquiredHandler { get; set; }

		/// <summary>
		/// An action that will be invoked when an object is released back to the pool.
		/// The object being released is passed as a parameter, as well as a value indicating whether the object is about to be destroyed.
		/// </summary>
		/// <remarks>
		/// This action will be invoked for objects that are released to a pool that has reached its maximum size.
		/// In this situation, the second parameter is set to <see langword="true"/> to indicate that the released object is about to be destroyed.
		/// </remarks>
		public Action<T, bool> ObjectReleasedHandler { get; set; }

		/// <summary>
		/// An action that will be invoked when an object is destroyed. The object being destroyed is passed as a parameter.
		/// </summary>
		public Action<T> ObjectDestroyedHandler { get; set; }

		/// <summary>
		/// An action that will be invoked when the value of <see cref="CanAcquire"/> changes.
		/// The new value of <see cref="CanAcquire"/> is passed as a parameter.
		/// </summary>
		/// <seealso cref="CanAcquire"/>
		public Action<bool> CanAcquireChangedHandler { get; set; }

		/// <summary>
		/// An action that will be invoked when <see cref="Count"/> changes.
		/// The new value of <see cref="Count"/> is passed as a parameter.
		/// </summary>
		/// <seealso cref="Count"/>
		public Action<int> CountChangedHandler { get; set; }
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="BasicObjectPool{T}"/> class.
		/// </summary>
		/// <remarks>
		/// This constructor uses the public parameterless constructor on type <typeparamref name="T"/> for the creation of new objects.
		/// If you need to have greater control over the creation of new objects, or <typeparamref name="T"/> does not have a public parameterless
		/// constructor, you should use the overloaded constructor that takes a factory method, <see cref="BasicObjectPool{T}(Func{T})"/>.
		/// </remarks>
		/// <exception cref="InvalidOperationException">If type <typeparamref name="T"/> has no public parameterless constructor.</exception>
		public BasicObjectPool() : this(BasicObjectPool<T>.DefaultInitialSize, BasicObjectPool<T>.DefaultMaximumSize) {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="BasicObjectPool{T}"/> class.
		/// </summary>
		/// <param name="initialSize">The initial number of objects to populate the pool with.</param>
		/// <param name="maximumSize">The maximum size of the pool, which is the maximum number of objects it can contain.</param>
		/// <remarks>
		/// This constructor uses the public parameterless constructor on type <typeparamref name="T"/> for the creation of new objects.
		/// If you need to have greater control over the creation of new objects, or <typeparamref name="T"/> does not have a public parameterless
		/// constructor, you should use the overloaded constructor that takes a factory method, <see cref="BasicObjectPool{T}(Func{T}, int, int)"/>.
		/// </remarks>
		/// <exception cref="InvalidOperationException">If type <typeparamref name="T"/> has no public parameterless constructor.</exception>
		public BasicObjectPool(int initialSize, int maximumSize) {
			Contract.RequiresMessage(initialSize >= 0, () => $"{nameof(initialSize)} cannot be a negative number.");
			Contract.RequiresMessage(initialSize <= maximumSize, () => $"{nameof(initialSize)} cannot be larger than {nameof(maximumSize)}.");

			Type typeOfT = typeof(T);
			ConstructorInfo defaultConstructor = typeOfT.GetConstructor(Type.EmptyTypes);
			if (defaultConstructor == null) throw new InvalidOperationException($"No public parameterless constructor could be found on the pooled type ({typeof(T).FullName}). Use the overloaded constructor that takes a factory method for object creation.");
			this.objectFactory = Expression.Lambda<Func<T>>(Expression.New(defaultConstructor)).Compile();

			this.pooledTypeImplementsIPoolable = typeof(IPoolable).IsAssignableFrom(typeOfT);

			this.Initialise(initialSize, maximumSize);
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="BasicObjectPool{T}"/> class.
		/// </summary>
		/// <param name="factory">A factory method that constructs and returns a new object of type <typeparamref name="T"/> each time it is invoked.</param>
		public BasicObjectPool(Func<T> factory) : this(factory, BasicObjectPool<T>.DefaultInitialSize, BasicObjectPool<T>.DefaultMaximumSize) {
			Contract.RequiresNotNull(factory, nameof(factory));
			
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="BasicObjectPool{T}"/> class.
		/// </summary>
		/// <param name="factory">A factory method that constructs and returns a new object of type <typeparamref name="T"/> each time it is invoked.</param>
		/// <param name="initialSize">The initial number of objects to populate the pool with.</param>
		/// <param name="maximumSize">The maximum size of the pool, which is the maximum number of objects it can contain.</param>
		public BasicObjectPool(Func<T> factory, int initialSize, int maximumSize) {
			Contract.RequiresNotNull(factory, nameof(factory));
			Contract.RequiresMessage(initialSize >= 0, () => $"{nameof(initialSize)} cannot be a negative number.");
			Contract.RequiresMessage(initialSize <= maximumSize, () => $"{nameof(initialSize)} cannot be larger than {nameof(maximumSize)}.");

			this.objectFactory = factory;
			this.pooledTypeImplementsIPoolable = typeof(IPoolable).IsAssignableFrom(typeof(T));

			this.Initialise(initialSize, maximumSize);
		}
		#endregion

		#region Initialise method.
		/// <summary>
		/// Initialises the pool, populating it with the initial number of objects.
		/// </summary>
		/// <param name="initialSize">The initial number of objects to populate the pool with.</param>
		/// <param name="maximumSize">The maximum size of the pool, which is the maximum number of objects it can contain.</param>
		private void Initialise(int initialSize, int maximumSize) {
			Contract.RequiresMessage(initialSize >= 0, () => $"{nameof(initialSize)} cannot be a negative number.");
			Contract.RequiresMessage(initialSize <= maximumSize, () => $"{nameof(initialSize)} cannot be larger than {nameof(maximumSize)}.");
			
			this.MaximumSize = maximumSize;

			// Populate the pool with the initial number of pooled objects.
			this.SetSize(initialSize);
		}
		#endregion

		#region Acquire method.
		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <returns>An object from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire"/>
		/// <seealso cref="Release"/>
		public T Acquire() {
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			//Contract.Ensures(Contract.Result<T>() != null);

			T instance;
			if (!this.TryAcquire(out instance)) {
				// The pool is empty and instantiation is not allowed. Shouldn't happen if the preconditions are met.
				throw new InvalidOperationException("Cannot acquire from an empty pool when instantiation is disabled.");
			}

			Debug.Assert(instance != null);

			return instance;
		}
		#endregion

		#region TryAcquire(out T) method.
		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <param name="instance">When this method returns, contains the object from the pool, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire"/>
		/// <seealso cref="Release"/>
		public bool TryAcquire(out T instance) {
			bool instantiated;

			// If there's an object in the pool, acquire it.
			if (!this.IsEmpty) {
				bool previousCanAcquire = this.CanAcquire;

				instance = this.AcquireFromPool();
				instantiated = false;

				// Raise the CountChanged event.
				this.OnCountChanged(this.Count);

				if (previousCanAcquire != this.CanAcquire) {
					// Raise the CanAcquireChanged event.
					this.OnCanAcquireChanged(this.CanAcquire);
				}
			} else if (this.InstantiateWhenEmpty) {
				// If the pool is empty, and instantiation is allowed, instantiate a new object.
				instance = this.Instantiate();
				instantiated = true;
			} else {
				// At this point, the pool is empty and instantiation is not allowed. An instance cannot be acquired.
				instance = default(T);
				return false;
			}

			Debug.Assert(instance != null);

			// Raise the ObjectAcquired event.
			this.OnObjectAcquired(instance, instantiated);

			return true;
		}
		#endregion

		#region Release(T) method.
		/// <summary>
		/// Releases an object back to the pool.
		/// </summary>
		/// <param name="instance">The object to release to the pool.</param>
		public void Release(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			// Ensure the pool size isn't being exceeded by returning the object to it; if it is, destroy the object instead.
			if (this.Count < this.MaximumSize) {
				bool previousCanAcquire = this.CanAcquire;

				// Let the object know that it's being released to the pool.
				if (this.pooledTypeImplementsIPoolable) {
					((IPoolable)instance).Release();
				}

				// Add the game object back to the pool.
				this.AddToPool(instance);

				// Raise the ObjectReleased event.
				this.OnObjectReleased(instance, false);

				// Raise the CountChanged event.
				this.OnCountChanged(this.Count);

				if (previousCanAcquire != this.CanAcquire) {
					// Raise the CanAcquireChanged event.
					this.OnCanAcquireChanged(this.CanAcquire);
				}
			} else {
				// The pool is full, so the object is destroyed.
				// Raise the ObjectReleased event.
				this.OnObjectReleased(instance, true);

				// Raise the ObjectDestroyed event.
				this.OnObjectDestroyed(instance);
			}
		}
		#endregion

		#region SetSize(int), Fill, Clear, Remove(T), Contains(T) methods.
		/// <summary>
		/// Sets the number of objects contained by the pool, either destroying excess pooled objects, or instantiating new ones.
		/// </summary>
		/// <param name="poolSize">The target number of objects the pool should contain.</param>
		/// <remarks>
		/// <paramref name="poolSize"/> cannot be a negative number, and cannot be larger than <see cref="MaximumSize"/>.
		/// </remarks>
		/// <seealso cref="Fill"/>
		/// <seealso cref="Clear"/>
		public void SetSize(int poolSize) {
			Contract.RequiresMessage(poolSize >= 0, () => $"{nameof(poolSize)} cannot be a negative number.");
			Contract.RequiresMessage(poolSize <= this.MaximumSize, () => $"{nameof(poolSize)} cannot be larger than {nameof(this.MaximumSize)}.");

			// Nothing to do if the number of objects in the pool matches the target number.
			if (this.Count == poolSize) return;

			bool previousCanAcquire = this.CanAcquire;

			// Instantiate new objects until the size is met.
			while (this.Count < poolSize) {
				T poolObject = this.Instantiate();

				// Add the object to the pool.
				this.AddToPool(poolObject);
			}

			// Destroy pooled objects until the size is met.
			while (this.Count > poolSize) {
				T instance = this.Pop();

				// Raise the ObjectDestroyed event.
				this.OnObjectDestroyed(instance);
			}

			// Raise the CountChanged event.
			this.OnCountChanged(this.Count);

			if (previousCanAcquire != this.CanAcquire) {
				// Raise the CanAcquireChanged event.
				this.OnCanAcquireChanged(this.CanAcquire);
			}
		}

		/// <summary>
		/// Fills the pool, populating it with pooled objects until it reaches the maximum pool size.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Clear"/>
		/// <seealso cref="MaximumSize"/>
		public void Fill() {
			//Contract.Ensures(this.Count == this.MaximumSize);

			// Fill the pool by setting the number of objects to the maximum allowed.
			this.SetSize(this.MaximumSize);
		}

		/// <summary>
		/// Clears the pool, emptying it of all pooled objects.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Fill"/>
		public void Clear() {
			//Contract.Ensures(this.Count == 0);

			// Clear the pool by setting the number of objects to zero.
			this.SetSize(0);
		}

		/// <summary>
		/// Removes the specified instance from the pool.
		/// </summary>
		/// <param name="instance">The instance of the source object that should be removed from the pool.</param>
		/// <returns><see langword="true"/> if <paramref name="instance"/> was found in the pool and removed; otherwise, <see langword="false"/>.</returns>
		public bool Remove(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			bool previousCanAcquire = this.CanAcquire;
			bool removed = this.pooledObjects.Remove(instance);

			if (removed) {
				// Raise the CountChanged event.
				this.OnCountChanged(this.Count);

				if (previousCanAcquire != this.CanAcquire) {
					// Raise the CanAcquireChanged event.
					this.OnCanAcquireChanged(this.CanAcquire);
				}
			}

			return removed;
		}

		/// <summary>
		/// Determines whether an instance is in the pool.
		/// </summary>
		/// <param name="instance">The instance of the source object to locate in the pool.</param>
		/// <returns><see langword="true"/> if <paramref name="instance"/> is found in the pool; otherwise, <see langword="false"/>.</returns>
		public bool Contains(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			return this.pooledObjects.Contains(instance);
		}
		#endregion

		#region GetItems method.
		/// <summary>
		/// Gets a list of items currently contained by the pool, and stores them in the specified <see cref="List{T}"/>.
		/// </summary>
		/// <param name="list">The existing list in which the items should be stored.</param>
		/// <seealso cref="Items"/>
		public void GetItems(List<T> list) {
			Contract.RequiresNotNull(list, nameof(list));

			list.AddRange(this.pooledObjects);
		}
		#endregion

		#region InternalAdd(T) method.
		/// <summary>
		/// Adds an instance directly to the pool. This method is used internally and should be used with caution.
		/// </summary>
		/// <param name="instance">The instance to add to the pool.</param>
		/// <remarks>
		/// <para>If the maximum size of the pool would be exceeded by adding the instance, the instance is destroyed.</para>
		/// <para>
		/// This method does not inform the instance that it is being returned to the pool, and does not raise
		/// any events. It should only be used to add instances to the pool that were previously already in the pool,
		/// such as those serialised during live recompilation.
		/// </para>
		/// </remarks>
		internal void InternalAdd(T instance) {
			// Ensure the pool size isn't being exceeded by returning the object to it; if it is, destroy the object instead.
			if (this.Count < this.MaximumSize) {
				// Add the game object back to the pool.
				this.AddToPool(instance);
			} else {
				// The pool is full, so the object is destroyed.
				// Raise the ObjectDestroyed event.
				this.OnObjectDestroyed(instance);
			}
		}
		#endregion

		#region InternalTryInstantiate(out T) method.
		/// <summary>
		/// Instantiates a new object if <see cref="InstantiateWhenEmpty"/> is <see langword="true"/>.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(out T instance) {
			if (this.InstantiateWhenEmpty) {
				// If instantiation is allowed, instantiate a new object.
				instance = this.Instantiate();
			} else {
				// Instantiation is not allowed. An instance cannot be acquired since we're not allowed to use any pooled objects.
				instance = default(T);
				return false;
			}
			
			// Raise the ObjectAcquired event.
			this.OnObjectAcquired(instance, true);

			return true;
		}
		#endregion

		#region Private methods.
		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <returns>An object from the pool.</returns>
		private T AcquireFromPool() {
			Contract.Requires(!this.IsEmpty);

			// Get an object from the pool.
			T instance = this.Pop();
			
			// If the object implements IPoolable, tell it to reinitialise as it's being taken from the pool.
			if (this.pooledTypeImplementsIPoolable) {
				((IPoolable)instance).Acquire();
			}

			return instance;
		}

		/// <summary>
		/// Instantiates a new object.
		/// </summary>
		/// <returns>A newly-instantiated object.</returns>
		private T Instantiate() {
			// Construct a new instance using the factory method.
			T instance = this.objectFactory();
			
			// Raise the ObjectInstantiated event.
			this.OnObjectInstantiated(instance);

			return instance;
		}

		/// <summary>
		/// Adds the specified object to the pool.
		/// </summary>
		/// <param name="instance">The object to add to the pool.</param>
		private void AddToPool(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			this.pooledObjects.Add(instance);
		}

		/// <summary>
		/// Removes an object from the pool, and returns it.
		/// </summary>
		/// <returns>The object that was removed from the pool.</returns>
		private T Pop() {
			int lastIndex = this.pooledObjects.Count - 1;
			T item = this.pooledObjects[lastIndex];
			this.pooledObjects.RemoveAt(lastIndex);
			return item;
		}
		#endregion

		#region Event raisers.
		/// <summary>
		/// Raises the <see cref="ObjectInstantiated"/> event.
		/// </summary>
		/// <param name="instance">The object that was instantiated.</param>
		protected virtual void OnObjectInstantiated(T instance) {
			this.ObjectInstantiated?.Invoke(this, EventArgs.Empty);
			this.ObjectInstantiatedHandler?.Invoke(instance);
		}

		/// <summary>
		/// Raises the <see cref="ObjectAcquired"/> event.
		/// </summary>
		/// <param name="instance">The object that was acquired from the pool.</param>
		/// <param name="instantiated">A value indicating whether the acquired object was instantiated specifically for this acquisition, rather than being taken from the pool.</param>
		protected virtual void OnObjectAcquired(T instance, bool instantiated) {
			this.ObjectAcquired?.Invoke(this, EventArgs.Empty);
			this.ObjectAcquiredHandler?.Invoke(instance, instantiated);
		}

		/// <summary>
		/// Raises the <see cref="ObjectReleased"/> event.
		/// </summary>
		/// <param name="instance">The object that was released back to the pool.</param>
		/// <param name="destroying">A value indicating whether the released object is about to be destroyed.</param>
		protected virtual void OnObjectReleased(T instance, bool destroying) {
			this.ObjectReleased?.Invoke(this, EventArgs.Empty);
			this.ObjectReleasedHandler?.Invoke(instance, destroying);
		}

		/// <summary>
		/// Raises the <see cref="ObjectDestroyed"/> event.
		/// </summary>
		/// <param name="instance">The object that was destroyed.</param>
		protected virtual void OnObjectDestroyed(T instance) {
			this.ObjectDestroyed?.Invoke(this, EventArgs.Empty);
			this.ObjectDestroyedHandler?.Invoke(instance);
		}

		/// <summary>
		/// Raises the <see cref="CanAcquireChanged"/> event.
		/// </summary>
		/// <param name="canAcquire">The new value of <see cref="CanAcquire"/>.</param>
		protected virtual void OnCanAcquireChanged(bool canAcquire) {
			this.CanAcquireChanged?.Invoke(this, EventArgs.Empty);
			this.CanAcquireChangedHandler?.Invoke(canAcquire);
		}

		/// <summary>
		/// Raises the <see cref="CountChanged"/> event.
		/// </summary>
		/// <param name="count">The new value of <see cref="Count"/>.</param>
		protected virtual void OnCountChanged(int count) {
			this.CountChanged?.Invoke(this, EventArgs.Empty);
			this.CountChangedHandler?.Invoke(count);
		}
		#endregion

	}

}