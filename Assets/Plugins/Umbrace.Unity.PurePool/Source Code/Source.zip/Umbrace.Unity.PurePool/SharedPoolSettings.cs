using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A container class for the shared settings that a <see cref="GameObjectPool"/> and a <see cref="ComponentPool"/> can have.
	/// </summary>
	/// <typeparam name="TSource">The type of object being pooled.</typeparam>
	[Serializable]
	public abstract class SharedPoolSettings<TSource> : ISharedPoolSettings<TSource> {

		#region Fields.
		[SerializeField, HideInInspector] private int initialSize;
		[SerializeField, HideInInspector] private bool initialiseOnStart;
		[SerializeField, HideInInspector] private bool isPoolingEnabled;
		[SerializeField, HideInInspector] private LogLevel logMessages;
		[SerializeField, HideInInspector] private NotificationMode notificationMode;
		[SerializeField, HideInInspector] private bool dontDestroyOnLoad;
		[SerializeField, HideInInspector] private bool instantiateWhenEmpty;
		[SerializeField, HideInInspector] private bool reparentPooledObjects;
		[SerializeField, HideInInspector] private int maximumSize;
		[SerializeField, HideInInspector] private bool recordStatistics;
		[SerializeField, HideInInspector] private bool warnOnDestroy;

		[SerializeField, HideInInspector] private bool frozen;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets a value indicating whether the object has been frozen, and cannot be modified.
		/// </summary>
		public bool Frozen => this.frozen;

		/// <summary>
		/// Gets or sets the source object that will be pooled.
		/// </summary>
		public abstract TSource Source { get; set; }

		/// <summary>
		/// Gets or sets the initial size of the pool.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="InitialSize"/>, if the <see cref="SharedPoolSettings{TSource}"/> have been frozen.</exception>
		public int InitialSize {
			get => this.initialSize;
			set {
				if (value < 0) throw new ArgumentOutOfRangeException(nameof(value), $"{nameof(this.InitialSize)} cannot be a negative value.");
				this.EnsureNotFrozen();
				this.initialSize = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to initialise the pool in the <see cref="MonoBehaviour"/> Start method.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="InitialiseOnStart"/>, if the <see cref="SharedPoolSettings{TSource}"/> have been frozen.</exception>
		public bool InitialiseOnStart {
			get => this.initialiseOnStart;
			set {
				this.EnsureNotFrozen();
				this.initialiseOnStart = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether pooling is enabled.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="Enabled"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public bool Enabled {
			get => this.isPoolingEnabled;
			set {
				this.EnsureNotFrozen();
				this.isPoolingEnabled = value;
			}
		}

		/// <summary>
		/// Gets or sets the level of log messaging that the pool will output.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="LogMessages"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public LogLevel LogMessages {
			get => this.logMessages;
			set {
				this.EnsureNotFrozen();
				this.logMessages = value;
			}
		}

		/// <summary>
		/// Gets or sets the modes in which pooled objects are notified of their acquisition from, and release to, the pool.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="NotificationMode"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public NotificationMode NotificationMode {
			get => this.notificationMode;
			set {
				this.EnsureNotFrozen();
				this.notificationMode = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether the pool should persist between scene changes.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="DontDestroyOnLoad"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public bool DontDestroyOnLoad {
			get => this.dontDestroyOnLoad;
			set {
				this.EnsureNotFrozen();
				this.dontDestroyOnLoad = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to instantiate a new object when the pool is empty, and an attempt is made to acquire from the pool.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="InstantiateWhenEmpty"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public bool InstantiateWhenEmpty {
			get => this.instantiateWhenEmpty;
			set {
				this.EnsureNotFrozen();
				this.instantiateWhenEmpty = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to re-parent the pooled objects to the pool's transform, after the objects are released.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="ReparentPooledObjects"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public bool ReparentPooledObjects {
			get => this.reparentPooledObjects;
			set {
				this.EnsureNotFrozen();
				this.reparentPooledObjects = value;
			}
		}

		/// <summary>
		/// Gets or sets the maximum size of the pool, which is the maximum number of objects it can contain.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="MaximumSize"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public int MaximumSize {
			get => this.maximumSize;
			set {
				if (value < 0) throw new ArgumentOutOfRangeException(nameof(value), $"{nameof(this.MaximumSize)} cannot be a negative value.");
				this.EnsureNotFrozen();
				this.maximumSize = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to record pool statistics.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="RecordStatistics"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public bool RecordStatistics {
			get => this.recordStatistics;
			set {
				this.EnsureNotFrozen();
				this.recordStatistics = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to log a warning message when a poolable object is destroyed (either inside of the pool, or while in use).
		/// </summary>
		/// <remarks>
		/// <para>
		/// Poolable objects should be released to the pool and re-used, rather than being destroyed.
		/// This property ensures any destruction of the pooled objects is logged.
		/// </para>
		/// <para>
		/// Unfortunately, scene changes may also cause pooled objects to be destroyed. In this case, the warning message will be shown incorrectly,
		/// and can safely be ignored.
		/// </para>
		/// </remarks>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="WarnOnDestroy"/>, if the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		public bool WarnOnDestroy {
			get => this.warnOnDestroy;
			set {
				this.EnsureNotFrozen();
				this.warnOnDestroy = value;
			}
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Initialises a new instance of the <see cref="SharedPoolSettings{TSource}"/> class, using the specified settings.
		/// </summary>
		/// <param name="settings">The settings to copy the values from.</param>
		protected SharedPoolSettings(SharedPoolSettings<TSource> settings) {
			if (settings != null) {
				this.initialSize = settings.initialSize;
				this.initialiseOnStart = settings.initialiseOnStart;
				this.isPoolingEnabled = settings.isPoolingEnabled;
				this.logMessages = settings.logMessages;
				this.notificationMode = settings.notificationMode;
				this.dontDestroyOnLoad = settings.dontDestroyOnLoad;
				this.instantiateWhenEmpty = settings.instantiateWhenEmpty;
				this.maximumSize = settings.maximumSize;
				this.recordStatistics = settings.recordStatistics;
				this.reparentPooledObjects = settings.reparentPooledObjects;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Freezes the object and prevents modifications being made to it.
		/// </summary>
		public virtual void Freeze() {
			this.frozen = true;
		}

		/// <summary>
		/// Ensures the <see cref="SharedPoolSettings{TSource}"/> has not been frozen, and throws an exception if it has.
		/// </summary>
		/// <exception cref="InvalidOperationException">If the <see cref="SharedPoolSettings{TSource}"/> has been frozen.</exception>
		protected void EnsureNotFrozen() {
			if (this.frozen) throw new InvalidOperationException("This object has been frozen and cannot be modified.");
		}
		#endregion

	}

}