﻿using System;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Represents a contract violation in a method or property.
	/// </summary>
	internal class ContractException : Exception {

		/// <summary>
		/// Initialises a new instance of the <see cref="ContractException"/> class.
		/// </summary>
		internal ContractException() {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="ContractException"/> class.
		/// </summary>
		/// <param name="message">The message that describes the error.</param>
		internal ContractException(string message) : base(message) {
			// Do nothing.
		}

	}

}