﻿using System;

using Umbrace.Unity.PurePool.ForEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	/// <summary>
	/// A container class that holds display-related settings for pool containers.
	/// </summary>
	[Serializable]
	internal class ContainerSettings {

		[SerializeField] private BoolEditorChangeValue foldoutOpen = new BoolEditorChangeValue();

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the foldout for the container should be expanded in the inspector.
		/// </summary>
		[SerializeField]
		public BoolEditorChangeValue FoldoutOpen => this.foldoutOpen;

		/// <summary>
		/// Updates the <see cref="EditorChangeValue{T}"/> objects to their new value.
		/// This should be called at the start of the <see cref="EventType.Layout"/> pass.
		/// </summary>
		public void ChangeValues() {
			this.foldoutOpen.ChangeValue();
		}

	}

}