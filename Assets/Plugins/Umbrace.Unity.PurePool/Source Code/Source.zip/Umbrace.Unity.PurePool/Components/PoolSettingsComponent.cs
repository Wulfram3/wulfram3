﻿using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[DisallowMultipleComponent]
	[AddComponentMenu("")] // Hide this script in the Components menu of the editor.
	internal class PoolSettingsComponent : MonoBehaviour {

		[SerializeField, HideInInspector] private PoolDisplaySettings settings = new PoolDisplaySettings();
		[SerializeField, HideInInspector] private TimeDisplayMode timeDisplayMode = TimeDisplayMode.RealtimeSinceStartup;

		/// <summary>
		/// Gets the display-related settings for the pool.
		/// </summary>
		public PoolDisplaySettings PoolSettings => this.settings;

		/// <summary>
		/// Gets or sets the way in which times are displayed.
		/// </summary>
		public TimeDisplayMode TimeDisplayMode {
			get { return this.timeDisplayMode; }
			set { this.timeDisplayMode = value; }
		}
		
		public void ChangeValues() {
			this.settings.ChangeValues();
		}

	}

}