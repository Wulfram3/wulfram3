﻿using System;
using System.Diagnostics.CodeAnalysis;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A component that allows pooling of multiple associated <see cref="MonoBehaviour"/> components.
	/// </summary>
	[DisallowMultipleComponent]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	public class PoolableMonoBehaviour : MonoBehaviour, IPoolable {

		private class TypeToStringDictionary : SerialisableDictionary<Type, string> { }

		[SerializeField]
		[Tooltip("The " + nameof(MonoBehaviour) + " components that are to be reset. Leave blank to automatically find in children.")]
		private MonoBehaviour[] monoBehaviours;

		[SerializeField, HideInInspector]
		private TypeToStringDictionary serialisedDefault = new TypeToStringDictionary();

		private void Awake() {
			// Allow the MonoBehaviours to be set up in the inspector, or automatically find them if they weren't set up.
			if (this.monoBehaviours == null || this.monoBehaviours.Length == 0) {
				this.monoBehaviours = this.GetComponentsInChildren<MonoBehaviour>(true);
			}

			foreach (var monoBehaviour in this.monoBehaviours) {
				// Ignore if we already have the default values for this type.
				if (this.serialisedDefault.ContainsKey(monoBehaviour.GetType())) continue;

				// Convert the current values of the script to JSON, and then store it.
				this.serialisedDefault.Add(monoBehaviour.GetType(), JsonUtility.ToJson(monoBehaviour));
			}
		}

		void IPoolable.Acquire() {
			// Do nothing.
		}

		void IPoolable.Release() {
			foreach (var monoBehaviour in this.monoBehaviours) {
				// Ignore if we don't have any default values for this type.
				if (!this.serialisedDefault.ContainsKey(monoBehaviour.GetType())) continue;

				// Copy the serialised JSON values back to the script.
				string serialised = this.serialisedDefault[monoBehaviour.GetType()];
				JsonUtility.FromJsonOverwrite(serialised, monoBehaviour);
			}
		}

	}

}