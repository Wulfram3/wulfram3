﻿using System.Diagnostics.CodeAnalysis;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A component that allows pooling of multiple associated <see cref="Rigidbody"/> components.
	/// </summary>
	[RequireComponent(typeof(Rigidbody))]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	public class PoolableRigidbody : MonoBehaviour, IPoolable {

		[SerializeField]
		[Tooltip("The " + nameof(Rigidbody) + " components that are to be reset. Leave blank to automatically find in children.")]
		private Rigidbody[] rigidbodies;
		
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private void Awake() {
			// Allow the rigidbodies to be set up in the inspector, or automatically find them if they weren't set up.
			if (this.rigidbodies == null || this.rigidbodies.Length == 0) {
				this.rigidbodies = this.GetComponentsInChildren<Rigidbody>();
			}
		}

		/// <inheritdoc />
		void IPoolable.Acquire() {
			// Do nothing.
		}

		/// <inheritdoc />
		void IPoolable.Release() {
			// Reset the velocities to stop any movement.
			foreach (var rigidbody in this.rigidbodies) {
				// Skip any that have been destroyed.
				if (rigidbody == null) continue;

				rigidbody.velocity = Vector3.zero;
				rigidbody.angularVelocity = Vector3.zero;
			}
		}

	}

}