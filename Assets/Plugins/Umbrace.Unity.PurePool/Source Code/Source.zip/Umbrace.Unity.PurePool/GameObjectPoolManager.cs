﻿using System;
using System.Collections.Generic;

using Umbrace.Unity.Contracts;
#if UNITY_EDITOR
using System.Diagnostics.CodeAnalysis;
using UnityEditor;
#endif

using UnityEngine;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Manages a collection of <see cref="GameObjectPool"/> components, simplifying access to the pools and allowing for automatic pool creation.
	/// </summary>
	/// <example>
	/// <code language="cs">
	/// // Create the manager as a component on a game object.
	/// var manager = gameObject.AddComponent&lt;GameObjectPoolManager&gt;();
	/// 
	/// // Set up the manager's properties.
	/// manager.DontDestroyOnLoad = true;
	/// manager.AttachDescendentPools = true;
	/// manager.AcquireMode = AcquireNoPoolMode.CreatePool;
	/// 
	/// // Attach an existing pool to the manager.
	/// manager.AttachPool(pool);
	/// 
	/// // Create a pool that is attached to the manager.
	/// manager.CreatePool(new GameObjectPoolSettings {
	///		Source = myPrefab,
	///		DontDestroyOnLoad = true,
	///		Enabled = true,
	///		InitialiseOnStart = true,
	///		InitialSize = 10,
	///		InstantiateWhenEmpty = true,
	///		LogMessages = LogLevel.Warning,
	///		MaximumSize = 50,
	///		NotificationMode = NotificationMode.Interface,
	///		RecordStatistics = true,
	///		ReparentPooledObjects = true
	///	});
	/// 
	/// // Acquire an instance of myPrefab from the manager. The Acquire method can be used safely if the myPrefab pool's InstantiateWhenEmpty property is true, or if a check is made to CanAcquire beforehand.
	/// GameObject instance = manager.Acquire(myPrefab);
	/// 
	/// // Acquire another myPrefab instance from the manager. TryAcquire can be used safely even when InstantiateWhenEmpty is false.
	/// GameObject secondInstance;
	/// if (manager.TryAcquire(myPrefab, out secondInstance)) {
	/// 	// Release the instance back to the manager.
	/// 	manager.Release(secondInstance);
	///	}
	/// 
	/// // Release the instance back to the manager.
	/// manager.Release(instance);
	/// </code>
	/// </example>
	public class GameObjectPoolManager : PoolManagerBase<GameObjectPoolManagerSettings, GameObjectPool, GameObjectPoolSettings, GameObject, GameObject> {

		// TODO: Have a list of pools that will be attached on Start? They could exist anywhere in the scene, not just under the manager.

		#region Fields.
		[SerializeField, HideInInspector]
		private GameObjectToPoolDictionary objectPools = new GameObjectToPoolDictionary();

		[SerializeField, HideInInspector]
		private GameObjectPoolManagerSettings settings = new GameObjectPoolManagerSettings {
			AcquireMode = AcquireNoPoolMode.Instantiate,
			IsPoolingEnabled = true,
			DontDestroyOnLoad = false,
			AttachDescendentPools = true,
			DefaultPoolSettings = new GameObjectPoolSettings {
				DontDestroyOnLoad = true,
				Enabled = true,
				InitialiseOnStart = true,
				InitialSize = 10,
				InstantiateWhenEmpty = true,
				LogMessages = LogLevel.Warning,
				MaximumSize = 50,
				NotificationMode = NotificationMode.Interface,
				RecordStatistics = true,
				ReparentPooledObjects = true
			}
		};
		#endregion

		#region Properties.
		/// <inheritdoc />
		protected override IDictionary<GameObject, GameObjectPool> ObjectPools => this.objectPools;

		/// <inheritdoc />
		internal override GameObjectPoolManagerSettings Settings {
			get => this.settings;
			set => this.settings = value;
		}
		#endregion

		#region Acquire(GameObject) methods.
		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire(GameObject, Transform, out GameObject)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public GameObject Acquire(GameObject sourceObject, Transform parent) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			// Acquire and set the parent.
			return this.Acquire(sourceObject, parent, false);
		}

		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire(GameObject, Transform, out GameObject)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public GameObject Acquire(GameObject sourceObject, Transform parent, bool spawnInWorldSpace) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			// Acquire and set the parent.
			return this.Acquire(sourceObject).Set(parent, spawnInWorldSpace);
		}
		
		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its position and rotation.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire(GameObject, Vector3, Quaternion, out GameObject)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public GameObject Acquire(GameObject sourceObject, Vector3 position, Quaternion rotation) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			// Acquire and set the position and rotation.
			return this.Acquire(sourceObject).Set(position, rotation);
		}

		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire(GameObject, Vector3, Quaternion, Transform, out GameObject)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public GameObject Acquire(GameObject sourceObject, Vector3 position, Quaternion rotation, Transform parent) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			// Acquire and set the parent, position and rotation.
			return this.Acquire(sourceObject).Set(parent, position, rotation);
		}
		#endregion

		#region TryAcquire(out GameObject) methods.
		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(GameObject, Transform)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire(GameObject sourceObject, Transform parent, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			return this.TryAcquire(sourceObject, parent, false, out instance);
		}

		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(GameObject, Transform)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire(GameObject sourceObject, Transform parent, bool spawnInWorldSpace, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			if (this.TryAcquire(sourceObject, out instance)) {
				instance.Set(parent, spawnInWorldSpace);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its position and rotation.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(GameObject, Vector3, Quaternion)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire(GameObject sourceObject, Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			if (this.TryAcquire(sourceObject, out instance)) {
				instance.Set(position, rotation);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Acquires an instance of <paramref name="sourceObject"/> from an attached pool, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="sourceObject">The game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(GameObject, Vector3, Quaternion, Transform)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire(GameObject sourceObject, Vector3 position, Quaternion rotation, Transform parent, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			if (this.TryAcquire(sourceObject, out instance)) {
				instance.Set(parent, position, rotation);
				return true;
			}

			return false;
		}
		#endregion

		#region ReleaseInternal(GameObject) method.
		/// <summary>
		/// Releases an instance of a game object that was previously acquired from an attached pool.
		/// </summary>
		/// <param name="instance">The instance to release back to its pool.</param>
		protected override void ReleaseInternal(GameObject instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			var poolable = instance.GetComponent<PoolableGameObject>();

			// If pooling is not enabled, destroy the object instead of releasing it to the pool.
			if (!this.Enabled) {
				// We expect the PoolableObject to be destroyed.
				if (poolable != null) {
					poolable.ExpectDestroy = true;
				}
				Object.Destroy(instance);
				return;
			}

			// Ensure the instance has its PoolableObject component on it, which is needed to know which pool it should be returned to.
			if (poolable == null) {
				DebugHelper.LogError($"Unable to release a game object ({instance.name}) to its pool without a {nameof(PoolableGameObject)} component on it. The object may not have originated from a pool. The object will be destroyed.");
				Object.Destroy(instance);
				return;
			}
			
			// Get the pool that handles this instance.
			GameObjectPool pool;
			if (!this.TryGetPool(poolable.SourceObject, out pool)) {
				DebugHelper.LogWarning($"Unable to release a game object ({instance.name}) to its pool. No pool exists for the object. The object will be destroyed.");
				Object.Destroy(instance);
				return;
			}

			pool.Release(instance);
		}
		#endregion

		#region CreatePool methods.
		/// <summary>
		/// Creates a <see cref="GameObjectPool"/> that pools instances of <paramref name="sourceObject"/>, and attaches it to the manager.
		/// The pool is created on a child object of the manager's game object.
		/// </summary>
		/// <param name="sourceObject">The <see cref="GameObject"/> to be pooled.</param>
		/// <returns>The newly-created <see cref="GameObjectPool"/>.</returns>
		public GameObjectPool CreatePool(GameObject sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.RequiresMessage(!this.HasPool(sourceObject), () => $"The pool could not be created, as the source object ('{sourceObject.name}') is already assigned to an existing pool.");

			// Create the pool on a child object of the manager's game object.
			return this.CreatePool(sourceObject, this.gameObject, true);
		}

		/// <summary>
		/// Creates a <see cref="GameObjectPool"/> that pools instances of <paramref name="sourceObject"/>, and attaches it to the manager.
		/// </summary>
		/// <param name="sourceObject">The <see cref="GameObject"/> to be pooled.</param>
		/// <param name="parent">The <see cref="GameObject"/> that the pool should be attached to, either directly or indirectly depending on <paramref name="createContainer"/>.</param>
		/// <param name="createContainer"><see langword="true"/> to create the pool on a child object parented to <paramref name="parent"/>; <see langword="false"/> to create the pool directly on <paramref name="parent"/>.</param>
		/// <returns>The newly-created <see cref="GameObjectPool"/>.</returns>
		public GameObjectPool CreatePool(GameObject sourceObject, GameObject parent, bool createContainer = false) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.RequiresMessage(!this.HasPool(sourceObject), () => $"The pool could not be created, as the source object ('{sourceObject.name}') is already assigned to an existing pool.");

			var settings = new GameObjectPoolSettings(this.DefaultPoolSettings) {
				Source = sourceObject
			};
			return this.CreatePool(settings, parent, createContainer);
		}
		#endregion

		#region PoolManagerBase overrides.
		/// <inheritdoc />
		protected override bool InternalAcquire(GameObject sourceObject, out GameObjectPool pool, out GameObject instance) {
			// As no pool exists for the source object, decide what to do next.
			switch (this.AcquireMode) {
				case AcquireNoPoolMode.Error:
					throw new ArgumentException("Unable to acquire an instance of an object, as no pool exists for it.", nameof(sourceObject));
				case AcquireNoPoolMode.Instantiate:
					// Instantiate a new instance of the object.
					instance = Object.Instantiate(sourceObject);
					pool = null;

					// Add the PoolableObject component, and let it know that the object is not expected to be returned to a pool.
					var poolable = instance.AddComponent<PoolableGameObject>();
					poolable.SourceObject = sourceObject;
					poolable.ExpectNoPool = true;
					poolable.IsInPool = false;
					poolable.NotificationMode = this.DefaultPoolSettings.NotificationMode;
					poolable.Initialised = true; // TODO: This could be set to false to allow SerialisableGameObjectPool to add the Destroyed event handler.

					return false;
				case AcquireNoPoolMode.CreatePool:
					var settings = new GameObjectPoolSettings(this.DefaultPoolSettings) {
						Source = sourceObject
					};

					// Ensure at least one instance can always be acquired immediately after initialising the pool.
					if (settings.InitialSize == 0 && !settings.InstantiateWhenEmpty) {
						settings.InstantiateWhenEmpty = true;
					}

					// Create and initialise the new pool.
					pool = this.CreatePool(settings);
					instance = null;
					return true;
				default:
					throw new NotImplementedException();
			}
		}

		/// <inheritdoc />
		protected override string GetSourceName(GameObject source) {
			return source.name;
		}
		#endregion

		#region GameObject menu item.
#if UNITY_EDITOR
		/// <summary>
		/// Adds a menu item to create custom GameObjects.
		/// </summary>
		/// <param name="menuCommand"></param>
		[MenuItem("GameObject/Pooling/GameObject Pool Manager", false, 10)] // Priority 10 ensures it is grouped with the other menu items of the same kind and propagated to the hierarchy dropdown and hierarchy context menus.
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void CreateCustomGameObject(MenuCommand menuCommand) {
			EditorHelper.CreateCustomGameObject<GameObjectPoolManager>("GameObject Pool Manager", menuCommand.context as GameObject);
		}
#endif
		#endregion

		#region Static access.
		private static GameObjectPoolManager instance;

		/// <summary>
		/// Gets the <see cref="GameObjectPoolManager"/> found in the scene.
		/// </summary>
		/// <remarks>
		/// <para>
		/// If more than one <see cref="GameObjectPoolManager"/> exists in the scene, the instance returned by this property is undefined.
		/// </para>
		/// <para>
		/// If no <see cref="GameObjectPoolManager"/> is found in the scene, a new root <see cref="GameObject"/> is
		/// created with the <see cref="GameObjectPoolManager"/> component attached.
		/// </para>
		/// </remarks>
		public static GameObjectPoolManager Instance {
			get {
				if (GameObjectPoolManager.instance != null) return GameObjectPoolManager.instance;

				// Look for the manager in the scene.
				GameObjectPoolManager.instance = Object.FindObjectOfType<GameObjectPoolManager>();
				if (GameObjectPoolManager.instance == null) {
					// Create a new manager.
					var container = new GameObject(nameof(GameObjectPoolManager));
					GameObjectPoolManager.instance = container.AddComponent<GameObjectPoolManager>();
				}

				return GameObjectPoolManager.instance;
			}
		}
		#endregion

	}

}