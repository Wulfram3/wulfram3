﻿using System.Collections.Generic;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Defines an interface for the pooling and recycling of objects.
	/// </summary>
	public interface IObjectPool {

		#region Properties.
		/// <summary>
		/// Gets or sets a value indicating whether the pool should instantiate a new object when the pool is empty, and an attempt is made to acquire from the pool.
		/// </summary>
		bool InstantiateWhenEmpty { get; set; }

		/// <summary>
		/// Gets or sets the maximum size of the pool, which is the maximum number of objects it can contain.
		/// </summary>
		/// <remarks>
		/// <para>The maximum size must be greater than, or equal to, zero. It cannot be a negative number.</para>
		/// <para>If an object is released to the pool while the pool is full, the object will be destroyed.</para>
		/// <para>
		/// If <see cref="MaximumSize"/> is set to a value lower than the current <see cref="Count"/>, the pool will be
		/// reduced in size by destroying excess objects.
		/// </para>
		/// </remarks>
		int MaximumSize { get; set; }

		/// <summary>
		/// Gets the number of objects currently contained by the pool.
		/// </summary>
		int Count { get; }
		#endregion

		#region Methods.
		/// <summary>
		/// Sets the number of objects contained by the pool, either destroying excess pooled objects, or instantiating new ones.
		/// </summary>
		/// <param name="poolSize">The target number of objects the pool should contain.</param>
		/// <seealso cref="Fill"/>
		/// <seealso cref="Clear"/>
		void SetSize(int poolSize);

		/// <summary>
		/// Fills the pool, populating it with pooled objects until it reaches the maximum pool size.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Clear"/>
		/// <seealso cref="MaximumSize"/>
		void Fill();

		/// <summary>
		/// Clears the pool, emptying it of all pooled objects.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Fill"/>
		void Clear();
		#endregion

	}

	/// <summary>
	/// Defines an interface for the pooling and recycling of objects of type <typeparamref name="T"/>.
	/// </summary>
	/// <typeparam name="T">The type of object being pooled.</typeparam>
	public interface IObjectPool<T> : IObjectPool {

		#region Properties.
		/// <summary>
		/// Gets a list of items currently contained by the pool.
		/// </summary>
		/// <remarks>
		/// <para>
		/// This property always creates a new <see cref="List{T}"/> each time the property getter is accessed.
		/// For performance reasons the value should be cached where possible, to avoid the costs of object instantiation and garbage collection.
		/// </para>
		/// <para>See the <see cref="GetItems"/> method for a way to avoid the allocation of a new <see cref="List{T}"/> object.</para>
		/// </remarks>
		/// <seealso cref="GetItems"/>
		IList<T> Items { get; }
		#endregion

		#region Methods.
		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <returns>An object from the pool.</returns>
		/// <seealso cref="TryAcquire"/>
		/// <seealso cref="Release"/>
		T Acquire();

		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <param name="instance">When this method returns, contains the object from the pool, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire"/>
		/// <seealso cref="Release"/>
		bool TryAcquire(out T instance);

		/// <summary>
		/// Releases an object back to the pool.
		/// </summary>
		/// <param name="instance">The object to release to the pool.</param>
		void Release(T instance);
		
		/// <summary>
		/// Gets a list of items currently contained by the pool, and stores them in the specified <see cref="List{T}"/>.
		/// </summary>
		/// <param name="list">The existing list in which the items should be stored.</param>
		/// <seealso cref="Items"/>
		void GetItems(List<T> list);
		#endregion

	}

}