﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// An interface that defines the settings that can be changed on a <see cref="Component"/> pool.
	/// </summary>
	public interface IComponentPoolSettings : ISharedPoolSettings<Type> {

		/// <summary>
		/// Gets a collection of additional component types that should exist on the pooled object.
		/// </summary>
		ComponentTypeCollection AdditionalComponentTypes { get; }

	}

}