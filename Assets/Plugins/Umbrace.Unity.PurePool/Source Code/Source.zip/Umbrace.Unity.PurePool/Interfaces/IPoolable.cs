using UnityEngine.EventSystems;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Defines an interface for objects that can be maintained by an object pool.
	/// </summary>
	public interface IPoolable : IEventSystemHandler {

		/// <summary>
		/// Reinitialises the object after being acquired from the pool.
		/// </summary>
		void Acquire();

		/// <summary>
		/// Frees any allocated resources, and stops any active processes, before the object returns to the pool.
		/// </summary>
		void Release();

	}

}