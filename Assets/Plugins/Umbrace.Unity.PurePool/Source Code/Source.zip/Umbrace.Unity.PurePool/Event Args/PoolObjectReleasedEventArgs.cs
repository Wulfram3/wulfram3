﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains data for object pooling events.
	/// </summary>
	/// <typeparam name="T">The type of the object that the event is about.</typeparam>
	[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
	public class PoolObjectReleasedEventArgs<T> : PoolObjectEventArgs<T> {

		// This object purposefully allows Instance to be changed, to allow the object to be pooled.
		
		/// <summary>
		/// Gets or sets a value indicating whether the released object is about to be destroyed.
		/// </summary>
		public bool Destroying { get; set; }

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolObjectReleasedEventArgs{T}"/> class.
		/// </summary>
		/// <param name="instance">The object that the event is about.</param>
		/// <param name="destroying">A value indicating whether the released object is about to be destroyed.</param>
		public PoolObjectReleasedEventArgs(T instance, bool destroying) : base(instance) {
			this.Destroying = destroying;
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolObjectReleasedEventArgs{T}"/> class.
		/// </summary>
		public PoolObjectReleasedEventArgs() {
			// Do nothing.
		}

		/// <inheritdoc />
		protected override void ReleaseInternal() {
			base.ReleaseInternal();

			// Reset the values.
			this.Destroying = false;
		}

	}

}