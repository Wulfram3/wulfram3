﻿using System;
using System.Collections.Generic;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A static class that provides pooling of <see cref="EventArgs"/> for use in events.
	/// </summary>
	internal static class EventArgsPool {

		private static readonly Dictionary<Type, object> Pools = new Dictionary<Type, object>();

		/// <summary>
		/// Gets the object pool for objects of type <typeparamref name="T"/>, or creates one if it doesn't exist.
		/// </summary>
		/// <typeparam name="T">The type of object to be pooled.</typeparam>
		/// <returns>An object pool for objects of type <typeparamref name="T"/>.</returns>
		internal static BasicObjectPool<T> GetPool<T>() where T : EventArgs {
			object poolObject;
			
			if (!EventArgsPool.Pools.TryGetValue(typeof(T), out poolObject)) {
				poolObject = new BasicObjectPool<T> {
					InstantiateWhenEmpty = true
				};
				EventArgsPool.Pools[typeof(T)] = poolObject;
			}

			return (BasicObjectPool<T>)poolObject;
		}

		/// <summary>
		/// Acquires an object of type <typeparamref name="T"/> from the pool.
		/// </summary>
		/// <typeparam name="T">The type of object to acquire.</typeparam>
		/// <returns>An object of type <typeparamref name="T"/> from the pool.</returns>
		/// <seealso cref="Release{T}"/>
		internal static T Acquire<T>() where T : EventArgs {
			var pool = EventArgsPool.GetPool<T>();
			
			var instance = pool.Acquire();

			var poolable = instance as IPoolable;
			poolable?.Acquire();

			return instance;
		}

		/// <summary>
		/// Releases an object of type <typeparamref name="T"/> back to the pool.
		/// </summary>
		/// <param name="instance">The object to release to the pool.</param>
		/// <typeparam name="T">The type of the object being released.</typeparam>
		internal static void Release<T>(T instance) where T : EventArgs {
			var pool = EventArgsPool.GetPool<T>();

			var poolable = instance as IPoolable;
			poolable?.Release();

			pool.Release(instance);
		}

	}

}