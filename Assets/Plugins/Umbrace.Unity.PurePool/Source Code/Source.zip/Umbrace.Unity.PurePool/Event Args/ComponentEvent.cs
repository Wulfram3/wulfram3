using System;

using UnityEngine;
using UnityEngine.Events;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Represents an event that has a single <see cref="Component"/> parameter.
	/// </summary>
	[Serializable]
	public class ComponentEvent : UnityEvent<Component> { }

}