﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains event data about the destruction of an object or component.
	/// </summary>
	[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
	public class DestroyedEventArgs : EventArgs, IPoolable {

		/// <summary>
		/// Gets or sets a value indicating whether the object or component was destroyed due to the application quitting.
		/// </summary>
		public bool ApplicationQuit { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether the destruction of the object or component was expected.
		/// </summary>
		/// <remarks>
		/// Destruction is most often expected when the object is being destroyed by the pool, because pooling has been disabled.
		/// The object is not released to the pool and not processed as if it is being released, but is simply destroyed instead.
		/// </remarks>
		public bool ExpectDestroy { get; set; }

		/// <summary>
		/// Initialises a new instance of the <see cref="DestroyedEventArgs"/> class.
		/// </summary>
		public DestroyedEventArgs() {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="DestroyedEventArgs"/> class.
		/// </summary>
		/// <param name="applicationQuit">A value indicating whether the object or component was destroyed due to the application quitting.</param>
		/// <param name="expectDestroy">A value indicating whether the destruction of the object or component was expected.</param>
		public DestroyedEventArgs(bool applicationQuit, bool expectDestroy) {
			this.ApplicationQuit = applicationQuit;
			this.ExpectDestroy = expectDestroy;
		}

		void IPoolable.Acquire() {
			// Do nothing.
		}

		void IPoolable.Release() {
			// Reset the values.
			this.ApplicationQuit = false;
			this.ExpectDestroy = false;
		}

	}

}