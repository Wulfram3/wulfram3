﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains data for object pooling events.
	/// </summary>
	[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
	public class PoolCountChangedEventArgs : EventArgs {

		// This object purposefully allows Count to be changed, to allow the object to be pooled.

		/// <summary>
		/// Gets or sets the number of objects currently contained by the pool.
		/// </summary>
		public int Count { get; set; }

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolCountChangedEventArgs"/> class.
		/// </summary>
		/// <param name="count">The number of objects currently contained by the pool.</param>
		public PoolCountChangedEventArgs(int count) {
			this.Count = count;
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolCountChangedEventArgs"/> class.
		/// </summary>
		public PoolCountChangedEventArgs() {
			// Do nothing.
		}

	}

}