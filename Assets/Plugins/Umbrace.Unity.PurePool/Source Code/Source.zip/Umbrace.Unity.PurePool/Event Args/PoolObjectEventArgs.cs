﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains data for object pooling events.
	/// </summary>
	/// <typeparam name="T">The type of the object that the event is about.</typeparam>
	[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
	public class PoolObjectEventArgs<T> : EventArgs, IPoolable {

		// This object purposefully allows Instance to be changed, to allow the object to be pooled.

		/// <summary>
		/// Gets or sets the object that the event refers to.
		/// </summary>
		public T Instance { get; set; }

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolObjectEventArgs{T}"/> class.
		/// </summary>
		/// <param name="instance">The object that the event is about.</param>
		public PoolObjectEventArgs(T instance) {
			this.Instance = instance;
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolObjectEventArgs{T}"/> class.
		/// </summary>
		public PoolObjectEventArgs() {
			// Do nothing.
		}

		/// <summary>
		/// When implemented in a derived class, performs actions when the object is acquired from an object pool.
		/// </summary>
		protected virtual void AcquireInternal() {
			// Do nothing.
		}

		/// <summary>
		/// Performs actions when the object is released back to an object pool.
		/// </summary>
		protected virtual void ReleaseInternal() {
			// Reset the values.
			this.Instance = default(T);
		}

		void IPoolable.Acquire() {
			this.AcquireInternal();
		}

		void IPoolable.Release() {
			this.ReleaseInternal();
		}

	}

}