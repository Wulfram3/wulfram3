using System;

using UnityEngine;
using UnityEngine.Events;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Represents an event that has a single <see cref="GameObject"/> parameter.
	/// </summary>
	[Serializable]
	public class GameObjectEvent : UnityEvent<GameObject> { }

}