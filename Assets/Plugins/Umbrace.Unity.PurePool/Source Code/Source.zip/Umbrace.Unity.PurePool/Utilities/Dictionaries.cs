﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	[Serializable]
	internal class GameObjectToPoolDictionary : SerialisableDictionary<GameObject, GameObjectPool> {

	}

	[Serializable]
	internal class GameObjectToPoolableObjectDictionary : SerialisableDictionary<GameObject, PoolableGameObject> {

	}

	[Serializable]
	internal class TypeToPoolDictionary : SerialisableDictionary<Type, ComponentPool> {

	}

	[Serializable]
	internal class ComponentToPoolableComponentDictionary : SerialisableDictionary<Component, PoolableComponent> {

	}

	[Serializable]
	internal class StringToGameObjectDictionary : SerialisableDictionary<string, GameObject> {

	}

}