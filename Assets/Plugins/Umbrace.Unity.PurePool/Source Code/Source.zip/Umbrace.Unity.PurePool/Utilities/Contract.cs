﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

using Umbrace.Unity.PurePool;

namespace Umbrace.Unity.Contracts {

	/// <summary>
	/// Contains static methods for representing program contracts such as preconditions.
	/// </summary>
	public static class Contract {

		#region Assert methods.
		//[Conditional("CONTRACTS_ASSERT")]
		//[Conditional("CONTRACTS_FULL")]
		//public static void Assert(bool condition, [CallerMemberName] string memberName = null) {
		//	Contract.AssertMessage(condition, null, memberName, filePath, lineNumber);
		//}

		//[Conditional("CONTRACTS_ASSERT")]
		//[Conditional("CONTRACTS_FULL")]
		//public static void AssertMessage(bool condition, string message, [CallerMemberName] string memberName = null) {
		//	DebugHelper.AssertMessage(condition, message, memberName, filePath, lineNumber);
		//}
		#endregion
		
		#region Requires methods.
		/// <summary>
		/// Specifies a precondition contract for the enclosing method or property.
		/// </summary>
		/// <param name="condition">The conditional expression to test.</param>
		/// <param name="memberName"></param>
		[Conditional("CONTRACTS_REQUIRES")]
		[Conditional("CONTRACTS_FULL")]
		public static void Requires(bool condition, [CallerMemberName] string memberName = null) {
			Contract.RequiresMessage(condition, (string)null, memberName);
		}

		/// <summary>
		/// Specifies a precondition contract for the enclosing method or property, and displays a message if the condition for the contract fails.
		/// </summary>
		/// <param name="condition">The conditional expression to test.</param>
		/// <param name="message">The message to display if the condition is <see langword="false"/>.</param>
		/// <param name="memberName"></param>
		[Conditional("CONTRACTS_REQUIRES")]
		[Conditional("CONTRACTS_FULL")]
		public static void RequiresMessage(bool condition, string message, [CallerMemberName] string memberName = null) {
			if (!condition) {
				if (Debugger.IsAttached) {
					Debugger.Break();
				}

				if (string.IsNullOrEmpty(message)) {
					throw new ContractException($"Requires failed in {memberName}.");
				} else {
					throw new ContractException($"{message}{Environment.NewLine}" +
												$"Requires failed in {memberName}.");
				}
			}
		}

		/// <summary>
		/// Specifies a precondition contract for the enclosing method or property, and displays a message if the condition for the contract fails.
		/// </summary>
		/// <param name="condition">The conditional expression to test.</param>
		/// <param name="messageBuilder">A function that returns the message to display if the condition is <see langword="false"/>.</param>
		/// <param name="memberName"></param>
		/// <remarks>
		/// This method allows string formatting and concatenation to be performed after it is known whether the message will be displayed.
		/// This avoids generating unnecessary allocations, and therefore also avoids the associated increase in garbage collector pressure.
		/// </remarks>
		[Conditional("CONTRACTS_REQUIRES")]
		[Conditional("CONTRACTS_FULL")]
		public static void RequiresMessage(bool condition, Func<string> messageBuilder, [CallerMemberName] string memberName = null) {
			if (!condition) {
				string message = messageBuilder();
				Contract.RequiresMessage(condition, message, memberName);
			}
		}

		/// <summary>
		/// Specifies a precondition contract for the enclosing method or property, and displays a message if the condition for the contract fails.
		/// </summary>
		/// <param name="condition">The conditional expression to test.</param>
		/// <param name="messageBuilder">A function that returns the message to display if the condition is <see langword="false"/>.</param>
		/// <param name="arg1">The first argument to be passed to <paramref name="messageBuilder"/>.</param>
		/// <param name="memberName"></param>
		/// <remarks>
		/// This method allows string formatting and concatenation to be performed after it is known whether the message will be displayed.
		/// This avoids generating unnecessary allocations, and therefore also avoids the associated increase in garbage collector pressure.
		/// </remarks>
		[Conditional("CONTRACTS_REQUIRES")]
		[Conditional("CONTRACTS_FULL")]
		public static void RequiresMessage(bool condition, Func<string, string> messageBuilder, string arg1, [CallerMemberName] string memberName = null) {
			if (!condition) {
				string message = messageBuilder(arg1);
				Contract.RequiresMessage(condition, message, memberName);
			}
		}

		/// <summary>
		/// Specifies a precondition contract for the enclosing method or property, and displays a message if the condition for the contract fails.
		/// </summary>
		/// <param name="condition">The conditional expression to test.</param>
		/// <param name="messageBuilder">A function that returns the message to display if the condition is <see langword="false"/>.</param>
		/// <param name="arg1">The first argument to be passed to <paramref name="messageBuilder"/>.</param>
		/// <param name="arg2">The second argument to be passed to <paramref name="messageBuilder"/>.</param>
		/// <param name="memberName"></param>
		/// <remarks>
		/// This method allows string formatting and concatenation to be performed after it is known whether the message will be displayed.
		/// This avoids generating unnecessary allocations, and therefore also avoids the associated increase in garbage collector pressure.
		/// </remarks>
		[Conditional("CONTRACTS_REQUIRES")]
		[Conditional("CONTRACTS_FULL")]
		public static void RequiresMessage(bool condition, Func<string, string, string> messageBuilder, string arg1, string arg2, [CallerMemberName] string memberName = null) {
			if (!condition) {
				string message = messageBuilder(arg1, arg2);
				Contract.RequiresMessage(condition, message, memberName);
			}
		}
		#endregion

		#region RequiresNotNull methods.
		/// <summary>
		/// Specifies a non-null precondition contract for the enclosing method or property.
		/// </summary>
		/// <typeparam name="T">The type of the object to test.</typeparam>
		/// <param name="obj">The object to test for null.</param>
		/// <param name="objectName">The name of the object. Use the <see langword="nameof"/> operator.</param>
		/// <param name="memberName"></param>
		[Conditional("CONTRACTS_REQUIRES")]
		[Conditional("CONTRACTS_FULL")]
		public static void RequiresNotNull<T>(T obj, string objectName, [CallerMemberName] string memberName = null) {
			Contract.RequiresMessage(obj != null, _objectName => $"{_objectName} cannot be null.", objectName, memberName);
		}
		#endregion

		#region Requires<TException> methods.
		/// <summary>
		/// Specifies a precondition contract for the enclosing method or property, and throws an exception with the provided message if the condition for the contract fails.
		/// </summary>
		/// <typeparam name="TException">The exception to throw if the condition is <see langword="false"/>.</typeparam>
		/// <param name="condition">The conditional expression to test.</param>
		/// <param name="message">The message to display if the condition is <see langword="false"/>.</param>
		/// <param name="memberName"></param>
		[Conditional("CONTRACTS_REQUIRES_E")]
		[Conditional("CONTRACTS_FULL")]
		public static void Requires<TException>(bool condition, string message, [CallerMemberName] string memberName = null) where TException : Exception, new() {
			if (!condition) {
				if (Debugger.IsAttached) {
					Debugger.Break();
				}

				DebugHelper.LogError($"{message}{Environment.NewLine}" +
									 $"Requires failed in {memberName}.");
				throw new TException();
			}
		}
		#endregion

	}

}