﻿using System;
using System.Diagnostics;

using Debug = UnityEngine.Debug;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A static class that provides logging methods that write to the Unity console.
	/// </summary>
	public static class DebugHelper {
		
		#region Fields.
		private static bool isLoggingEnabled = true;
		private static bool isInformationLoggingEnabled = true;
		private static bool isWarningLoggingEnabled = true;
		private static bool isErrorLoggingEnabled = true;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets or sets a value indicating whether logging to the Unity console is enabled.
		/// </summary>
		public static bool IsLoggingEnabled {
			get { return DebugHelper.isLoggingEnabled; }
			set { DebugHelper.isLoggingEnabled = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether logging of <see cref="LogLevel.Information"/> messages to the Unity console is enabled.
		/// </summary>
		public static bool IsInformationLoggingEnabled {
			get { return DebugHelper.isInformationLoggingEnabled; }
			set { DebugHelper.isInformationLoggingEnabled = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether logging of <see cref="LogLevel.Warning"/> messages to the Unity console is enabled.
		/// </summary>
		public static bool IsWarningLoggingEnabled {
			get { return DebugHelper.isWarningLoggingEnabled; }
			set { DebugHelper.isWarningLoggingEnabled = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether logging of <see cref="LogLevel.Error"/> messages to the Unity console is enabled.
		/// </summary>
		public static bool IsErrorLoggingEnabled {
			get { return DebugHelper.isErrorLoggingEnabled; }
			set { DebugHelper.isErrorLoggingEnabled = value; }
		}
		#endregion

		#region Log, LogWarning, LogError methods.
		/// <summary>
		/// Logs the specified informational message to the Unity console.
		/// </summary>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void Log(string message) {
			if (DebugHelper.IsLoggingEnabled && DebugHelper.IsInformationLoggingEnabled) Debug.Log(message);
		}

		/// <summary>
		/// Logs the specified informational message to the Unity console.
		/// </summary>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void Log(string message, UnityEngine.Object context) {
			if (DebugHelper.IsLoggingEnabled && DebugHelper.IsInformationLoggingEnabled) Debug.Log(message, context);
		}

		/// <summary>
		/// Logs the specified warning message to the Unity console.
		/// </summary>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogWarning(string message) {
			if (DebugHelper.IsLoggingEnabled && DebugHelper.IsWarningLoggingEnabled) Debug.LogWarning(message);
		}

		/// <summary>
		/// Logs the specified warning message to the Unity console.
		/// </summary>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogWarning(string message, UnityEngine.Object context) {
			if (DebugHelper.IsLoggingEnabled && DebugHelper.IsWarningLoggingEnabled) Debug.LogWarning(message, context);
		}

		/// <summary>
		/// Logs the specified error message to the Unity console.
		/// </summary>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogError(string message) {
			if (DebugHelper.IsLoggingEnabled && DebugHelper.IsErrorLoggingEnabled) Debug.LogError(message);
		}

		/// <summary>
		/// Logs the specified error message to the Unity console.
		/// </summary>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogError(string message, UnityEngine.Object context) {
			if (DebugHelper.IsLoggingEnabled && DebugHelper.IsErrorLoggingEnabled) Debug.LogError(message, context);
		}
		#endregion

		#region Log, LogWarning, LogError methods (LogLevel).
		/// <summary>
		/// Logs the specified informational message to the Unity console, if allowed by <paramref name="logLevel"/>.
		/// </summary>
		/// <param name="logLevel">The maximum level of log messaging that is allowed.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void Log(LogLevel logLevel, string message) {
			bool log = logLevel != LogLevel.Off && logLevel <= LogLevel.Information;
			DebugHelper.LogIf(log, message);
		}

		/// <summary>
		/// Logs the specified informational message to the Unity console, if allowed by <paramref name="logLevel"/>.
		/// </summary>
		/// <param name="logLevel">The maximum level of log messaging that is allowed.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void Log(LogLevel logLevel, string message, UnityEngine.Object context) {
			bool log = logLevel != LogLevel.Off && logLevel <= LogLevel.Information;
			DebugHelper.LogIf(log, message, context);
		}

		/// <summary>
		/// Logs the specified warning message to the Unity console, if allowed by <paramref name="logLevel"/>.
		/// </summary>
		/// <param name="logLevel">The maximum level of log messaging that is allowed.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogWarning(LogLevel logLevel, string message) {
			bool log = logLevel != LogLevel.Off && logLevel <= LogLevel.Warning;
			DebugHelper.LogWarningIf(log, message);
		}

		/// <summary>
		/// Logs the specified warning message to the Unity console, if allowed by <paramref name="logLevel"/>.
		/// </summary>
		/// <param name="logLevel">The maximum level of log messaging that is allowed.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogWarning(LogLevel logLevel, string message, UnityEngine.Object context) {
			bool log = logLevel != LogLevel.Off && logLevel <= LogLevel.Warning;
			DebugHelper.LogWarningIf(log, message, context);
		}

		/// <summary>
		/// Logs the specified error message to the Unity console, if allowed by <paramref name="logLevel"/>.
		/// </summary>
		/// <param name="logLevel">The maximum level of log messaging that is allowed.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogError(LogLevel logLevel, string message) {
			bool log = logLevel != LogLevel.Off && logLevel <= LogLevel.Error;
			DebugHelper.LogErrorIf(log, message);
		}

		/// <summary>
		/// Logs the specified error message to the Unity console, if allowed by <paramref name="logLevel"/>.
		/// </summary>
		/// <param name="logLevel">The maximum level of log messaging that is allowed.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogError(LogLevel logLevel, string message, UnityEngine.Object context) {
			bool log = logLevel != LogLevel.Off && logLevel <= LogLevel.Error;
			DebugHelper.LogErrorIf(log, message, context);
		}
		#endregion

		#region LogIf, LogWarningIf, LogErrorIf methods (bool).
		/// <summary>
		/// Logs the specified informational message to the Unity console, if the condition is <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogIf(bool condition, string message) {
			if (condition) DebugHelper.Log(message);
		}

		/// <summary>
		/// Logs the specified informational message to the Unity console, if the condition is <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogIf(bool condition, string message, UnityEngine.Object context) {
			if (condition) DebugHelper.Log(message, context);
		}

		/// <summary>
		/// Logs the specified warning message to the Unity console, if the condition is <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogWarningIf(bool condition, string message) {
			if (condition) DebugHelper.LogWarning(message);
		}

		/// <summary>
		/// Logs the specified warning message to the Unity console, if the condition is <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogWarningIf(bool condition, string message, UnityEngine.Object context) {
			if (condition) DebugHelper.LogWarning(message, context);
		}

		/// <summary>
		/// Logs the specified error message to the Unity console, if the condition is <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogErrorIf(bool condition, string message) {
			if (condition) DebugHelper.LogError(message);
		}

		/// <summary>
		/// Logs the specified error message to the Unity console, if the condition is <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogErrorIf(bool condition, string message, UnityEngine.Object context) {
			if (condition) DebugHelper.LogError(message, context);
		}
		#endregion

		#region LogIf, LogWarningIf, LogErrorIf methods (Func<bool>).
		/// <summary>
		/// Logs the specified informational message to the Unity console, if the condition evaluates to <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogIf(Func<bool> condition, string message) {
			if (condition.Invoke()) DebugHelper.Log(message);
		}

		/// <summary>
		/// Logs the specified informational message to the Unity console, if the condition evaluates to <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogIf(Func<bool> condition, string message, UnityEngine.Object context) {
			if (condition.Invoke()) DebugHelper.Log(message, context);
		}

		/// <summary>
		/// Logs the specified warning message to the Unity console, if the condition evaluates to <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogWarningIf(Func<bool> condition, string message) {
			if (condition.Invoke()) DebugHelper.LogWarning(message);
		}

		/// <summary>
		/// Logs the specified warning message to the Unity console, if the condition evaluates to <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogWarningIf(Func<bool> condition, string message, UnityEngine.Object context) {
			if (condition.Invoke()) DebugHelper.LogWarning(message, context);
		}

		/// <summary>
		/// Logs the specified error message to the Unity console, if the condition evaluates to <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogErrorIf(Func<bool> condition, string message) {
			if (condition.Invoke()) DebugHelper.LogError(message);
		}

		/// <summary>
		/// Logs the specified error message to the Unity console, if the condition evaluates to <see langword="true"/>.
		/// </summary>
		/// <param name="condition">The condition to check.</param>
		/// <param name="message">The message to log.</param>
		/// <param name="context">The object to which the message applies.</param>
		[Conditional("LOG_MESSAGING")]
		public static void LogErrorIf(Func<bool> condition, string message, UnityEngine.Object context) {
			if (condition.Invoke()) DebugHelper.LogError(message, context);
		}
		#endregion

	}

}
