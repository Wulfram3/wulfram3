﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Represents a single captured instant in time.
	/// </summary>
	[Serializable]
	public struct TimeInstant {

		[SerializeField, HideInInspector]
		private int frameCount;
		[SerializeField, HideInInspector]
		private float realtimeSinceStartup;
		[SerializeField, HideInInspector]
		private float time;
		[SerializeField, HideInInspector]
		private float unscaledTime;

		/// <summary>
		/// Gets the value of <see cref="UnityEngine.Time.frameCount"/> as of the captured instant in time.
		/// </summary>
		public int FrameCount => this.frameCount;

		/// <summary>
		/// Gets the value of <see cref="UnityEngine.Time.realtimeSinceStartup"/> as of the captured instant in time.
		/// </summary>
		public float RealtimeSinceStartup => this.realtimeSinceStartup;

		/// <summary>
		/// Gets the value of <see cref="UnityEngine.Time.time"/> as of the captured instant in time.
		/// </summary>
		public float Time => this.time;

		/// <summary>
		/// Gets the value of <see cref="UnityEngine.Time.unscaledTime"/> as of the captured instant in time.
		/// </summary>
		public float UnscaledTime => this.unscaledTime;

		/// <summary>
		/// Initialises a new instance of the <see cref="TimeInstant"/> struct.
		/// </summary>
		/// <param name="frameCount">The total number of frames that have passed.</param>
		/// <param name="realtimeSinceStartup">The real time in seconds since the game started.</param>
		/// <param name="time">The time at the beginning of the frame.</param>
		/// <param name="unscaledTime">The time-scale independent time at the beginning of the frame.</param>
		public TimeInstant(int frameCount, float realtimeSinceStartup, float time, float unscaledTime) {
			this.frameCount = frameCount;
			this.realtimeSinceStartup = realtimeSinceStartup;
			this.time = time;
			this.unscaledTime = unscaledTime;
		}

	}

}