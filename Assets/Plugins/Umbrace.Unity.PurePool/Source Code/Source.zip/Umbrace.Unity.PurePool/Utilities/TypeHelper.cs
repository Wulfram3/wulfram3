﻿using System;
using System.Collections.Generic;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A static class that provides utility methods for working with <see cref="Component"/> types.
	/// </summary>
	public static class TypeHelper {

		/// <summary>
		/// Finds all types within the current <see cref="AppDomain"/> that can be added to a <see cref="GameObject"/> as a component.
		/// </summary>
		/// <param name="allowEmptyComponentMenu">
		/// Whether to include component types if the <see cref="AddComponentMenu"/> attribute specifies an empty
		/// component menu name, meaning the component won't show up in the Add Component menu.
		/// </param>
		/// <returns>An <see cref="IEnumerable{T}"/> of all types that can be added as a component.</returns>
		public static IEnumerable<Type> FindComponentTypes(bool allowEmptyComponentMenu = true) {
			IEnumerable<Type> types = AppDomain.CurrentDomain.GetAssemblies().SelectMany(assembly => assembly.GetTypes());

			return types.Where(type => type.CanAddAsComponent(allowEmptyComponentMenu)).OrderBy(type => type.Name);
		}
		
		/// <summary>
		/// Gets a value indicating whether the specified <see cref="Type"/> can be added to a <see cref="GameObject"/> as a component.
		/// </summary>
		/// <param name="type">The type to check.</param>
		/// <param name="allowEmptyComponentMenu">
		/// Whether to allow the component type if its <see cref="AddComponentMenu"/> attribute specifies an empty
		/// component menu name, meaning the component won't show up in the Add Component menu.
		/// </param>
		/// <returns><see langword="true"/> if the specified type can be added to a <see cref="GameObject"/> as a component; otherwise, <see langword="false"/>.</returns>
		public static bool CanAddAsComponent(this Type type, bool allowEmptyComponentMenu = true) {
			Contract.RequiresNotNull(type, nameof(type));

			if (!type.IsSubclassOf(typeof(Component))) return false;
			if (type == typeof(MonoBehaviour)) return false;
			if (type == typeof(Behaviour)) return false;
			if (type == typeof(Transform)) return false;
			if (type.IsAbstract || type.IsGenericType) return false;
			if (!allowEmptyComponentMenu && type.GetCustomAttributes(typeof(AddComponentMenu), true).Cast<AddComponentMenu>().Any(attr => string.IsNullOrEmpty(attr.componentMenu))) return false;

			return true;
		}

		/// <summary>
		/// Gets a value indicating whether the specified component <see cref="Type"/> can be added multiple times to a <see cref="GameObject"/>.
		/// </summary>
		/// <param name="componentType"></param>
		/// <returns><see langword="true"/> if the specified component type can be added multiple times; otherwise, <see langword="false"/>.</returns>
		public static bool DisallowMultiple(this Type componentType) {
			Contract.RequiresNotNull(componentType, nameof(componentType));
			Contract.RequiresMessage(componentType.CanAddAsComponent(), () => $"{nameof(componentType)} must be a type that can be attached to a {nameof(GameObject)} as a component.");

			return componentType.GetCustomAttributes(typeof(DisallowMultipleComponent), true).Any();
		}

		/// <summary>
		/// Gets the components that implement <see cref="IPoolable"/> for the specified <paramref name="componentType"/>.
		/// </summary>
		/// <param name="componentType">The type whose <see cref="IPoolable"/> components should be found.</param>
		/// <returns>A collection of component types that implement <see cref="IPoolable"/>, and require a <paramref name="componentType"/> component.</returns>
		public static IEnumerable<Type> FindPoolableComponents(Type componentType) {
			var poolableTypes = TypeHelper.FindComponentTypes().Where(type => typeof(IPoolable).IsAssignableFrom(type));
			return poolableTypes.Where(type =>
				type.GetCustomAttributes(typeof(RequireComponent), true).Cast<RequireComponent>().Any(c =>
				c.m_Type0 == componentType || c.m_Type1 == componentType || c.m_Type2 == componentType));
		}

	}

}