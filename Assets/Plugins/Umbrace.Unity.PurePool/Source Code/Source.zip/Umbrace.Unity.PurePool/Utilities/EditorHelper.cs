﻿#if UNITY_EDITOR
using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	internal static class EditorHelper {

		/// <summary>
		/// Creates a new <see cref="GameObject"/> with a component added to it, with the specified name, and parented and aligned to the specified parent.
		/// </summary>
		/// <typeparam name="T">The type of component to add to the new <see cref="GameObject"/>.</typeparam>
		/// <param name="name">The name of the <see cref="GameObject"/>.</param>
		/// <param name="parent">The parent <see cref="GameObject"/>.</param>
		/// <remarks>
		/// This method is useful when using a <see cref="MenuItem"/> attribute to add an item to the GameObject menu.
		/// Internally, <see cref="GameObjectUtility.SetParentAndAlign"/> is used to ensure the object is re-parented
		/// if the menu action was from a context click.
		/// </remarks>
		internal static void CreateCustomGameObject<T>(string name, GameObject parent) where T : Component {
			// Create a custom game object.
			GameObject go = new GameObject(name);
			go.AddComponent<T>();

			// Ensure it gets re-parented if this was a context click (otherwise does nothing).
			GameObjectUtility.SetParentAndAlign(go, parent);

			// Register the creation in the undo system.
			Undo.RegisterCreatedObjectUndo(go, "Create " + name);
			Selection.activeObject = go;
		}

	}

}
#endif