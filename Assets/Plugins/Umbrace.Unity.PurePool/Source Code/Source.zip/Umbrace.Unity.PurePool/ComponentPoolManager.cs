﻿using System;
using System.Collections.Generic;

using Umbrace.Unity.Contracts;
#if UNITY_EDITOR
using System.Diagnostics.CodeAnalysis;
using UnityEditor;
#endif

using UnityEngine;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Manages a collection of <see cref="ComponentPool"/> components, simplifying access to the pools and allowing for automatic pool creation.
	/// </summary>
	/// <example>
	/// <code language="cs">
	/// // Create the manager as a component on a game object.
	/// var manager = gameObject.AddComponent&lt;ComponentPoolManager&gt;();
	/// 
	/// // Set up the manager's properties.
	/// manager.DontDestroyOnLoad = true;
	/// manager.AttachDescendentPools = true;
	/// manager.AcquireMode = AcquireNoPoolMode.CreatePool;
	/// 
	/// // Attach an existing pool to the manager.
	/// manager.AttachPool(pool);
	/// 
	/// // Create a pool that is attached to the manager.
	/// manager.CreatePool(new ComponentPoolSettings {
	///		Source = typeof(AudioSource),
	///		DontDestroyOnLoad = true,
	///		Enabled = true,
	///		InitialiseOnStart = true,
	///		InitialSize = 10,
	///		InstantiateWhenEmpty = true,
	///		LogMessages = LogLevel.Warning,
	///		MaximumSize = 50,
	///		NotificationMode = NotificationMode.Interface,
	///		RecordStatistics = true,
	///		ReparentPooledObjects = true
	///	});
	/// 
	/// // Acquire an AudioSource instance from the manager. The Acquire method can be used safely if the AudioSource pool's InstantiateWhenEmpty property is true, or if a check is made to CanAcquire beforehand.
	/// AudioSource instance = manager.Acquire&lt;AudioSource&gt;();
	/// 
	/// // Acquire another AudioSource instance from the manager. TryAcquire can be used safely even when InstantiateWhenEmpty is false.
	/// AudioSource secondInstance;
	/// if (manager.TryAcquire(out secondInstance)) {
	/// 	// Release the component back to the manager.
	/// 	manager.Release(secondInstance);
	///	}
	/// 
	/// // Release the component back to the manager.
	/// manager.Release(instance);
	/// </code>
	/// </example>
	public class ComponentPoolManager : PoolManagerBase<ComponentPoolManagerSettings, ComponentPool, ComponentPoolSettings, Type, Component> {

		// TODO: Have a list of pools that will be attached on Start? They could exist anywhere in the scene, not just under the manager.

		#region Fields.
		[SerializeField, HideInInspector]
		private TypeToPoolDictionary objectPools = new TypeToPoolDictionary();

		[SerializeField, HideInInspector]
		private ComponentPoolManagerSettings settings = new ComponentPoolManagerSettings {
			AcquireMode = AcquireNoPoolMode.Instantiate,
			IsPoolingEnabled = true,
			DontDestroyOnLoad = false,
			AttachDescendentPools = true,
			DefaultPoolSettings = new ComponentPoolSettings {
				DontDestroyOnLoad = true,
				Enabled = true,
				InitialiseOnStart = true,
				InitialSize = 10,
				InstantiateWhenEmpty = true,
				LogMessages = LogLevel.Warning,
				MaximumSize = 50,
				NotificationMode = NotificationMode.Interface,
				RecordStatistics = true,
				ReparentPooledObjects = true
			}
		};
		#endregion

		#region Properties.
		/// <inheritdoc />
		protected override IDictionary<Type, ComponentPool> ObjectPools => this.objectPools;

		/// <inheritdoc />
		internal override ComponentPoolManagerSettings Settings {
			get => this.settings;
			set => this.settings = value;
		}
		#endregion

		#region Acquire(Component) methods.
		/// <summary>
		/// Acquires an instance of <paramref name="componentType"/> from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="componentType">The type of component to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of <paramref name="componentType"/> acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Type, Transform, out Component)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public Component Acquire(Type componentType, Transform parent) {
			Contract.RequiresNotNull(componentType, nameof(componentType));
			Contract.Requires(this.CanAcquire(componentType));

			// Acquire and set the parent.
			var instance = this.Acquire(componentType);
			instance.gameObject.Set(parent, false);
			return instance;
		}

		/// <summary>
		/// Acquires an instance of <paramref name="componentType"/> from an attached pool, and sets its position and rotation.
		/// </summary>
		/// <param name="componentType">The type of component to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <returns>An instance of <paramref name="componentType"/> acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Type, Vector3, Quaternion, out Component)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public Component Acquire(Type componentType, Vector3 position, Quaternion rotation) {
			Contract.RequiresNotNull(componentType, nameof(componentType));
			Contract.Requires(this.CanAcquire(componentType));

			// Acquire and set the position and rotation.
			var instance = this.Acquire(componentType);
			instance.gameObject.Set(position, rotation);
			return instance;
		}

		/// <summary>
		/// Acquires an instance of <paramref name="componentType"/> from an attached pool, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="componentType">The type of component to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <returns>An instance of <paramref name="componentType"/> acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Type, Transform, Vector3, Quaternion, out Component)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public Component Acquire(Type componentType, Transform parent, Vector3 position, Quaternion rotation) {
			Contract.RequiresNotNull(componentType, nameof(componentType));
			Contract.Requires(this.CanAcquire(componentType));

			// Acquire and set the parent, position and rotation.
			var instance = this.Acquire(componentType);
			instance.gameObject.Set(parent, position, rotation);
			return instance;
		}
		#endregion

		#region Acquire<T> methods.
		/// <summary>
		/// Acquires an instance of the component <typeparamref name="T"/> from an attached pool.
		/// </summary>
		/// <typeparam name="T">The type of component to acquire an instance of.</typeparam>
		/// <returns>An instance of the component <typeparamref name="T"/> that was acquired from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(out T)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public T Acquire<T>() where T : Component {
			Contract.RequiresMessage(this.CanAcquire(typeof(T)), () => $"Unable to acquire an instance of component type '{typeof(T).Name}' from the manager. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return (T)this.Acquire(typeof(T));
		}

		/// <summary>
		/// Acquires an instance of the component <typeparamref name="T"/> from an attached pool, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <typeparam name="T">The type of component to acquire an instance of.</typeparam>
		/// <returns>An instance of the component <typeparamref name="T"/> that was acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Transform,out T)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public T Acquire<T>(Transform parent) where T : Component {
			Contract.RequiresMessage(this.CanAcquire(typeof(T)), () => $"Unable to acquire an instance of component type '{typeof(T).Name}' from the manager. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			// Acquire and set the parent.
			return (T)this.Acquire(typeof(T), parent);
		}

		/// <summary>
		/// Acquires an instance of the component <typeparamref name="T"/> from an attached pool, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <typeparam name="T">The type of component to acquire an instance of.</typeparam>
		/// <returns>An instance of the component <typeparamref name="T"/> that was acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Vector3,Quaternion,out T)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public T Acquire<T>(Vector3 position, Quaternion rotation) where T : Component {
			Contract.RequiresMessage(this.CanAcquire(typeof(T)), () => $"Unable to acquire an instance of component type '{typeof(T).Name}' from the manager. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			// Acquire and set the position and rotation.
			return (T)this.Acquire(typeof(T), position, rotation);
		}

		/// <summary>
		/// Acquires an instance of the component <typeparamref name="T"/> from an attached pool, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <typeparam name="T">The type of component to acquire an instance of.</typeparam>
		/// <returns>An instance of the component <typeparamref name="T"/> that was acquired from the pool.</returns>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Transform,Vector3,Quaternion,out T)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public T Acquire<T>(Transform parent, Vector3 position, Quaternion rotation) where T : Component {
			Contract.RequiresMessage(this.CanAcquire(typeof(T)), () => $"Unable to acquire an instance of component type '{typeof(T).Name}' from the manager. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			// Acquire and set the parent, position and rotation.
			return (T)this.Acquire(typeof(T), parent, position, rotation);
		}
		#endregion

		#region TryAcquire(out Component) methods.
		/// <summary>
		/// Acquires an instance of <paramref name="componentType"/> from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="componentType">The type of component to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="componentType"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="componentType"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Type, Transform)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire(Type componentType, Transform parent, out Component instance) {
			Contract.RequiresNotNull(componentType, nameof(componentType));

			if (this.TryAcquire(componentType, out instance)) {
				instance.gameObject.Set(parent, false);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Acquires an instance of <paramref name="componentType"/> from an attached pool, and sets its position and rotation.
		/// </summary>
		/// <param name="componentType">The type of component to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="componentType"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="componentType"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Type, Vector3, Quaternion)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire(Type componentType, Vector3 position, Quaternion rotation, out Component instance) {
			Contract.RequiresNotNull(componentType, nameof(componentType));

			if (this.TryAcquire(componentType, out instance)) {
				instance.gameObject.Set(position, rotation);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Acquires an instance of <paramref name="componentType"/> from an attached pool, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="componentType">The type of component to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="componentType"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="componentType"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Type, Transform, Vector3, Quaternion)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire(Type componentType, Transform parent, Vector3 position, Quaternion rotation, out Component instance) {
			Contract.RequiresNotNull(componentType, nameof(componentType));

			if (this.TryAcquire(componentType, out instance)) {
				instance.gameObject.Set(parent, position, rotation);
				return true;
			}

			return false;
		}
		#endregion

		#region TryAcquire<T> methods.
		/// <summary>
		/// Acquires an instance of the component <typeparamref name="T"/> from an attached pool.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <typeparam name="T">The type of component to acquire an instance of.</typeparam>
		/// <returns><see langword="true"/> if an instance of the component was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}()"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire<T>(out T instance) where T : Component {
			Component componentInstance;
			bool result = this.TryAcquire(typeof(T), out componentInstance);
			instance = (T)componentInstance;
			return result;
		}

		/// <summary>
		/// Acquires an instance of the component <typeparamref name="T"/> from an attached pool, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <typeparam name="T">The type of component to acquire an instance of.</typeparam>
		/// <returns><see langword="true"/> if an instance of the component was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Transform)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire<T>(Transform parent, out T instance) where T : Component {
			Component componentInstance;
			bool result = this.TryAcquire(typeof(T), parent, out componentInstance);
			instance = (T)componentInstance;
			return result;
		}

		/// <summary>
		/// Acquires an instance of the component <typeparamref name="T"/> from an attached pool, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <typeparam name="T">The type of component to acquire an instance of.</typeparam>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Vector3, Quaternion)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire<T>(Vector3 position, Quaternion rotation, out T instance) where T : Component {
			Component componentInstance;
			bool result = this.TryAcquire(typeof(T), position, rotation, out componentInstance);
			instance = (T)componentInstance;
			return result;
		}

		/// <summary>
		/// Acquires an instance of the component <typeparamref name="T"/> from an attached pool,, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <typeparam name="T">The type of component to acquire an instance of.</typeparam>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Transform, Vector3, Quaternion)"/>
		/// <seealso cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.Release"/>
		public bool TryAcquire<T>(Transform parent, Vector3 position, Quaternion rotation, out T instance) where T : Component {
			Component componentInstance;
			bool result = this.TryAcquire(typeof(T), parent, position, rotation, out componentInstance);
			instance = (T)componentInstance;
			return result;
		}
		#endregion

		#region ReleaseInternal(Component) method.
		/// <summary>
		/// Releases an instance of a component that was previously acquired from an attached pool.
		/// </summary>
		/// <param name="instance">The instance to release back to the pool.</param>
		protected override void ReleaseInternal(Component instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			var poolable = instance.GetComponent<PoolableComponent>();

			// If pooling is not enabled, destroy the object instead of releasing it to the pool.
			if (!this.Enabled) {
				// We expect the PoolableComponent to be destroyed.
				if (poolable != null) {
					poolable.ExpectDestroy = true;
				}
				Object.Destroy(instance.gameObject);
				return;
			}

			// Ensure the instance has its PoolableComponent component on it, which is needed to know which pool it should be returned to.
			if (poolable == null) {
				DebugHelper.LogError($"Unable to release a component ({instance.name}) to its pool without a {nameof(PoolableComponent)} component on it. The object may not have originated from a pool. The object will be destroyed.");
				Object.Destroy(instance.gameObject);
				return;
			}
			
			// Get the pool that handles this instance.
			ComponentPool pool;
			if (!this.TryGetPool(poolable.SourceObject, out pool)) {
				DebugHelper.LogError($"Unable to release a component ({instance.name}) to its pool. No pool exists for the object. The object will be destroyed.");
				Object.Destroy(instance.gameObject);
				return;
			}

			pool.Release(instance);
		}
		#endregion

		#region CreatePool methods.
		/// <summary>
		/// Creates a <see cref="ComponentPool"/> that pools instances of <paramref name="componentType"/>, and attaches it to the manager.
		/// The pool is created on a child object of the manager's game object.
		/// </summary>
		/// <param name="componentType">The type of component to be pooled.</param>
		/// <returns>The newly-created <see cref="ComponentPool"/>.</returns>
		public ComponentPool CreatePool(Type componentType) {
			Contract.RequiresNotNull(componentType, nameof(componentType));
			Contract.RequiresMessage(!this.HasPool(componentType), () => $"The pool could not be created, as the component type ('{componentType.Name}') is already assigned to an existing pool.");

			// Create the pool on a child object of the manager's game object.
			return this.CreatePool(componentType, this.gameObject, true);
		}

		/// <summary>
		/// Creates a <see cref="ComponentPool"/> that pools instances of <paramref name="componentType"/>, and attaches it to the manager.
		/// </summary>
		/// <param name="componentType">The type of component to be pooled.</param>
		/// <param name="parent">The <see cref="GameObject"/> that the pool should be attached to, either directly or indirectly depending on <paramref name="createContainer"/>.</param>
		/// <param name="createContainer"><see langword="true"/> to create the pool on a child object parented to <paramref name="parent"/>; <see langword="false"/> to create the pool directly on <paramref name="parent"/>.</param>
		/// <returns>The newly-created <see cref="ComponentPool"/>.</returns>
		public ComponentPool CreatePool(Type componentType, GameObject parent, bool createContainer = false) {
			Contract.RequiresNotNull(componentType, nameof(componentType));
			Contract.RequiresMessage(!this.HasPool(componentType), () => $"The pool could not be created, as the component ('{componentType.Name}') is already assigned to an existing pool.");

			var settings = new ComponentPoolSettings(this.DefaultPoolSettings) {
				Source = componentType
			};

			return this.CreatePool(settings, parent, createContainer, $"{componentType.Name} Pool");
		}
		#endregion

		#region PoolManagerBase overrides.
		/// <inheritdoc />
		protected override bool InternalAcquire(Type componentType, out ComponentPool pool, out Component instance) {
			// As no pool exists for the source object, decide what to do next.
			switch (this.AcquireMode) {
				case AcquireNoPoolMode.Error:
					throw new ArgumentException("Unable to acquire an instance of a component, as no pool exists for it.", nameof(componentType));
				case AcquireNoPoolMode.Instantiate:
					// Instantiate a new instance of the component.
					var go = new GameObject(componentType.Name);
					instance = go.AddComponent(componentType);
					pool = null;

					// Add the PoolableComponent component, and let it know that the instance is not expected to be returned to a pool.
					var poolable = go.AddComponent<PoolableComponent>();
					poolable.SourceObject = componentType;
					poolable.ExpectNoPool = true;
					poolable.IsInPool = false;
					poolable.NotificationMode = this.DefaultPoolSettings.NotificationMode;

					return false;
				case AcquireNoPoolMode.CreatePool:
					var settings = new ComponentPoolSettings(this.DefaultPoolSettings) {
						Source = componentType
					};

					// Ensure at least one instance can always be acquired immediately after initialising the pool.
					if (settings.InitialSize == 0 && !settings.InstantiateWhenEmpty) {
						settings.InstantiateWhenEmpty = true;
					}

					// Create and initialise the new pool.
					pool = this.CreatePool(settings);
					instance = null;
					return true;
				default:
					throw new NotImplementedException();
			}
		}

		/// <inheritdoc />
		protected override string GetSourceName(Type source) {
			return source.Name;
		}
		#endregion

		#region GameObject menu item.
#if UNITY_EDITOR
		/// <summary>
		/// Adds a menu item to create custom GameObjects.
		/// </summary>
		/// <param name="menuCommand"></param>
		[MenuItem("GameObject/Pooling/Component Pool Manager", false, 10)] // Priority 10 ensures it is grouped with the other menu items of the same kind and propagated to the hierarchy dropdown and hierarchy context menus.
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void CreateCustomGameObject(MenuCommand menuCommand) {
			EditorHelper.CreateCustomGameObject<ComponentPoolManager>("Component Pool Manager", menuCommand.context as GameObject);
		}
#endif
		#endregion

		#region Static access.
		private static ComponentPoolManager instance;
		
		/// <summary>
		/// Gets the <see cref="ComponentPoolManager"/> found in the scene.
		/// </summary>
		/// <remarks>
		/// <para>
		/// If more than one <see cref="ComponentPoolManager"/> exists in the scene, the instance returned by this property is undefined.
		/// </para>
		/// <para>
		/// If no <see cref="ComponentPoolManager"/> is found in the scene, a new root <see cref="GameObject"/> is
		/// created with the <see cref="ComponentPoolManager"/> component attached.
		/// </para>
		/// </remarks>
		public static ComponentPoolManager Instance {
			get {
				if (ComponentPoolManager.instance != null) return ComponentPoolManager.instance;

				// Look for the manager in the scene.
				ComponentPoolManager.instance = Object.FindObjectOfType<ComponentPoolManager>();
				if (ComponentPoolManager.instance == null) {
					// Create a new manager.
					var container = new GameObject(nameof(ComponentPoolManager));
					ComponentPoolManager.instance = container.AddComponent<ComponentPoolManager>();
				}

				return ComponentPoolManager.instance;
			}
		}
		#endregion

	}

}