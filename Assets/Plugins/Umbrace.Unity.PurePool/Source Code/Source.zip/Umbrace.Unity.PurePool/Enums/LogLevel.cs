﻿namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Specifies the level of log messaging to output.
	/// </summary>
	public enum LogLevel {

		/// <summary>
		/// Logging is disabled.
		/// </summary>
		Off,

		/// <summary>
		/// Informational messages, warning messages and error messages are displayed.
		/// </summary>
		Information,

		/// <summary>
		/// Warning messages and error messages are displayed.
		/// </summary>
		Warning,

		/// <summary>
		/// Only error messages are displayed.
		/// </summary>
		Error
		
	}

}