﻿ // ReSharper disable once CheckNamespace
namespace System.Runtime.CompilerServices {

	// Define the Caller* attributes that are only present in .NET 4.5. The compiler will still be able to use them as long as they are in the correct namespace.

	[AttributeUsage(AttributeTargets.Parameter, AllowMultiple = false, Inherited = false)]
	internal sealed class CallerMemberNameAttribute : Attribute {
	}

	//[AttributeUsage(AttributeTargets.Parameter, AllowMultiple = false, Inherited = false)]
	//internal class CallerFilePathAttribute : Attribute {
	//}

	//[AttributeUsage(AttributeTargets.Parameter, AllowMultiple = false, Inherited = false)]
	//internal class CallerLineNumberAttribute : Attribute {
	//}

}