using System;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A container class for the settings that a <see cref="ComponentPoolManager"/> can have.
	/// </summary>
	[Serializable]
	public class ComponentPoolManagerSettings : PoolManagerSettings<ComponentPoolSettings, Type> {

		#region Constructor.
		/// <summary>
		/// Initialises a new instance of the <see cref="ComponentPoolManagerSettings"/> class.
		/// </summary>
		public ComponentPoolManagerSettings() {
			// Do nothing.
		}
		#endregion

	}

}