﻿using UnityEngine;

namespace Umbrace.Unity.PurePool.Photon {

	/// <summary>
	/// Defines all the methods that a Object Pool must implement, so that PUN can use it.
	/// </summary>
	/// <remarks>
	/// To use a Object Pool for instantiation, you can set PhotonNetwork.ObjectPool.
	/// That is used for all objects, as long as ObjectPool is not null.
	/// The pool has to return a valid non-null GameObject when PUN calls Instantiate.
	/// Also, the position and rotation must be applied.
	///
	/// Please note that pooled GameObjects don't get the usual Awake and Start calls.
	/// OnEnable will be called (by your pool) but the networking values are not updated yet
	/// when that happens. OnEnable will have outdated values for PhotonView (isMine, etc.).
	/// You might have to adjust scripts.
	///
	/// PUN will call OnPhotonInstantiate (see IPunCallbacks). This should be used to
	/// setup the re-used object with regards to networking values / ownership.
	/// </remarks>
	public interface IPunPrefabPool {

		/// <summary>
		/// This is called when PUN wants to create a new instance of an entity prefab. Must return valid GameObject with PhotonView.
		/// </summary>
		/// <param name="prefabId">The id of this prefab.</param>
		/// <param name="position">The position we want the instance instantiated at.</param>
		/// <param name="rotation">The rotation we want the instance to take.</param>
		/// <returns>The newly instantiated object, or null if a prefab with <paramref name="prefabId"/> was not found.</returns>
		GameObject Instantiate(string prefabId, Vector3 position, Quaternion rotation);

		/// <summary>
		/// This is called when PUN wants to destroy the instance of an entity prefab.
		/// </summary>
		/// <remarks>
		/// A pool needs some way to find out which type of GameObject got returned via Destroy().
		/// It could be a tag or name or anything similar.
		/// </remarks>
		/// <param name="gameObject">The instance to destroy.</param>
		void Destroy(GameObject gameObject);

	}

}