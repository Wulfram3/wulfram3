﻿using System;
using System.Collections.Generic;

using UnityEngine;
// ReSharper disable All

namespace Umbrace.Unity.PurePool.Photon {

	/// <summary>
	/// <para>This is a non-functional template class. DO NOT USE.</para>
	/// <para>
	/// The main class to use the PhotonNetwork plugin.
	/// This class is static.
	/// </para>
	/// </summary>
	public static class PhotonNetwork {

		/// <summary>
		/// While enabled (true), Instantiate uses PhotonNetwork.PrefabCache to keep game objects in memory (improving instantiation of the same prefab).
		/// </summary>
		/// <remarks>
		/// Setting UsePrefabCache to false during runtime will not clear PrefabCache but will ignore it right away.
		/// You could clean and modify the cache yourself. Read its comments.
		/// </remarks>
		public static bool UsePrefabCache = true;

		/// <summary>
		/// An Object Pool can be used to keep and reuse instantiated object instances. It replaced Unity's default Instantiate and Destroy methods.
		/// </summary>
		/// <remarks>
		/// To use a GameObject pool, implement IPunPrefabPool and assign it here.
		/// Prefabs are identified by name.
		/// </remarks>
		public static IPunPrefabPool PrefabPool {
			get => throw new NotImplementedException();
			set => throw new NotImplementedException();
		}

		/// <summary>
		/// Keeps references to GameObjects for frequent instantiation (out of memory instead of loading the Resources).
		/// </summary>
		/// <remarks>
		/// You should be able to modify the cache anytime you like, except while Instantiate is used. Best do it only in the main-Thread.
		/// </remarks>
		public static Dictionary<string, GameObject> PrefabCache = null;

	}


}